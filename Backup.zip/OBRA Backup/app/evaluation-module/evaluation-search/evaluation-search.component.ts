import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { MyDatePicker, IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { DateService } from '../../Service/date.service';
import { ModalService } from '../../Service/modal.service';


@Component({
  selector: 'app-evaluation-search',
  templateUrl: './evaluation-search.component.html',
  styleUrls: ['./evaluation-search.component.css']
})
export class EvaluationSearchComponent implements OnInit {
  dataUrl: string;
  configUrl: string;
  searchInput: Object = {};
  errorSection: boolean;
  errorContent: string;
  resetFlag: boolean;
  terminationTypeDropDown: any;
  dischargeTypeDropDown: any;
  evaluationTypeDropDown: any;
  determinationsDropDown: any;
  diagonosisCategoriesDropDown: any;
  agenciesDropDown: any;
  recomendationsDropDown: any;
  facilitiesDropDown: any;
  findAllActiveReferralList: any;
  serviceProviderDropDown: any;
  reviewerDropDown: any;
  spinnerFlag: boolean;
  ssnMask: any[] = [/\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  private assignmentDropDown: any = [{ 'key': '1', 'value': '=' }, { 'key': '2', 'value': '>' }, { 'key': '3', 'value': '<' },
  { 'key': '4', 'value': '>=' }, { 'key': '5', 'value': '<=' }, { 'key': '6', 'value': 'Range' }];
  private obj: any = [];
  private rolekeys: any;
  private evaluationSearchForm: any;
  private filter: any = { 'filters': {} };
  private myDatePickerOptions: IMyDpOptions = {
    dateFormat: this.dateService.dateFormate(),
    editableDateField: false,
    openSelectorOnInputClick: true,
    disableSince: this.dateService.disableDate()
  };
 
  private flagArray: any = {
    'dateOfBirth': false, 'terminationDate': false, 'receivedDate': false,
    'referralDate': false, 'determinationDate': false
  };


  constructor(private dateService: DateService, private router: Router, private httpService: WebService,
    private activeRoute: ActivatedRoute, private builder: FormBuilder, private modalService: ModalService) {
    // console.log(this.flagArray.dateOfBirth);
    this.errorSection = false;
    this.resetFlag = false;
    this.spinnerFlag = false;
  }

  ngOnInit() {
    this.dataUrl = 'evaluationsList';
    this.configUrl = 'EvaluationSearch.json';
    // this.searchInput = {
    //   'search': '{\'filters\':[{\'id\':\'firstName\',\'value\':\'\'}]}'
    // };
    this.evaluationSearchForm = this.builder.group({
      'ssn': [''],
      'firstName': [''],
      'lastName': [''],
      'dateOfBirthSelect': [''],
      'dateOfBirth': [''],
      'dateOfBirthTo': [''],
      'terminationType': [''],
      'terminationDateSelect': [''],
      'terminationDate': [''],
      'terminationDateTo': [''],
      'dischargeType': [''],
      'evaluationTypeStr': [''],
      'determination': [''],
      'diagnosisCategory': [''],
      'recommendation': [''],
      'facilitiesStr': [''],
      'referralFacility': [''],
      'serviceProvidersStr': [''],
      'agenciesStr': [''],
      'transferTrauma': [''],
      'thirtyMonthRule': [''],
      'receivedDateSelect': [''],
      'receivedDate': [''],
      'receivedDateTo': [''],
      'referralDateSelect': [''],
      'referralDate': [''],
      'referralDateTo': [''],
      'determinationDateSelect': [''],
      'determinationDate': [''],
      'determinationDateTo': [''],
      'reviewer': ['']
    });
    this.getDropDowns();
  }
  getDropDowns() {
    this.spinnerFlag = true;
    this.httpService.getRecord('terminationTypeDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.terminationTypeDropDown = res.data;
        this.spinnerFlag = false;
      } else {
        this.spinnerFlag = false;
      }

    }, error => {
      this.spinnerFlag = false;
    });
    this.spinnerFlag = true;
    this.httpService.getRecord('dischargeTypeDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.dischargeTypeDropDown = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
    this.spinnerFlag = true;
    this.httpService.getRecord('evaluationTypeDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.evaluationTypeDropDown = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
    this.spinnerFlag = true;
    this.httpService.getRecord('determinationsDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.determinationsDropDown = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
    this.spinnerFlag = true;
    this.httpService.getRecord('diagonosisCategoriesDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.diagonosisCategoriesDropDown = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
    this.spinnerFlag = true;
    this.httpService.getRecord('agenciesDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.agenciesDropDown = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
    this.spinnerFlag = true;
    this.httpService.getRecord('recomendationsDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.recomendationsDropDown = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
    this.spinnerFlag = true;
    this.httpService.getRecord('facilitiesDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.facilitiesDropDown = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
    this.spinnerFlag = true;
    this.httpService.getRecord('findAllActiveReferralList').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.findAllActiveReferralList = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
    this.spinnerFlag = true;
    this.httpService.getRecord('serviceProviderDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.serviceProviderDropDown = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
    this.spinnerFlag = true;
    this.httpService.getRecord('reviewerDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.reviewerDropDown = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
  }
  onDateChanged(field, event: IMyDateModel) {
    console.log(field);
  }
  assignmentOperatorChange(selecetedVal, formField) {
    if (Number(selecetedVal) === 6) {
      this.flagArray[formField] = true;
    } else {
      this.flagArray[formField] = false;
    }
  }
  evaluationSearchSubmit() {
    this.resetFlag = false;
    Object.keys(this.evaluationSearchForm.controls).forEach(field => {
      const control = this.evaluationSearchForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    const SsnData = String(this.evaluationSearchForm.value.ssn);
    this.evaluationSearchForm.value.ssn = SsnData.replace(/\D+/g, '');
    // if (this.evaluationSearchForm.valid) {
    // }
    this.obj = [];
    if (this.evaluationSearchForm.value.dateOfBirth instanceof Object) {
      const dateOfBirth = this.evaluationSearchForm.value.dateOfBirth.formatted;
      this.evaluationSearchForm.value.dateOfBirth = dateOfBirth;
    } else if (!this.evaluationSearchForm.value.dateOfBirth) {
      this.evaluationSearchForm.value.dateOfBirth = '';
    }
    if (this.evaluationSearchForm.value.dateOfBirthTo instanceof Object) {
      const dateOfBirthTo = this.evaluationSearchForm.value.dateOfBirthTo.formatted;
      this.evaluationSearchForm.value.dateOfBirthTo = dateOfBirthTo;
    } else if (!this.evaluationSearchForm.value.dateOfBirthTo) {
      this.evaluationSearchForm.value.dateOfBirthTo = '';
    }
    if (this.evaluationSearchForm.value.terminationDate instanceof Object) {
      const terminationDate = this.evaluationSearchForm.value.terminationDate.formatted;
      this.evaluationSearchForm.value.terminationDate = terminationDate;
    } else if (!this.evaluationSearchForm.value.terminationDate) {
      this.evaluationSearchForm.value.terminationDate = '';
    }
    if (this.evaluationSearchForm.value.terminationDateTo instanceof Object) {
      const terminationDateTo = this.evaluationSearchForm.value.terminationDateTo.formatted;
      this.evaluationSearchForm.value.terminationDateTo = terminationDateTo;
    } else if (!this.evaluationSearchForm.value.terminationDateTo) {
      this.evaluationSearchForm.value.terminationDateTo = '';
    }
    if (this.evaluationSearchForm.value.referralDate instanceof Object) {
      const referralDate = this.evaluationSearchForm.value.referralDate.formatted;
      this.evaluationSearchForm.value.referralDate = referralDate;
    } else if (!this.evaluationSearchForm.value.referralDate) {
      this.evaluationSearchForm.value.referralDate = '';
    }
    if (this.evaluationSearchForm.value.referralDateTo instanceof Object) {
      const referralDateTo = this.evaluationSearchForm.value.referralDateTo.formatted;
      this.evaluationSearchForm.value.referralDateTo = referralDateTo;
    } else if (!this.evaluationSearchForm.value.referralDateTo) {
      this.evaluationSearchForm.value.referralDateTo = '';
    }
    if (this.evaluationSearchForm.value.determinationDate instanceof Object) {
      const determinationDate = this.evaluationSearchForm.value.determinationDate.formatted;
      this.evaluationSearchForm.value.determinationDate = determinationDate;
    } else if (!this.evaluationSearchForm.value.determinationDate) {
      this.evaluationSearchForm.value.determinationDate = '';
    }
    if (this.evaluationSearchForm.value.determinationDateTo instanceof Object) {
      const determinationDateTo = this.evaluationSearchForm.value.determinationDateTo.formatted;
      this.evaluationSearchForm.value.determinationDateTo = determinationDateTo;
    } else if (!this.evaluationSearchForm.value.determinationDateTo) {
      this.evaluationSearchForm.value.determinationDateTo = '';
    }
    this.rolekeys = Object.keys(this.evaluationSearchForm.value);
    for (let i = 0; i < this.rolekeys.length; i++) {
      const jsonData: any = {};
      let j = this.rolekeys[i];
      j = j.replace(/"/g, '\\"');
      jsonData.id = this.rolekeys[i];
      jsonData.value = this.evaluationSearchForm.value[j];
      this.obj.push(jsonData);
    }
    this.filter.filters = this.obj;
    this.getEvaluationList();
  }
  getEvaluationList() {
    if (this.resetFlag === true) {
      this.searchInput = {
        'search': JSON.stringify({})
      };
    } else {
      this.searchInput = {
        'search': JSON.stringify(this.filter)
      };
    }
  }
  searchFormReset() {
    this.evaluationSearchForm.reset();
    this.resetFlag = true;
  }
  createEvaluation() {
    this.router.navigateByUrl('/dashboard/evaluationdashboard/createevaluation');
    // this.router.navigate(['evaluationdashboard/createevaluation']);
  }


  // From Date Change Event
  ChangeDateOfBithFrom(event: IMyDateModel) {
    if (event.formatted === '' && this.evaluationSearchForm.value.dateOfBirth instanceof Object) {
      this.evaluationSearchForm.value.dateOfBirth.formatted = '';
    }

    if (event.formatted && this.evaluationSearchForm.value.dateOfBirthTo instanceof Object) {
      const fromDate = event.formatted;
      const toDate = this.evaluationSearchForm.value.dateOfBirthTo.formatted;

      if (this.dateService.compareDates(fromDate, toDate)) {
        this.errorSection = true;
        this.errorContent = this.dateService.getConfig().FROMDATE_ERROR;

        // this.disableSearchBtn = true;
      } else {
        this.errorSection = false;
        this.errorContent = '';


      }

    }

    if (!event.formatted && !this.evaluationSearchForm.value.dateOfBirthTo) {
      this.errorSection = false;
      this.errorContent = '';


    }

    if (!event.formatted && this.evaluationSearchForm.value.dateOfBirthTo) {
      this.errorSection = true;
      this.errorContent = this.dateService.getConfig().FROMDATE_NULLERROR;

      // this.disableSearchBtn = true;
    }


  }

  // To Date Change Event
  ChangeDateOfBirthTo(event: IMyDateModel) {
    if (event.formatted === '' && this.evaluationSearchForm.value.dateOfBirthTo instanceof Object) {
      this.evaluationSearchForm.value.dateOfBirthTo.formatted = '';
    }

    if (event.formatted && this.evaluationSearchForm.value.dateOfBirth instanceof Object) {
      const fromDate = this.evaluationSearchForm.value.dateOfBirth.formatted;
      const toDate = event.formatted;
      if (this.dateService.compareDates(fromDate, toDate)) {
        this.errorSection = true;
        this.errorContent = this.dateService.getConfig().FROMDATE_ERROR;

        // this.disableSearchBtn = true;
      } else {
        this.errorSection = false;
        this.errorContent = '';


      }

    }

    if (!event.formatted && !this.evaluationSearchForm.value.dateOfBirth) {
      this.errorSection = false;
      this.errorContent = '';

    }

    if (!event.formatted && this.evaluationSearchForm.value.dateOfBirth) {
      this.errorSection = false;
      this.errorContent = '';
    }

    if (event.formatted && !this.evaluationSearchForm.value.dateOfBirth) {
      this.errorSection = true;
      this.errorContent = this.dateService.getConfig().FROMDATE_NULLERROR;

    }

  }

  // From Date Change Event
  ChangeTerminationDateFrom(event: IMyDateModel) {
    if (event.formatted === '' && this.evaluationSearchForm.value.terminationDate instanceof Object) {
      this.evaluationSearchForm.value.terminationDate.formatted = '';
    }

    if (event.formatted && this.evaluationSearchForm.value.terminationDateTo instanceof Object) {
      const fromDate = event.formatted;
      const toDate = this.evaluationSearchForm.value.terminationDateTo.formatted;

      if (this.dateService.compareDates(fromDate, toDate)) {
        this.errorSection = true;
        this.errorContent = this.dateService.getConfig().FROMDATE_ERROR;
      } else {
        this.errorSection = false;
        this.errorContent = '';


      }

    }
    if (!event.formatted && !this.evaluationSearchForm.value.terminationDateTo) {
      this.errorSection = false;
      this.errorContent = '';
    }


    if (!event.formatted && this.evaluationSearchForm.value.terminationDateTo) {
      this.errorSection = true;
      this.errorContent = this.dateService.getConfig().FROMDATE_NULLERROR;
    }
  }

  // To Date Change Event
  ChangeTerminationDateTo(event: IMyDateModel) {
    if (event.formatted === '' && this.evaluationSearchForm.value.terminationDateTo instanceof Object) {
      this.evaluationSearchForm.value.terminationDateTo.formatted = '';
    }

    if (event.formatted && this.evaluationSearchForm.value.terminationDate instanceof Object) {
      const fromDate = this.evaluationSearchForm.value.terminationDate.formatted;
      const toDate = event.formatted;

      if (this.dateService.compareDates(fromDate, toDate)) {
        this.errorSection = true;
        this.errorContent = this.dateService.getConfig().FROMDATE_ERROR;

      } else {
        this.errorSection = false;
        this.errorContent = '';


      }

    }

    if (!event.formatted && !this.evaluationSearchForm.value.terminationDate) {
      this.errorSection = false;
      this.errorContent = '';


    }

    if (!event.formatted && this.evaluationSearchForm.value.terminationDate) {
      this.errorSection = false;
      this.errorContent = '';


    }

    if (event.formatted && !this.evaluationSearchForm.value.terminationDate) {
      this.errorSection = true;
      this.errorContent = this.dateService.getConfig().FROMDATE_NULLERROR;

    }

  }

  // From Date Change Event
  ChangeReceivedDateFrom(event: IMyDateModel) {
    if (event.formatted === '' && this.evaluationSearchForm.value.receivedDate instanceof Object) {
      this.evaluationSearchForm.value.receivedDate.formatted = '';
    }

    if (event.formatted && this.evaluationSearchForm.value.receivedDateTo instanceof Object) {
      const fromDate = event.formatted;
      const toDate = this.evaluationSearchForm.value.receivedDateTo.formatted;

      if (this.dateService.compareDates(fromDate, toDate)) {
        this.errorSection = true;
        this.errorContent = this.dateService.getConfig().FROMDATE_ERROR;
      } else {
        this.errorSection = false;
        this.errorContent = '';


      }

    }



    if (!event.formatted && !this.evaluationSearchForm.value.receivedDateTo) {
      this.errorSection = false;
      this.errorContent = '';

    }

    if (!event.formatted && this.evaluationSearchForm.value.receivedDateTo) {
      this.errorSection = true;
      this.errorContent = this.dateService.getConfig().FROMDATE_NULLERROR;
    }


  }

  // To Date Change Event
  ChangeReceivedDateTo(event: IMyDateModel) {
    if (event.formatted === '' && this.evaluationSearchForm.value.receivedDateTo instanceof Object) {
      this.evaluationSearchForm.value.receivedDateTo.formatted = '';
    }

    if (event.formatted && this.evaluationSearchForm.value.receivedDate instanceof Object) {
      const fromDate = this.evaluationSearchForm.value.receivedDate.formatted;
      const toDate = event.formatted;

      if (this.dateService.compareDates(fromDate, toDate)) {
        this.errorSection = true;
        this.errorContent = this.dateService.getConfig().FROMDATE_ERROR;

      } else {
        this.errorSection = false;
        this.errorContent = '';


      }

    }

    if (!event.formatted && !this.evaluationSearchForm.value.receivedDate) {
      this.errorSection = false;
      this.errorContent = '';


    }

    if (!event.formatted && this.evaluationSearchForm.value.receivedDate) {
      this.errorSection = false;
      this.errorContent = '';


    }

    if (event.formatted && !this.evaluationSearchForm.value.receivedDate) {
      this.errorSection = true;
      this.errorContent = this.dateService.getConfig().FROMDATE_NULLERROR;
    }

  }
  // From Date Change Event
  ChangeReferralDateFrom(event: IMyDateModel) {
    if (event.formatted === '' && this.evaluationSearchForm.value.referralDate instanceof Object) {
      this.evaluationSearchForm.value.referralDate.formatted = '';
    }

    if (event.formatted && this.evaluationSearchForm.value.referralDateTo instanceof Object) {
      const fromDate = event.formatted;
      const toDate = this.evaluationSearchForm.value.referralDateTo.formatted;

      if (this.dateService.compareDates(fromDate, toDate)) {
        this.errorSection = true;
        this.errorContent = this.dateService.getConfig().FROMDATE_ERROR;

      } else {
        this.errorSection = false;
        this.errorContent = '';
      }

    }

    if (!event.formatted && !this.evaluationSearchForm.value.referralDateTo) {
      this.errorSection = false;
      this.errorContent = '';


    }
    if (!event.formatted && this.evaluationSearchForm.value.referralDateTo) {
      this.errorSection = true;
      this.errorContent = this.dateService.getConfig().FROMDATE_NULLERROR;
    }
  }

  // To Date Change Event
  ChangeReferralDateTo(event: IMyDateModel) {
    if (event.formatted === '' && this.evaluationSearchForm.value.referralDateTo instanceof Object) {
      this.evaluationSearchForm.value.referralDateTo.formatted = '';
    }

    if (event.formatted && this.evaluationSearchForm.value.referralDate instanceof Object) {
      const fromDate = this.evaluationSearchForm.value.referralDate.formatted;
      const toDate = event.formatted;

      if (this.dateService.compareDates(fromDate, toDate)) {
        this.errorSection = true;
        this.errorContent = this.dateService.getConfig().FROMDATE_ERROR;
      } else {
        this.errorSection = false;
        this.errorContent = '';


      }

    }

    if (!event.formatted && !this.evaluationSearchForm.value.referralDate) {
      this.errorSection = false;
      this.errorContent = '';


    }

    if (!event.formatted && this.evaluationSearchForm.value.referralDate) {
      this.errorSection = false;
      this.errorContent = '';


    }

    if (event.formatted && !this.evaluationSearchForm.value.referralDate) {
      this.errorSection = true;
      this.errorContent = this.dateService.getConfig().FROMDATE_NULLERROR;
    }

  }
  // From Date Change Event
  ChangeDeterminationDateFrom(event: IMyDateModel) {
    if (event.formatted === '' && this.evaluationSearchForm.value.determinationDate instanceof Object) {
      this.evaluationSearchForm.value.determinationDate.formatted = '';
    }

    if (event.formatted && this.evaluationSearchForm.value.determinationDateTo instanceof Object) {
      const fromDate = event.formatted;
      const toDate = this.evaluationSearchForm.value.determinationDateTo.formatted;

      if (this.dateService.compareDates(fromDate, toDate)) {
        this.errorSection = true;
        this.errorContent = this.dateService.getConfig().FROMDATE_ERROR;
      } else {
        this.errorSection = false;
        this.errorContent = '';


      }

    }

    if (!event.formatted && !this.evaluationSearchForm.value.determinationDateTo) {
      this.errorSection = false;
      this.errorContent = '';


    }
    if (!event.formatted && this.evaluationSearchForm.value.determinationDateTo) {
      this.errorSection = true;
      this.errorContent = this.dateService.getConfig().FROMDATE_NULLERROR;
    }
  }

  // To Date Change Event
  ChangeDeterminationDateTo(event: IMyDateModel) {
    if (event.formatted === '' && this.evaluationSearchForm.value.determinationDateTo instanceof Object) {
      this.evaluationSearchForm.value.determinationDateTo.formatted = '';
    }

    if (event.formatted && this.evaluationSearchForm.value.determinationDate instanceof Object) {
      const fromDate = this.evaluationSearchForm.value.determinationDate.formatted;
      const toDate = event.formatted;

      if (this.dateService.compareDates(fromDate, toDate)) {
        this.errorSection = true;
        this.errorContent = this.dateService.getConfig().FROMDATE_ERROR;
      } else {
        this.errorSection = false;
        this.errorContent = '';
      }

    }

    if (!event.formatted && !this.evaluationSearchForm.value.determinationDate) {
      this.errorSection = false;
      this.errorContent = '';
    }
    if (!event.formatted && this.evaluationSearchForm.value.determinationDate) {
      this.errorSection = false;
      this.errorContent = '';
    }

    if (event.formatted && !this.evaluationSearchForm.value.determinationDate) {
      this.errorSection = true;
      this.errorContent = this.dateService.getConfig().FROMDATE_NULLERROR;
    }

  }
}
