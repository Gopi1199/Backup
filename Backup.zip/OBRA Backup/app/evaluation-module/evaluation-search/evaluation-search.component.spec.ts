import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EvaluationSearchComponent } from './evaluation-search.component';

describe('EvaluationSearchComponent', () => {
  let component: EvaluationSearchComponent;
  let fixture: ComponentFixture<EvaluationSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EvaluationSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EvaluationSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
