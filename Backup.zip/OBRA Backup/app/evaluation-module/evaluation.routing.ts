import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EvaluationComponent } from './evaluation.component';
import { CreateEvaluationComponent } from './create-evaluation/create-evaluation.component';
import { ViewEvaluationComponent } from './view-evaluation/view-evaluation.component';
import { EvaluationHistoryComponent } from './evaluation-history/evaluation-history.component';
import { EvaluationDetailComponent } from './evaluation-detail/evaluation-detail.component';
const routes: Routes = [
    { path: '', component: EvaluationComponent, pathMatch: 'full' },
    { path: 'evaluationdashboard', pathMatch: 'full', component: EvaluationComponent },
    { path: 'createevaluation', pathMatch: 'full', component: CreateEvaluationComponent },
    { path: 'createevaluation/:evalId', pathMatch: 'full', component: CreateEvaluationComponent },
    { path: 'evaluationhistroy', pathMatch: 'full', component: EvaluationHistoryComponent },
    { path: 'createevaluation/:id', pathMatch: 'full', component: CreateEvaluationComponent },
    { path: 'evaluationdetail/:id', pathMatch: 'full', component: EvaluationDetailComponent },
    { path: 'viewevaluation', pathMatch: 'full', component: ViewEvaluationComponent },
    { path: '**', redirectTo: 'dashboard', pathMatch: 'full' }
];

export const EvalutionRoutes: ModuleWithProviders = RouterModule.forChild(routes);
