import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { EvalutionRoutes } from './evaluation.routing';
import { ValidationService } from '../validation/validation.service';
import { HttpModule } from '@angular/http';
import { SharedModule } from '../SharedModule/shared.module';
import { EvaluationComponent } from './evaluation.component';
import { EvaluationSearchComponent } from './evaluation-search/evaluation-search.component';
import { CreateEvaluationComponent } from './create-evaluation/create-evaluation.component';
import { ViewEvaluationComponent } from './view-evaluation/view-evaluation.component';
import { TextMaskModule } from 'angular2-text-mask';
import { EvaluationHistoryComponent } from './evaluation-history/evaluation-history.component';
import { EvaluationDetailComponent } from './evaluation-detail/evaluation-detail.component';
@NgModule({
    imports: [
        EvalutionRoutes,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        HttpModule,
        SharedModule,
        TextMaskModule
    ],
    declarations: [
        EvaluationComponent,
        EvaluationSearchComponent,
        CreateEvaluationComponent,
        ViewEvaluationComponent,
        EvaluationHistoryComponent,
        EvaluationDetailComponent
    ],
    providers: [ValidationService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class EvalutionModule {

}
