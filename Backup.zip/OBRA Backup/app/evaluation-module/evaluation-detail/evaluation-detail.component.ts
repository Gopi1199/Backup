import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { WebService } from '../../Service/webservice';

@Component({
  selector: 'app-evaluation-detail',
  templateUrl: './evaluation-detail.component.html',
  styleUrls: ['./evaluation-detail.component.css']
})
export class EvaluationDetailComponent implements OnInit {
  private sub: any;
  private evalId: any;
  private spinnerFlag: boolean;
  private selectedRowData: any;
  constructor(private activeRoute: ActivatedRoute, private httpService: WebService) {
    this.spinnerFlag = false;
  }

  ngOnInit() {
    this.sub = this.activeRoute.params.subscribe(params => {
      if (params['id']) {
        this.evalId = params['id'];
      }
    });
    this.getEvalDetails();
  }
  getEvalDetails() {
    this.spinnerFlag = true;
    this.httpService.getRecord('fetchEvaluation?evaluationId=' + this.evalId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.selectedRowData = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });

  }
}
