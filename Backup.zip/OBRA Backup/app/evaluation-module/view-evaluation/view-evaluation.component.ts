import { Component, OnInit, OnDestroy, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { CommonServiceService } from '../../Service/common-service.service';
import { WebService } from '../../Service/webservice';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { dateFormat } from '../../JSON';

@Component({
  selector: 'app-view-evaluation',
  templateUrl: './view-evaluation.component.html',
  styleUrls: ['./view-evaluation.component.css']
})
export class ViewEvaluationComponent implements OnInit {
  private modalRef: BsModalRef;
  constructor(private activeRoute: ActivatedRoute, private httpService: WebService, private router: Router,
    private modalService: BsModalService, private builder: FormBuilder) { }

  ngOnInit() {
  }
  viewClientNotesModal(viewClientNotes: TemplateRef<any>) {
    this.modalRef = this.modalService.show(viewClientNotes);
  }
  dischargeLetterModal(dischargeLetter: TemplateRef<any>) {
    this.modalRef = this.modalService.show(dischargeLetter);
  }
  openEvaluationModal(openEvaluation: TemplateRef<any>) {
    this.modalRef = this.modalService.show(openEvaluation);
  }
  certificationDeliveryModal(certificationDelivery: TemplateRef<any>) {
    this.modalRef = this.modalService.show(certificationDelivery);
  }
  medicaidLetterModal(medicaidLetter: TemplateRef<any>) {
    this.modalRef = this.modalService.show(medicaidLetter);
  }
  consumerNotesModal(consumerNotes: TemplateRef<any>) {
    this.modalRef = this.modalService.show(consumerNotes);
  }
  evaluationLetterHistoryModal(evaluationLetterHistory: TemplateRef<any>) {
    this.modalRef = this.modalService.show(evaluationLetterHistory);
  }
  evaluationDocumentsModal(evaluationDocuments: TemplateRef<any>) {
    this.modalRef = this.modalService.show(evaluationDocuments);
  }
  editEvaluationModal(viewClientNotes: TemplateRef<any>) {
    this.modalRef = this.modalService.show(viewClientNotes);
  }
  editEvaluationLevelOneModal(editEvaluationLevelOne: TemplateRef<any>) {
    this.modalRef = this.modalService.show(editEvaluationLevelOne);
  }
  editEvalAxisAndRecModal(editEvalAxisAndRec: TemplateRef<any>) {
    this.modalRef = this.modalService.show(editEvalAxisAndRec);
  }
  editEvaluationMDHHSModal(editEvaluationMDHHS: TemplateRef<any>) {
    this.modalRef = this.modalService.show(editEvaluationMDHHS);
  }
}
