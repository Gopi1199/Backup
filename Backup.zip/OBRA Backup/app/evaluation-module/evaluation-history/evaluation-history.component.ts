import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
// import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-evaluation-history',
  templateUrl: './evaluation-history.component.html',
  styleUrls: ['./evaluation-history.component.css']
})
export class EvaluationHistoryComponent implements OnInit {
  dataUrl: string;
  configUrl: string;
  searchInput: Object = {};
  clientId: any;
  sub: any;
  constructor(private router: Router) { }

  ngOnInit() {
    // this.sub = this.activeRoute.params.subscribe(params => {
    //   alert(params['clientId']);
    //   this.clientId = params['clientId'];
    // });
    this.dataUrl = 'evaluationsList';
    this.configUrl = 'EvaluationSearch.json';
    this.searchInput = {
      'search': JSON.stringify({})
    };
  }
  onNotify(data: any): void {
    this.router.navigate(['/dashboard/evaluationdashboard/evaluationdetail', data.evaluationId]);
  }

}
