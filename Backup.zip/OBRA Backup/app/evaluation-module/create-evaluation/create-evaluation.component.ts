import { Component, OnInit, Input, ViewChild, ElementRef, Renderer2, TemplateRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { MyDatePicker, IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { DateService } from '../../Service/date.service';
import { ModalService } from '../../Service/modal.service';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';


@Component({
  selector: 'app-create-evaluation',
  templateUrl: './create-evaluation.component.html',
  styleUrls: ['./create-evaluation.component.css']
})

export class CreateEvaluationComponent implements OnInit {
  spinnerFlag: boolean;
  name: string;

  private modalRef: BsModalRef;
  @ViewChild('fileInput') el: ElementRef;
  private evaluationCreateForm: any;
  private ssnSearchFlag: boolean;
  private notesFlag: boolean;
  private form1: boolean;
  private form3: boolean;
  private form2: boolean;
  private maxlength: number;
  private notes: string;
  private ssnFlag: boolean;
  private notesMouseEvevtFlag: boolean;
  private characterleft: number;
  private evaluationTypeDropDown: any;
  private agenciesDropDown: any;
  private findAllActiveReferralList: any;
  private facilitiesDropDown: any;
  private clientId: any;
  private fromData: any = {};
  private popOverFlag: boolean;
  private ssnData: any;
  private data: any;
  private selectedEvalRowData: any;
  private ProfessionalsDropDowns: any;
  psyFormAssessorList: any;
  psycoFormAssessorList: any;
  sensoriFormAssessorList: any;
  psycoFormCSList: any;
  sensoriFormCSList: any;
  psFormCSList: any;
  psyFormCSList: any;
  evalNoteCount: any;
  medicalFormAssessorList: any;
  psFormAssessorList: any;
  medicalFormCSList: any;
  ssnHeader: string;
  ssnNumber: any;
  errorSection: boolean;
  errorContent: string;
  addClientNotesForm: any;
  private selectedRowData: any;
  private clientNoteCount: any;
  private errorFlag: boolean;
  private erroMsg: string;
  private activeStatus: Boolean = true;
  private addClientNotesSuccess: boolean;
  private addClientNotesError: boolean;
  private addEvalNotesSuccess: boolean;
  private addEvalNotesError: boolean;
  private addEvalNotesForm: any;
  private evalId: any;
  private sub: any;
  mask: any[] = [/\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  private terminationTypeDropDown: any;
  constructor(private dateService: DateService, private router: Router, private httpService: WebService,
    private activeRoute: ActivatedRoute, private builder: FormBuilder, private rd: Renderer2, private modalService: BsModalService) {
    this.name = `File Upload`;
    this.ssnSearchFlag = false;
    this.form1 = true;
    this.form3 = false;
    this.form2 = false;
    this.maxlength = 4000;
    this.characterleft = this.maxlength;
    this.notes = '';
    this.notesMouseEvevtFlag = false;
    this.spinnerFlag = false;
    this.notesFlag = false;
    this.ssnFlag = true;
    this.popOverFlag = false;
    this.errorFlag = false;
    this.addClientNotesSuccess = false;
    this.addClientNotesSuccess = false;
    this.addEvalNotesSuccess = false;
    this.addEvalNotesSuccess = false;
    this.errorSection = false;
  }

  ngOnInit() {
    this.evaluationCreateForm = this.builder.group({
      'ssn': [''],
      'evaluationTypeId': [''],
      'referralDate': [''],
      'agencyId': [''],
      'referralId': [''],
      'facilityId': [''],
      'admissionDate': [''],
      'referralCriteriaOne': [''],
      'criteriaOneDiagnosisCategory': [''],
      'referralCriteriaTwo': [''],
      'criteriaTwoDiagnosisCategory': [''],
      'referralCriteriaThree': [''],
      'referralCriteriaFour': [''],
      'referralCriteriaFive': [''],
      'referralCriteriaSix': [''],
      'notes': [''],
      'Upload3877': [''],
      'Upload3878': [''],
      'OtherUpload': [''],
      'SocialAssessor': [''],
      'Signee': [''],
      'Medical': [''],
      'psychoSocialCounter': [''],
      'Psychiatric': [''],
      'psychoSocialCounter1': [''],
      'Assessor': [''],
      'Counter': [''],
      'Sensorimotor': [''],
      'CounterSignee': ['']
    });
    this.addClientNotesForm = this.builder.group({
      'notes': ['', Validators.required]
    });
    this.addEvalNotesForm = this.builder.group({
      'notes': ['', Validators.required]
    });
    this.sub = this.activeRoute.params.subscribe(params => {
      if (params['id']) {
        this.clientId = params['id'];
        // this.popOverFlag = true;
        this.getConsumerInfo();
      } else if (params['evalId']) {
        this.evalId = params['evalId'];
        this.getEvalId(params['evalId']);
      }

    });
    this.addClientNotesForm = this.builder.group({
      'notes': ['', Validators.required]
    });
    this.addEvalNotesForm = this.builder.group({
      'notes': ['', Validators.required]
    });
    this.sub = this.activeRoute.params.subscribe(params => {
      if (params['id']) {
        this.clientId = params['id'];
        // this.popOverFlag = true;
        this.getConsumerInfo();
      }

    });
    this.getDropDowns();

  }
  getEvalId(id) {
    this.spinnerFlag = true;
    this.httpService.getRecord('fetchEvaluation?evaluationId=' + id).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.selectedRowData = res.data;
        this.clientId = this.selectedRowData.clientId;
        this.ssnData = this.selectedRowData.lastName;
        this.spinnerFlag = false;
        this.selectedEvalRowData = res.data.evalNotes ? res.data.evalNotes : '';
        this.selectedRowData = res.data.clientNotes ? res.data.clientNotes : '';
        this.notesFlag = false;
        this.form1 = false;
        this.form2 = false;
        this.form3 = true;
        this.getEvalInfo();
        this.getConsumerInfo();
        this.qualifiedProfessionalsdropdowns();
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
  }
  getDropDowns() {
    this.spinnerFlag = true;
    this.httpService.getRecord('evaluationTypeDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.evaluationTypeDropDown = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
    this.spinnerFlag = true;
    this.httpService.getRecord('agenciesDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.agenciesDropDown = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
    this.spinnerFlag = true;
    this.httpService.getRecord('findAllActiveReferralList').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.findAllActiveReferralList = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
    this.spinnerFlag = true;
    this.httpService.getRecord('facilitiesDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.facilitiesDropDown = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
  }
  onFileChange(event, FcontrolName) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      if (FcontrolName === 'Upload3877') {
        this.evaluationCreateForm.value.Upload3877 = file.name;
      } else if (FcontrolName === 'Upload3878') {
        this.evaluationCreateForm.value.Upload3878 = file.name;
      } else {
        this.evaluationCreateForm.value.OtherUpload = file.name;
      }

      const formData: FormData = new FormData();
      formData.append('uploadFile', file, file.name);
      this.spinnerFlag = true;
      this.httpService.getRecordList('this.dataUrl', formData).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;

        } else {
          this.spinnerFlag = false;
          // this.modalService.showAlertPopup('Warning', res.statusText, '');
        }
      }, error => {
        this.spinnerFlag = false;
      });

    }
  }
  getConsumerInfo() {
    this.spinnerFlag = true;
    this.selectedRowData = [];
    this.selectedRowData['clientLegalRepViews'] = [];
    this.selectedRowData['address'] = [];
    this.httpService.getRecord('viewClientHistory?clientId=' + this.clientId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.selectedRowData = res.data;
        this.clientId = this.selectedRowData.clientsId;
        this.spinnerFlag = false;
        this.ssnSearchFlag = false;
        this.ssnFlag = false;
        // alert(this.selectedRowData.lastName);
        this.ssnData = this.selectedRowData.lastName;
        // this.popOverFlag = true;
        this.clientNoteCount = res.data.clientNotes.length;
        this.selectedRowData.clientLegalRepViews.forEach(element => {
          if (element.status === 'A') {
            this.activeStatus = false;
          }
        });
        this.spinnerFlag = false;

      } else {
        this.spinnerFlag = false;
        this.errorFlag = true;
        this.erroMsg = res.inline;
      }

    }, error => {
      console.log(error);
    });
  }
  ssnValidator() {
    this.ssnSearchFlag = false;
    this.ssnNumber = this.evaluationCreateForm.value.ssn.replace(/\D+/g, '');
    if (this.ssnNumber.length === 9) {
      this.ssnSearchFlag = true;
      this.spinnerFlag = true;
      this.httpService.getRecord('quickSearch?ssn=' + this.ssnNumber).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.ssnData = res.data.lastname;
          this.ssnHeader = res.data.description;
          this.clientId = res.data.clientsID;
          this.spinnerFlag = false;
          this.ssnSearchFlag = false;
          this.ssnFlag = false;
          // this.popOverFlag = true;
          this.getConsumerInfo();
        } else {
          this.ssnHeader = res.data.description;
          this.popOverFlag = true;
          this.spinnerFlag = false;
          this.ssnSearchFlag = false;
        }
      }, error => {
        console.log(error);
      });
    }
  }
  addClientNotesSubmit() {
    this.addClientNotesSuccess = false;
    this.addClientNotesError = false;
    Object.keys(this.addClientNotesForm.controls).forEach(field => {
      const control = this.addClientNotesForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.addClientNotesForm.valid) {
      this.data = this.addClientNotesForm.value;
      this.data['clientsId'] = this.clientId;
      this.httpService.addRecord('addComment', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.getConsumerInfo();
          this.addClientNotesSuccess = true;
        } else {
          this.addClientNotesError = true;
          this.spinnerFlag = false;
        }

      }, error => {
        console.log(error);
      });

    }
  }
  closeEvalNoteModal() {
    this.modalRef.hide();
  }
  addEvalNotesSubmit() {
    this.addEvalNotesSuccess = false;
    this.addEvalNotesError = false;
    Object.keys(this.addEvalNotesForm.controls).forEach(field => {
      const control = this.addEvalNotesForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.addEvalNotesForm.valid) {
      this.data = [];
      this.data = this.addEvalNotesForm.value;
      this.data['evaluationId'] = this.evalId;
      console.log(this.data);
      this.httpService.addRecord('addEvalComment', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.getEvalInfo();
          this.addEvalNotesSuccess = true;
        } else {
          this.addEvalNotesError = true;
          this.spinnerFlag = false;
        }
      }, error => {
        console.log(error);
      });
    }
  }
  getEvalInfo() {
    this.spinnerFlag = true;
    this.selectedEvalRowData = [];
    this.httpService.getRecord('fetchEvaluationNotes?evaluationId=' + this.evalId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.selectedEvalRowData = res.data;
        this.spinnerFlag = false;
        this.ssnSearchFlag = false;
        this.ssnFlag = false;
        this.addEvalNotesForm.reset();
        this.evalNoteCount = res.data.length;
        this.spinnerFlag = false;

      } else {
        this.spinnerFlag = false;
        this.errorFlag = true;
        this.erroMsg = res.inline;
      }

    }, error => {
      console.log(error);
    });
  }
  closeClientNoteModal() {
    this.modalRef.hide();
  }
  consumerSearch() {
    //  this.router.navigate(['/dashboard/consumer-dashboard/consumer-search']);
    this.router.navigate(['/dashboard/consumer-dashboard/consumer-search', this.ssnNumber]);
  }
  Addconsumer() {
    this.router.navigate(['/dashboard/consumer-dashboard/add-edit-consumer', 'add', this.ssnNumber]);
  }
  gotoEditConsumer() {
    this.router.navigate(['/dashboard/consumer-dashboard/add-edit-consumer', 'edit', this.clientId]);
  }
  viewClientHistory() {
    this.router.navigate(['/dashboard/consumer-dashboard/consumer-history', this.clientId]);
  }
  viewClientNotesModal(viewClientNotes: TemplateRef<any>) {
    this.modalRef = this.modalService.show(viewClientNotes);
  }
  viewEvalNotesModal(viewEvalNotes: TemplateRef<any>) {
    this.modalRef = this.modalService.show(viewEvalNotes);
  }
  createNewEvaluation() {
    this.ssnFlag = true;
    this.router.navigate(['/dashboard/evaluationdashboard/createevaluation']);
    this.evaluationCreateForm.value.ssn = '';
  }
  cancelCreateEvaluation() {
    this.router.navigate(['/dashboard/evaluationdashboard/createevaluation']);
  }
  EvaluationHistroy() {
    this.router.navigate(['/dashboard/evaluationdashboard/evaluationhistroy']);
  }
  count(msg) {
    if (this.maxlength >= msg.length) {
      this.characterleft = (this.maxlength) - (msg.length);
    } else {
      this.notes = msg.substr(0, msg.length - 1);
      console.log(msg);
    }
  }
  mouseenter() {
    this.count(this.notes);
    this.notesMouseEvevtFlag = true;

  }
  mouseleave() {
    this.count(this.notes);
    this.notesMouseEvevtFlag = false;
  }
  form1Reset() {
    this.evaluationCreateForm.value.ssn = '';
    this.evaluationCreateForm.value.evalType = '';
    this.evaluationCreateForm.value.referralDate = '';
    this.evaluationCreateForm.value.agency = '';
    this.evaluationCreateForm.value.referral = '';
    this.evaluationCreateForm.value.facility = '';
    this.evaluationCreateForm.value.admissionDate = '';

  }
  form2Reset() {
    this.evaluationCreateForm.value.currentDiagnosis = '';
    this.evaluationCreateForm.value.receivedTreatment = '';
    this.evaluationCreateForm.value.receivedAntipsychotic = '';
    this.evaluationCreateForm.value.evidenceOfMentalIllness = '';
    this.evaluationCreateForm.value.intellectualDisability = '';
    this.evaluationCreateForm.value.evidenceOfDeficits = '';
    this.evaluationCreateForm.value.notes = '';

  }
  gotoForm2() {
    if (this.evaluationCreateForm.value.evaluationTypeId && this.evaluationCreateForm.value.referralDate
      && this.evaluationCreateForm.value.referralDate instanceof Object && !this.ssnFlag) {
      this.fromData['evaluationTypeId'] = this.evaluationCreateForm.value.evaluationTypeId;
      this.fromData['referralDate'] = this.evaluationCreateForm.value.referralDate instanceof Object ?
        this.evaluationCreateForm.value.referralDate.formatted : '';
      this.fromData['agencyId'] = this.evaluationCreateForm.value.agencyId;
      this.fromData['referralId'] = this.evaluationCreateForm.value.referralId;
      this.fromData['facilityId'] = this.evaluationCreateForm.value.facilityId;
      this.fromData['clientId'] = this.clientId;
      this.fromData['admissionDate'] = this.evaluationCreateForm.value.admissionDate instanceof Object ?
        this.evaluationCreateForm.value.admissionDate.formatted : '';
      this.spinnerFlag = true;
      this.httpService.getRecordList('createEvaluation', this.fromData).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.ssnSearchFlag = false;
          this.ssnFlag = false;
          this.form1 = false;
          this.form2 = true;
          this.form3 = false;
        } else {
          this.spinnerFlag = false;
          this.ssnSearchFlag = false;
        }
      }, error => {
        console.log(error);
      });
    } else {
      console.log('form contains errors');
    }
  }
  gotoForm1() {
    this.form1 = true;
    this.form2 = false;
    this.form3 = false;

  }
  form2Submit() {
    this.fromData['referralCriteriaOne'] = this.evaluationCreateForm.value.referralCriteriaOne ?
      this.evaluationCreateForm.value.referralCriteriaOne : '';
    this.fromData['criteriaOneDiagnosisCategory'] = this.evaluationCreateForm.value.criteriaOneDiagnosisCategory ?
      this.evaluationCreateForm.value.criteriaOneDiagnosisCategory : '';
    this.fromData['referralCriteriaTwo'] = this.evaluationCreateForm.value.referralCriteriaTwo
      ? this.evaluationCreateForm.value.referralCriteriaTwo : '';
    this.fromData['criteriaTwoDiagnosisCategory'] = this.evaluationCreateForm.value.criteriaTwoDiagnosisCategory ?
      this.evaluationCreateForm.value.criteriaTwoDiagnosisCategory : '';
    this.fromData['referralCriteriaThree'] = this.evaluationCreateForm.value.referralCriteriaThree ?
      this.evaluationCreateForm.value.referralCriteriaThree : '';
    this.fromData['referralCriteriaFour'] = this.evaluationCreateForm.value.referralCriteriaFour ?
      this.evaluationCreateForm.value.referralCriteriaFour : '';
    this.fromData['referralCriteriaFive'] = this.evaluationCreateForm.value.referralCriteriaFive ?
      this.evaluationCreateForm.value.referralCriteriaFive : '';
    this.fromData['referralCriteriaSix'] = this.evaluationCreateForm.value.referralCriteriaSix ?
      this.evaluationCreateForm.value.referralCriteriaSix : '';
    this.fromData['notes'] = this.evaluationCreateForm.value.notes ? this.evaluationCreateForm.value.notes : '';
    this.spinnerFlag = true;
    this.httpService.getRecordList('createEvaluation', this.fromData).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.notesFlag = false;
        this.form1 = false;
        this.form2 = false;
        this.form3 = true;
        this.evalId = res.data.evaluationId;
        this.selectedEvalRowData = res.data.notes;
        this.evalNoteCount = this.selectedEvalRowData.length ? this.selectedEvalRowData.length : 0;
        this.qualifiedProfessionalsdropdowns();
      } else {
        this.spinnerFlag = false;
        this.ssnSearchFlag = false;
      }
    }, error => {
      console.log(error);
    });
  }
  qualifiedProfessionalsdropdowns() {
    this.spinnerFlag = true;
    this.httpService.getRecord('qualifiedProfessionalsDropDowns').subscribe(res => {
      if (res.global === 'successMsg@') {
        console.log(this.spinnerFlag);
        console.log('2');
        this.ProfessionalsDropDowns = res.data;
        this.psyFormAssessorList = this.ProfessionalsDropDowns['psyFormAssessorList'];
        this.psycoFormAssessorList = this.ProfessionalsDropDowns['psycoFormAssessorList'];
        this.sensoriFormAssessorList = this.ProfessionalsDropDowns['sensoriFormAssessorList'];
        this.psycoFormCSList = this.ProfessionalsDropDowns['psycoFormCSList'];
        this.sensoriFormCSList = this.ProfessionalsDropDowns['sensoriFormCSList'];
        this.psFormCSList = this.ProfessionalsDropDowns['psFormCSList'];
        this.psyFormCSList = this.ProfessionalsDropDowns['psyFormCSList'];
        this.medicalFormAssessorList = this.ProfessionalsDropDowns['medicalFormAssessorList'];
        this.psFormAssessorList = this.ProfessionalsDropDowns['psFormAssessorList'];
        this.medicalFormCSList = this.ProfessionalsDropDowns['medicalFormCSList'];
        console.log('3');
        this.spinnerFlag = false;
      } else {
        console.log('3');
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
  }
  gotoForm3() {
    if (this.evaluationCreateForm.value.referralCriteriaOne === 'Yes' || this.evaluationCreateForm.value.referralCriteriaTwo === 'Yes'
      || this.evaluationCreateForm.value.referralCriteriaThree === 'Yes' || this.evaluationCreateForm.value.referralCriteriaFour === 'Yes'
      || this.evaluationCreateForm.value.referralCriteriaFive === 'Yes' || this.evaluationCreateForm.value.referralCriteriaSix === 'Yes') {
      // if (this.evaluationCreateForm.value.notes === undefined || this.evaluationCreateForm.value.notes === '') {
      if (this.evaluationCreateForm.value.notes) {
        this.form2Submit();
      } else {

        this.notesFlag = true;
      }
    } else {
      this.errorSection = true;
      this.errorContent = 'Select atleast one value';
      // this.form2Submit();
    }
  }
  SaveForm() {
    console.log(this.evaluationCreateForm.value);
  }
}

