import { Component, OnInit, OnDestroy, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { CommonServiceService } from '../../Service/common-service.service';
import { WebService } from '../../Service/webservice';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { dateFormat } from '../../JSON';

@Component({
  selector: 'app-appeals-detail',
  templateUrl: './appeals-detail.component.html',
  styleUrls: ['./appeals-detail.component.css']
})
export class AppealsDetailComponent implements OnInit, OnDestroy {
  appealsId: number;
  appealType: number;
  evaluationId : number;
  clientsId : number;
  private sub: any;
  private legalRep: any;
  private modalRef: BsModalRef;
  private obj = new Array();
  private spinnerFlag: Boolean = false;
  private activeStatus: Boolean = true;
  private selectedRowData: any;
  private appealNoteCount: any;
  private dateFormat: any;
  private appealFilingsDropDown: any;
  private determinationsDropDown: any;
  private resolutionsByappealTypeDropDown: any;
  private appealsForm: any;
  private addAppealNotesForm: any;
  private addAppealNotesSuccess: Boolean = false;
  private addAppealNotesError: Boolean = false; 
  private statusMessage: String;
  private data: any; 
  private sucessFlag: Boolean = false;
  private errorFlag: Boolean = false;
  private sucessMsg: String = '';
  private errorMsg: String = '';

  constructor(private activeRoute: ActivatedRoute, private httpService: WebService, private router: Router,
    private modalService: BsModalService, private builder: FormBuilder) {
    this.dateFormat = dateFormat;  
  }

  ngOnInit() {
    this.sub = this.activeRoute.params.subscribe(params => {
      this.appealsId = Number(params['id']);
      this.getAppealsInfo();
    });
    this.addAppealNotesForm = this.builder.group({
      'notes': ['', Validators.required]
    });
    this.appealsForm = this.builder.group({
        'appealFilingId': ['', Validators.required],
        'dateOfAppeal': ['', Validators.required],
        'dateReceivedObra': ['', Validators.required],
        'dateReceivedTribunal': [''],
        'expirationDate': [''],
        'prehearingMeetingDate': [''],
        'hearingDocketNumber': [''],
        'dateScheduled': [''] ,
        'resolutionsId': [''] ,
        'appealType': [''],
        'detreminationId': [''] ,
        'reEvaluationDate': [''] ,
        'narrativeText':['']
      });
    this.getDropDownList();
  }
  getDropDownList() {
      this.spinnerFlag = true;
      this.httpService.getRecord('appealsFillingDropDown').subscribe(res => {
        if (res.global === 'successMsg@') {
          this.appealFilingsDropDown = res.data;
          this.spinnerFlag = false;
        } else {
          this.spinnerFlag = false;
        }

      }, error => {
      }); 
      this.spinnerFlag = true;
      this.httpService.getRecord('determinationsDropDown').subscribe(res => {
        if (res.global === 'successMsg@') {
          this.determinationsDropDown = res.data;
          this.spinnerFlag = false;
        } else {
          this.spinnerFlag = false;
        }

      }, error => {
      }); 
    }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  getAppealsInfo() {
    this.spinnerFlag = true;
    this.selectedRowData = []; 
    this.httpService.getRecord('viewAppeal?appealsId=' + this.appealsId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.selectedRowData = res.data;
        console.log(this.selectedRowData);
        this.clientsId = res.data.clientsId;
        this.evaluationId = res.data.evaluationId;
        this.appealType = res.data.appealType;
        if(res.data.appealNotesEntities!=null)
         this.appealNoteCount =  res.data.appealNotesEntities.length;      
       this.spinnerFlag = false;
       this.getresolutionDownList(res.data.appealType);
       this.resolutionTypeChange(res.data.resolutionsId);
        
      } else {
        this.spinnerFlag = false;
        this.errorFlag = true;
        this.errorMsg = res.inline;
      }

    }, error => {
      console.log(error);
    });
  }
  getresolutionDownList(appealType) {
      this.spinnerFlag = true; 
      //console.log(appealType);
      this.httpService.getRecord('resolutionsByappealTypeDropDown?appealType='+appealType).subscribe(res => {
          if (res.global === 'successMsg@') {
            this.resolutionsByappealTypeDropDown = res.data;
            this.spinnerFlag = false;
          } else {
            this.spinnerFlag = false;
          }

        }, error => {
        });
    }
  resolutionTypeChange(val) {
      val = Number(val);
     // if(this.selectedRowData.appealType == 1){
          if (val === 1) {
            this.appealsForm.controls['detreminationId'].enable();
            this.appealsForm.controls['reEvaluationDate'].enable();  
          } else { 
              this.appealsForm.controls['detreminationId'].disable();
              this.appealsForm.controls['reEvaluationDate'].disable();
          } 
      //}
    }
  viewAppealNotesModal(viewAppealNotes: TemplateRef<any>) {
    this.modalRef = this.modalService.show(viewAppealNotes);
  }
  gotoEvaulationDetail() {
      this.router.navigate(['/dashboard/evaluationdashboard/viewevaluation', this.selectedRowData.evaluationId]);
    }
  appealsSearchRouter() {
    this.router.navigate(['/dashboard/appealsdashboard']);
  }
   addAppealNotesSubmit() {
    this.addAppealNotesSuccess = false;
    this.addAppealNotesError = false;
    Object.keys(this.addAppealNotesForm.controls).forEach(field => {
      const control = this.addAppealNotesForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.addAppealNotesForm.valid) {
      this.data = this.addAppealNotesForm.value;
      this.data['appealsId'] = this.appealsId;
      this.httpService.addRecord('saveAppealNote', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.addAppealNotesSuccess = true;
          location.reload();
        } else {
          this.addAppealNotesError = true;
          this.spinnerFlag = false;
        }

      }, error => {
        console.log(error);
      });

    }
  }
  closeAppealNotesModal() {
    this.modalRef.hide();
  }
  closeNotification() {
    this.errorFlag = false;
  }
  
  saveAppeal() {
      console.log(this.appealsForm.value);
      Object.keys(this.appealsForm.controls).forEach(field => {
          const control = this.appealsForm.get(field);
          control.markAsTouched({ onlySelf: true });
        });

      if (this.appealsForm.valid) {
          this.data = {};
          this.spinnerFlag = true;
          this.data = this.appealsForm.value;  
          this.data['clientsId'] = this.clientsId;
          this.data['evaluationId'] = this.evaluationId;
          this.data['appealType'] = this.appealType;
          this.data['appealsId'] = this.appealsId;
          this.httpService.addRecord("saveAppeal",this.data).subscribe(res => {
            if (res.global === 'successMsg@') {
                this.spinnerFlag = false; 
                this.sucessMsg = res.inline;
                this.sucessFlag = true;
            } else {
              this.spinnerFlag = false;
              this.errorMsg = res.inline;
              this.errorFlag = true;
              window.scrollTo(0, 0);
            }
          }, error => {
        });
      }
      }
}
