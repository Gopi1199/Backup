import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AppealsDetailComponent } from './consumer-detail.component';

describe('AppealsDetailComponent', () => {
  let component: AppealsDetailComponent;
  let fixture: ComponentFixture<AppealsDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppealsDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppealsDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
