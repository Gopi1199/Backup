import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppealsRouting } from './appeals.routing';
import { ValidationService } from '../validation/validation.service';
import { HttpModule } from '@angular/http';
import { AppealsModuleComponent } from './appeals-module.component'; 
import { SearchAppealsComponent } from '../appeals-module/search-appeals/search-appeals.component';
import { AppealsDetailComponent } from './appeals-detail/appeals-detail.component'; 
import { TextMaskModule } from 'angular2-text-mask';
import { SharedModule } from '../SharedModule/shared.module'; 

@NgModule({
  declarations: [
    AppealsModuleComponent, 
    SearchAppealsComponent,
    AppealsDetailComponent 
  ],
  imports: [
    AppealsRouting,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    HttpModule,
    SharedModule,
    TextMaskModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [],
  bootstrap: []
})
export class AppealsModule { }
