import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appeals-module',
  templateUrl: './appeals-module.component.html',
  styleUrls: ['./appeals-module.component.css']
})
export class AppealsModuleComponent implements OnInit {

  constructor() { }
  ngOnInit() {
  }
}
