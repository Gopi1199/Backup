import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AppealsModuleComponent } from './consumer-module.component';

describe('AppealsModuleComponent', () => {
  let component: AppealsModuleComponent;
  let fixture: ComponentFixture<AppealsModuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppealsModuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppealsModuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
