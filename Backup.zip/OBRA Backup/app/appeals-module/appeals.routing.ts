import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppealsModuleComponent } from './appeals-module.component'; 
import { SearchAppealsComponent } from './search-appeals/search-appeals.component';
import { AppealsDetailComponent } from './appeals-detail/appeals-detail.component'; 

const routes: Routes = [
    { path: '', component: AppealsModuleComponent, pathMatch: 'full' },
    { path: 'appealsdashboard', pathMatch: 'full', component: AppealsModuleComponent },
    { path: 'appeals-search', pathMatch: 'full', component: SearchAppealsComponent }, 
    { path: 'appeals-detail/:id', pathMatch: 'full', component: AppealsDetailComponent },  
    { path: '**', redirectTo: 'dashboard', pathMatch: 'full' },
];
export const AppealsRouting: ModuleWithProviders = RouterModule.forChild(routes);
