import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchAppealsComponent } from './search-appeals.component';

describe('SearchAppealsComponent', () => {
  let component: SearchAppealsComponent;
  let fixture: ComponentFixture<SearchAppealsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchAppealsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchAppealsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
