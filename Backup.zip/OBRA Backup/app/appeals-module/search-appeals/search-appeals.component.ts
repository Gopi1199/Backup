import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MyDatePicker, IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { DateService } from '../../Service/date.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search-appeals',
  templateUrl: './search-appeals.component.html',
  styleUrls: ['./search-appeals.component.css']
})
export class SearchAppealsComponent implements OnInit {
  dataUrl: string;
  configUrl: string;
  searchInput: Object = {};
  private resetFlag: Boolean = false;
  private obj: any = [];
  private rolekeys: any;
  searchAppealsForm: any;
  private facilityTypeDropDownAll: any;
  private filter: any = { 'filters': {} };
  private data: Object;
  private selectedRowId: Number;
  private selectedRowData: any;
  private spinnerFlag =false;
  private sucessFlag: boolean;
  private sucessMsg: string;
  private errorFlag: boolean;
  private errorMsg: string;
  private emptyForm: boolean;
  mask: any[] = [/\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  datePlaceholder: string;
  private myDatePickerOptions: IMyDpOptions = {
    dateFormat: this.dateService.dateFormate(),
    editableDateField: true,
    openSelectorOnInputClick: true,
    disableSince: this.dateService.disableDate()
  };
  private model: Object = { date: { year: 2018, month: 10, day: 9 } };

  // DatePicker - Code End Here
  constructor(private router: Router, private Activatedroute: ActivatedRoute,private httpService: WebService,
    private formBuilder: FormBuilder, private dateService: DateService) {
    this.sucessFlag = false;
    this.errorFlag = false;
    this.emptyForm = false;
    this.datePlaceholder = 'Date Of Birth';
  }
  ngOnInit() {
    this.searchAppealsForm = this.formBuilder.group({
      'ssn': [''],
      'lastName': [''],
      'firstName': [''],
      'appealDate': [''],
      'preHearingDate': [''],
      'dateReceivedObra': [''],
      'adminHRDate': [''],
      'expirationDate': [''],
      'resolutionTypeStr': [''],
      'resolutionDate': [''],
      'appealStatus': [''],
      'facility': [''],
      'appealType': ['']
    });
    this.dataUrl = 'appealsSearch';
    this.configUrl = 'AppealsSearch.json';
    this.getDropDownList();
  }
  getDropDownList() {
      this.spinnerFlag = true;
      this.httpService.getRecord('facilitiesDropDown').subscribe(res => {
        if (res.global === 'successMsg@') {
          this.facilityTypeDropDownAll = res.data;
          this.spinnerFlag = false;
        } else {
          this.spinnerFlag = false;
        }

      }, error => {
      });
  
    }
  searchAppealsSubmit(event) {
    if (this.searchAppealsForm.value.ssn === '' && this.searchAppealsForm.value.lastName === '' &&
      this.searchAppealsForm.value.firstName === '' && !this.searchAppealsForm.value.appealDate
      && this.searchAppealsForm.value.medicaidNo === '') {
      this.sucessFlag = false;
      this.emptyForm = true;

    } else {
      this.searchAppealsForm.value.ssn = String(this.searchAppealsForm.value.ssn);
      this.searchAppealsForm.value.ssn = this.searchAppealsForm.value.ssn.replace(/\D+/g, '');
      this.emptyForm = false;
      this.resetFlag = false;
      this.obj = [];
      if (this.searchAppealsForm.value.appealDate instanceof Object) {
        const appealDate = this.searchAppealsForm.value.appealDate.formatted;
        this.searchAppealsForm.value.appealDate = appealDate;
      } else if (!this.searchAppealsForm.value.appealDate) {
        this.searchAppealsForm.value.appealDate = '';
      }
      this.rolekeys = Object.keys(this.searchAppealsForm.value);
      for (let i = 0; i < this.rolekeys.length; i++) {
        const jsonData: any = {};
        let j = this.rolekeys[i];
        j = j.replace(/"/g, '\\"');
        jsonData.id = this.rolekeys[i];
        jsonData.value = this.searchAppealsForm.value[j];
        this.obj.push(jsonData);
      }
      this.filter.filters = this.obj;
      this.getAppealsList();
    }
  }
 
  emptyFormClose() {
    this.emptyForm = false;
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.appealsId;
    this.router.navigate(['/dashboard/appealsdashboard/appeals-detail',this.selectedRowId]);
  }
  getMessage(data: any): void {
    if (data.global === 'successMsg@') {
      this.sucessFlag = true;
      this.errorFlag = false;
      this.sucessMsg = data.inline;
    } else if (data.global === 'errorMsg@') {
      this.errorFlag = true;
      this.sucessFlag = false;
      this.errorMsg = data.inline;
    }
  }
  getAppealsList() {
    if (this.resetFlag === true) {
      this.searchInput = {
        'search': JSON.stringify({})
      };
    } else {
      this.searchInput = {
        'search': JSON.stringify(this.filter)
      };
    }
  }
  consumerSearchReset() {
    this.searchAppealsForm.reset();
    this.resetFlag = true;
  }
  closeNotification(text) {
    if (text === 'success') {
      this.sucessFlag = false;
    } else if (text === 'error') {
      this.errorFlag = false;
    }
  }

}
