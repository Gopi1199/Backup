
import {
  OnInit, OnDestroy, Component, AfterViewInit
} from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ValidationService } from '../validation/validation.service';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../Service/webservice';
import { forkJoin } from 'rxjs/observable/forkJoin';
// import { ModalService } from '../Service/modal.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {
  mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  loginForm: FormGroup;
  userRegForm: FormGroup;
  loginFlag = true;
  UserRegFlag = false;
  regFlag = false;
  regSuccessFlag = false;
  regAccessDenied = false;
  private id;
  private sub;
  data: any;
  url: any;
  spinnerFlag: boolean = false;
  private UserRegFrmError: boolean = false;
  private firstNameError: boolean = false;
  private lastNameErrors: boolean = false;
  private userTypeErrors: boolean = false;
  private userRegistrationForm: any;
  private isActive: boolean = true;
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private str: any = '';
  private forkResponse: any;
  private qualificationsAll: any;
  private cmhBoardAll: any;
  private agenciesAll: any;

  itemList = [];
  selectedItems = [];
  settings = {};
  private chmBoardList: any;
  private agenciesList: any;
  qualificationList: any = [];
  private currentUser: any;

  constructor(private router: Router, private Activatedroute: ActivatedRoute, private builder: FormBuilder,
    private httpService: WebService,
    // private modalService: ModalService
  ) { }

  ngOnInit() {
    // this.currentUser = localStorage.getItem('currentUser');
    // if (this.currentUser !== null) {
    //   this.router.navigate(['dashboard']);
    // }
    this.sub = this.Activatedroute.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number
    });
    this.loginForm = this.builder.group({
      'username': new FormControl('')
    });
    this.userRegistrationForm = this.builder.group({
      'ssoUserID': ['ssoUserID'],
      'firstName': ['', Validators.required],
      'middleInitial': [''],
      'lastName': ['', Validators.required],
      'phoneNumber': [''],
      'email': ['', ValidationService.emailValidator],
      'userType': ['', Validators.required],
      'positionTitle': [{ value: '', disabled: true }],
      'cmhBoardsId': [{ value: '', disabled: true }],
      'newUserRegistration': [{ value: 'true' }],
      'agenciesId': [{ value: '', disabled: true }],
      'qualification': [{ value: '', disabled: true }]
    });

    this.loginForm = this.builder.group({
      'username': ['', Validators.required]
    });

  }

  ngOnDestroy() {
    this.spinnerFlag = false;
    this.sub.unsubscribe();
  }
  loginSubmit(event: any) {
    Object.keys(this.loginForm.controls).forEach(field => {
      const control = this.loginForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.loginForm.valid) {
      this.spinnerFlag = true;

      this.httpService.getRecord('login?userName=' + this.loginForm.value.username).subscribe(res => {
          localStorage.setItem('currentUser', this.loginForm.value.username);
          this.spinnerFlag = false;
          this.router.navigateByUrl('/dashboard');
      }, error => {
        this.spinnerFlag = false;
        this.loginFlag = false;
        localStorage.setItem('currentUser', '');
      });

    }
  }
  enableLogin() {
    this.UserRegFlag = false;
    this.loginForm = this.builder.group({
      'username': new FormControl('')
    });
    this.loginFlag = true;
  }
  UserSave(event: any) {
    event.preventDefault();

  }
  UserCancel() {
    this.UserRegFlag = false;
    this.regFlag = true;

  }
  UserRegFrmErrorClose() {
    this.UserRegFrmError = false;
  }
  // logout() {
  //   localStorage.removeItem('users');
  //   localStorage.removeItem('currentUser');
  //   localStorage.removeItem('userProfileId');
  //   this.loginFlag = true;
  //   this.UserRegFlag = false;
  //   this.regFlag = false;
  // }
}
