import {
  OnInit, OnDestroy, Component, AfterViewInit
} from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ValidationService } from '../validation/validation.service';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../Service/webservice';
import { forkJoin } from 'rxjs/observable/forkJoin';

@Component({
  selector: 'app-registration-link',
  templateUrl: './registration-link.component.html',
  styleUrls: ['./registration-link.component.css']
})
export class RegistrationLinkComponent implements OnInit {

  constructor(private router: Router, private Activatedroute: ActivatedRoute, private builder: FormBuilder,
    private httpService: WebService,
    // private modalService: ModalService
  ) { }

  ngOnInit() {
  }

  logout() {
    localStorage.removeItem('users');
    localStorage.removeItem('currentUser');
    localStorage.removeItem('userProfileId');
  }
  RegisterBtn() {
    localStorage.setItem('currentUser', '');
    this.router.navigateByUrl('/registration');
  }
}
