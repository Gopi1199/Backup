import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-assessment-form',
  templateUrl: './assessment-form.component.html',
  styleUrls: ['./assessment-form.component.css']
})
export class AssessmentFormComponent implements OnInit {
  private dataUrl: string;
  private configUrl: string;
  private searchInput: any;
  constructor() { }

  ngOnInit() {
    this.dataUrl = '';
    this.configUrl = 'Assessmentgrid.json';
    this.searchInput = {
      'search': ''
    };
  }

}
