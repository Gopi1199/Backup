import { Component,Input, OnChanges, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators, FormArray } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-sensorimotor-form',
  templateUrl: './sensorimotor.component.html',
  styleUrls: ['./sensorimotor.component.css']
})
export class SensorimotorComponent implements OnInit , OnChanges{
  private sensorimotorForm: FormGroup;
  public events: any[] = [];
  public myForm: FormGroup;
  public submitted: boolean;
  public digitalSighned = null;
  public rejection = false;
  public rejectionText;
  private maxlength: number;
  private countvalue: string;
  private notesMouseEvevtFlag: boolean;
  private notesMouseFlag: boolean;
  private characterleft: number;

  private characterleft1: number;
  limitCount: any;
  constructor(private formBuilder: FormBuilder) {
    this.maxlength = 4000;
    this.characterleft = this.maxlength;
    this.characterleft1 = this.maxlength;
    this.notesMouseEvevtFlag = false;
  }

  ngOnInit() {
    
      this.sensorimotorForm = this.formBuilder.group({
        'ambulationSkills': ['', Validators.required],
         'fineMotor': ['', Validators.required],
         'grossMotor': ['', Validators.required],
         'positioningNeeds': ['', Validators.required],
         'supportiveDevices': ['', Validators.required],
         'countdown': ['', Validators.required],
         
         'vocationalDevelopment': ['', Validators.required],
         'selfhelpDevelopment': ['', Validators.required],
         'socialDevelopment': ['', Validators.required],
         'recommendation': ['', Validators.required],
         'rejectionComments': ['ss'],
         'sig': ['', Validators.required]
      });
    
              const people = {
                'ambulationSkills': 'q',
                'fineMotor': 'q',
                'grossMotor': 'q',
                'positioningNeeds': 'q',
                'supportiveDevices': 'q',
                'vocationalDevelopment': 'q',
                'selfhelpDevelopment': 'q',
                'socialDevelopment': 'q',
                'recommendation': 'q',
                'rejectionComments': 'q',
                'sig': true
            };
            // (<FormGroup>this.sensorimotorForm)
            //     .setValue(people, { onlySelf: true });
    
      //(<FormControl>this.sensorimotorForm.controls['ambulationSkills'])
      //.setValue('Johnnnl', { onlySelf: true });
      //this.EditAgneciesModal();

      
    }
    ngOnChanges() {
    }
    sensorimotorFormSubmit(event: any) {
      Object.keys(this.sensorimotorForm.controls).forEach(field => {
        const control = this.sensorimotorForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      console.log(this.sensorimotorForm.valid + JSON.stringify(this.sensorimotorForm.value));
           if (this.sensorimotorForm.valid) {
            this.sensorimotorForm.disable();
            this.digitalSighned = {
      userSign: 's,s,s,s,s,s',
      counterSign: 's,s,s,s,s,s'
    };
         console.log('psychiatricForm' + (JSON.stringify(this.sensorimotorForm.value)));
       }
    }
    rejectionComments(event: any) {
      console.log('Event name is ' + event);
      this.rejection = true;
      if (this.rejectionText !== undefined) {
        console.log(this.rejectionText);
        console.log('psychiatricForm' + (JSON.stringify(this.sensorimotorForm.value)));
      }
    }
    reset() {
      this.sensorimotorForm.reset();
    }


    limitText(limitField,  limitNum) {
      
      if (limitField.length > limitNum) {
        limitField.value = limitField.value.substring(0, limitNum);
      } else {
        this.limitCount = limitNum - limitField.length;
        console.log(this.limitCount);
        return this.limitCount;
       
        
      }
    }



    
    countfineMotor(msg) {
      console.log(this.sensorimotorForm.value);

        this.characterleft1 = (this.maxlength) - (msg.length);  
         }          
         
  
    printfunction() {
      window.print();
  }
}
