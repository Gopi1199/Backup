import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SensorimotorComponent } from './sensorimotor.component';

describe('SensorimotorComponent', () => {
  let component: SensorimotorComponent;
  let fixture: ComponentFixture<SensorimotorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SensorimotorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SensorimotorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
