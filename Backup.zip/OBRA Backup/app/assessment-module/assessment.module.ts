import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { assessmentRoutes } from './assessment.routing';
import { ValidationService } from '../validation/validation.service';
import { HttpModule } from '@angular/http';
import { AssessmentComponent } from './assessment.component';
import { AssessmentFormComponent } from './assessment-form/assessment-form.component';
import { PsychosocialComponent } from './psychosocial/psychosocial.component';
import { SensorimotorComponent } from './sensorimotor/sensorimotor.component';
import { FormWizardModule } from 'angular2-wizard';
import { SharedModule } from '../SharedModule/shared.module';

@NgModule({
    imports: [
        assessmentRoutes,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        HttpModule,
        SharedModule,
        FormWizardModule
    ],
    declarations: [
        AssessmentComponent,
        AssessmentFormComponent,
        PsychosocialComponent,
        SensorimotorComponent
    ],
    providers: [ValidationService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AssessmentModule {

}
