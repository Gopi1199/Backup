import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssessmentComponent } from './assessment.component';
import { AssessmentFormComponent } from './assessment-form/assessment-form.component';
import { PsychosocialComponent } from './psychosocial/psychosocial.component';
import { SensorimotorComponent } from './sensorimotor/sensorimotor.component';
const routes: Routes = [
    { path: '', component: AssessmentComponent, pathMatch: 'full' },
    { path: 'assessmentDashboard', pathMatch: 'full', component: AssessmentFormComponent },
    { path: 'assessmentForm', pathMatch: 'full', component: AssessmentFormComponent },
    { path: 'psychosocial', pathMatch: 'full', component: PsychosocialComponent },
    { path: 'sensorimotor', pathMatch: 'full', component: SensorimotorComponent },
    { path: '**', redirectTo: 'dashboard', pathMatch: 'full' }
];

export const assessmentRoutes: ModuleWithProviders = RouterModule.forChild(routes);