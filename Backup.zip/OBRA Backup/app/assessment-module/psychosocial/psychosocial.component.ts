import { Component,Input, OnChanges, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators, ReactiveFormsModule, FormsModule, FormArray } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Psychosocialmodel } from './psychosocialmodel';
import { Console } from '@angular/core/src/console';

@Component({
  selector: 'app-psychosocial-form',
  templateUrl: './psychosocial.component.html',
  styleUrls: ['./psychosocial.component.css']
})
export class PsychosocialComponent implements OnInit {
  private psychosocialForm: FormGroup;
  private digitalSighned = null;
  public counter : number = 0;
  section: string[];
  addBorder: boolean = false; 
  addordeletevalidation = null;
  sections: string[];
  selectedIndex: number;
  indexvalue: number;
  psychosocialmodels: Array<Psychosocialmodel>;
  navigateSection: any;
  index: any;
  erroredit = false;
  checked = false;
  section1 = false;
  section2 = false;
  section3 = false;
  public saveform:boolean = false;
  public edited = false;
  constructor(private formBuilder: FormBuilder, private router: Router,private activeRoute: ActivatedRoute) {
        this.psychosocialmodels = [
      {behaviour: '', frequency: '', intensity: '', intervention: '', outcome: ''}
    ];
    this.section = ["section1", "section2","section3"];
   }

  ngOnInit() {
    this.psychosocialForm = this.formBuilder.group({
      'presentingProblems': ['', Validators.required],
      'subjectiveEvaluation': ['', Validators.required],
      'legalRepContacted': ['', Validators.required],
      'objectiveEvalExplain': ['', Validators.required],
      'objectiveEval': ['', Validators.required],
      'presentingProblemHistory': ['', Validators.required],
      'recentMhServices': ['', Validators.required],
      'psychosocialHistory': ['', Validators.required],
      'currentLiving': ['', Validators.required],
      'returnCurrResidence': ['', Validators.required],
      'cmhFunded': ['', Validators.required],
      'cmhFundedType': [''],
      'priorLiving': ['', Validators.required],
      'suicidal': ['', Validators.required],
      'suicidalHomicidalExplain': [''],
      'homicidal': [''],
      'homicidalExplain': [''],
      'substanceAbuse': ['', Validators.required],
      'affectiveDevelopment': ['', Validators.required],
      'cognitiveAbilities': ['', Validators.required],
      'strengthsResources': ['', Validators.required],
      'understands': ['', Validators.required],
      'simpleDirections': ['', Validators.required],
      'yesNoResponse': ['', Validators.required],
      'immediateNeeds': ['', Validators.required],
      'simpleQuestions': ['', Validators.required],
      'personalExp': ['', Validators.required],
      'receptiveLanguage': ['', Validators.required],
      'expressiveLanguage': ['', Validators.required],
      'nonOralComm': ['', Validators.required],
      'specialComm': ['', Validators.required],
      'recommendations': ['',Validators.required],
      'exceedNfCapacity': ['', Validators.required],
      'exceedNfExplain': [''],
      'psychiatricHospitalization': ['', Validators.required],
      'psychiatricExplanation': [''],
      'sig': ['', Validators.required]
    });
    const tempData = {
      affectiveDevelopment: 'g', cmhFunded: 'Y', cmhFundedType: 't', cognitiveAbilities: 'gh', currentLiving: 't',
exceedNfCapacity: 'Y', exceedNfExplain: 'sdfg', expressiveLanguage: ' b', homicidal: 'N', homicidalExplain: 't',
legalRepContacted: 'Y', nonOralComm: ' b', objectiveEval: 't', objectiveEvalExplain: 'tt', personalExp: 'N',
presentingProblemHistory: 't', presentingProblems: 't', priorLiving: 't', psychiatricExplanation: 'gsdfsdf',
psychiatricHospitalization: 'Y', psychosocialHistory: 't', recentMhServices: 't', receptiveLanguage: ' b',
recommendations: 'xdf', returnCurrResidence: 'N', sig: '', simpleDirections: 'N', simpleQuestions: 'N',
specialComm: 'b', strengthsResources: '', subjectiveEvaluation: 't', substanceAbuse: 'y', suicidal: 'Y',
suicidalHomicidalExplain: 't', understands: 'Y', yesNoResponse: 'Y', immediateNeeds: 'Y'};

//(<FormGroup> this.psychosocialForm).setValue(tempData, { onlySelf: true });

    this.psychosocialForm.get('suicidal').valueChanges.subscribe(
    (suicidal: string) => {
        if (suicidal === 'Y') {
            this.psychosocialForm.get('suicidalHomicidalExplain').setValidators([Validators.required]);
        } else if (suicidal === 'N') {
            this.psychosocialForm.get('suicidalHomicidalExplain').setValidators([]);
        }
        this.psychosocialForm.get('suicidalHomicidalExplain').updateValueAndValidity();
    }
);
    this.psychosocialForm.get('homicidal').valueChanges.subscribe(
    (homicidal: string) => {
        if (homicidal === 'Y') {
            this.psychosocialForm.get('homicidalExplain').setValidators([Validators.required]);
        } else if (homicidal === 'N') {
            this.psychosocialForm.get('homicidalExplain').setValidators([]);
        }
        this.psychosocialForm.get('homicidalExplain').updateValueAndValidity();
    }
  );



/*16th feb start*/
this.psychosocialForm.get('cmhFunded').valueChanges.subscribe(
    (cmhFunded: string) => {
        if (cmhFunded === 'Y') {
            this.psychosocialForm.get('cmhFundedType').setValidators([Validators.required]);
        } else if (cmhFunded === 'N') {
            this.psychosocialForm.get('cmhFundedType').setValidators([]);
        }
        this.psychosocialForm.get('cmhFundedType').updateValueAndValidity();
    }
  );
  /*16th feb End*/


    this.psychosocialForm.get('exceedNfCapacity').valueChanges.subscribe(
    (exceedNfCapacity: string) => {
        if (exceedNfCapacity === 'Y') {
            this.psychosocialForm.get('exceedNfExplain').setValidators([Validators.required]);
        } else if (exceedNfCapacity === 'N') {
            this.psychosocialForm.get('exceedNfExplain').setValidators([]);
        }
        this.psychosocialForm.get('exceedNfExplain').updateValueAndValidity();
    }
  );
    this.psychosocialForm.get('psychiatricHospitalization').valueChanges.subscribe(
    (psychiatricHospitalization: string) => {
        if (psychiatricHospitalization === 'Y') {
            this.psychosocialForm.get('psychiatricExplanation').setValidators([Validators.required]);
        } else if (psychiatricHospitalization === 'N') {
            this.psychosocialForm.get('psychiatricExplanation').setValidators([]);
        }
        this.psychosocialForm.get('psychiatricExplanation').updateValueAndValidity();
    }
  );
}
newRow(psychologicalTest) {
  let behaviour, frequency, intensity, intervention, outcome;
  let psychosocialmodels = new Psychosocialmodel(behaviour, frequency, intensity, intervention, outcome);   
   this.psychosocialmodels.push(psychosocialmodels);  
}

removeContact(psychologicalTest) {

  this.index = this.psychosocialmodels.indexOf(psychologicalTest);
  if (this.psychosocialmodels.length !== 1) {
    this.psychosocialmodels.splice(this.index, 1);
  }else {
    return false;
  } 
}
psychosocialFormSubmit(event: Event) {
   
    if(this.psychosocialForm.value.sig !=''){
        Object.keys(this.psychosocialForm.controls).forEach(field => {
            const control = this.psychosocialForm.get(field);
            control.markAsTouched({ onlySelf: true });
        });
       
        this.checked = false;
    }
    else
    {
        this.checked = true;
    }

   /* this.edited = true;
    setTimeout(function() {
        this.edited = false;
    }.bind(this), 4000);*/
} 

/*15th feb start */
psychosocialFormSubmitSection1(event: Event){
   
    this.section1=false; 
    if(this.psychosocialForm.value.presentingProblems!='' && this.psychosocialForm.value.subjectiveEvaluation!='' &&
    this.psychosocialForm.value.legalRepContacted!='' && this.psychosocialForm.value.objectiveEvalExplain!='' &&
    this.psychosocialForm.value.objectiveEval!='' && this.psychosocialForm.value.presentingProblemHistory!='' &&
    this.psychosocialForm.value.recentMhServices!='' && this.psychosocialForm.value.psychosocialHistory!='' &&
    this.psychosocialForm.value.currentLiving!='' && this.psychosocialForm.value.returnCurrResidence!='')
    { 
        this.section1=true;        
    }
   
   else
    {
        this.section1=false;       
    }
}
/*15th feb end*/

/*16th feb Start*/
psychosocialFormSubmitSection2(event: Event){

    this.section2=false; 
    if(this.psychosocialForm.value.cmhFunded!='' && this.psychosocialForm.value.priorLiving!='' &&
      this.psychosocialForm.value.suicidal!='' && this.psychosocialForm.value.homicidal!='' && 
      this.psychosocialForm.value.substanceAbuse!='' && this.psychosocialForm.value.affectiveDevelopment!='' && 
      this.psychosocialForm.value.cognitiveAbilities!=''
    )
     {
        this.section2=true;
        if(this.psychosocialForm.value.cmhFunded=='Y')
        { 
            if(this.psychosocialForm.value.cmhFundedType!='')
            {
                this.section2=true;                
            }
            else
            {
                this.section2=false;            
            }            
        }
        if(this.psychosocialForm.value.suicidal=='Y')
        {
            if(this.psychosocialForm.value.suicidalHomicidalExplain!='')
            {
                this.section2=true;                
            }
            else
            {
                this.section2=false;                
            }            
        }
        if(this.psychosocialForm.value.homicidal=='Y')
        {
            if(this.psychosocialForm.value.homicidalExplain!='')
            {
                this.section2=true;                
            }
            else
            {
                this.section2=false;               
            }    
        }
      
     }
    else
    {
        this.section2=false;
        console.log("Record empty section 2 cmhFunded=>"+this.psychosocialForm.value.cmhFunded);
        console.log("Record empty section 2=> suicidal "+this.psychosocialForm.value.suicidal);
        console.log("Record empty section 2 homicidal=>"+this.psychosocialForm.value.homicidal);
        
    }
}

psychosocialFormSubmitSection3(event: Event){

    this.section3=false;
    if(this.psychosocialForm.value.strengthsResources!='' && this.psychosocialForm.value.understands!='' &&
      this.psychosocialForm.value.simpleDirections!='' && this.psychosocialForm.value.yesNoResponse!='' && 
      this.psychosocialForm.value.immediateNeeds!='' && this.psychosocialForm.value.simpleQuestions!='' && 
      this.psychosocialForm.value.personalExp!='' && this.psychosocialForm.value.receptiveLanguage!='' &&
      this.psychosocialForm.value.expressiveLanguage!='' && this.psychosocialForm.value.nonOralComm!='' &&
      this.psychosocialForm.value.specialComm!='' && this.psychosocialForm.value.recommendations!='' && 
      this.psychosocialForm.value.exceedNfCapacity!='' && this.psychosocialForm.value.psychiatricHospitalization!='' )
      {
        this.section3=true;
        console.log("Record not empty section 3 exceedNfCapacity =>" + this.psychosocialForm.value.exceedNfCapacity);
        console.log("Record not empty section 3 psychiatricHospitalization =>" + this.psychosocialForm.value.psychiatricHospitalization);
        if(this.psychosocialForm.value.exceedNfCapacity=='Y')
        {
            if(this.psychosocialForm.value.exceedNfExplain!='')
            {
                this.section3=true;               
            }
            else
            {
                this.section3=false;               
            }            
        }
        if(this.psychosocialForm.value.psychiatricHospitalization=='Y')
        {
            if(this.psychosocialForm.value.psychiatricExplanation!='')
            {
                this.section3=true;               
            }
            else
            {
                this.section3=false;                
            }    
        } 
      }
      else
      {
        this.section3=false;
      }
}

/*16th  feb End */

mseenter(psychologicalTest){
    this.index = this.psychosocialmodels.indexOf(psychologicalTest);
    let element = document.getElementsByClassName('pshychomodal_input'+ this.index);
    for(var i = 0; i < element.length; i++)
    {
          element[i].classList.add('error_border');
        
    }    
   }
mseleave(psychologicalTest){
      this.index = this.psychosocialmodels.indexOf(psychologicalTest);
    let element = document.getElementsByClassName('pshychomodal_input'+ this.index);
     for(var i = 0; i < element.length; i++)
     {
         element[i].classList.remove('error_border');
     }        
   }

 printfunction() {
    window.print();
}

/*15th Feb 2018 start*/

cancelPsychosocialFrom() {
   
      this.router.navigate(['/dashboard/assessmentDashboard']);
  }

/*15th feb 2018 end*/
}
