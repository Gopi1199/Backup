import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PsychosocialComponent } from './psychosocial.component';

describe('PsychosocialFormComponent', () => {
  let component: PsychosocialComponent;
  let fixture: ComponentFixture<PsychosocialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PsychosocialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PsychosocialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
