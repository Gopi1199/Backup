export class Psychosocialmodel {

    behaviour: string;
    frequency: string;
    intensity: string;
    intervention: string;
    outcome: string;

    constructor(behaviour, frequency, intensity, intervention, outcome) {
        this.behaviour = '';
        this.frequency = '';
        this.intensity = '';
        this.intervention = '';
        this.outcome = '';
    }
}
