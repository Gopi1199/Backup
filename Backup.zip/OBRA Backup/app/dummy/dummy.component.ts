import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dummy',
  templateUrl: './dummy.component.html',
  styleUrls: ['./dummy.component.css']
})
export class DummyComponent implements OnInit {
  dataUrl: string;
  configUrl: string;

  customColumns: any = {
    'columns': [
      {
        'columnName': 'Delete',
        'columnTemplate': 'deleteButton',
        'model': ''
      },
      {
        'columnName': 'Save',
        'columnTemplate': 'saveButton',
        'model': ''
      }
    ]
  };

  constructor() {
    this.dataUrl = 'agenciesList';
    this.configUrl = 'AgenciesGrid.json';
  }

  ngOnInit() {
  }

  buttonClicked(event: any, row: any) {
    console.log(row);
  }
}
