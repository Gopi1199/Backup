import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { WebService } from '../../Service/webservice';
import { MyDatePicker, IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { DateService } from '../../Service/date.service';
import { ModalService } from '../../Service/modal.service';
import { dateFormat } from '../../JSON';

@Component({
  selector: 'app-add-edit-consumer',
  templateUrl: './add-edit-consumer.component.html',
  styleUrls: ['./add-edit-consumer.component.css']
})
export class AddEditConsumerComponent implements OnInit {
  private addEditConsumerForm: any;
  private clientId: number;
  private sub: any;
  private consumerDetails: any;
  private dischargeDropDownAll: any;
  private terminationTypeDropDown: any;
  private selectedRowData: any;
  private spinnerFlag: Boolean = false;
  private addClient: Boolean = true;
  private editClient: Boolean = false;
  private addressHist: Boolean = true;
  private createLegalRepFlag: Boolean = false;
  private addConsumerFlag: any;
  private data: any;
  private dateFormat: any;
  private screenTitle: String;
  private ssnValidateUrl: String;
  ssnMask: any[] = [/\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  phoneMask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  private maxlength: number;
  private clientNotes: string;
  private notesMouseEvevtFlag: boolean;
  private isActive: boolean;
  private isSpecial: boolean;
  private characterleft: number;
  // private sampeFormat: Object = { date: { year: 2018, month: 10, day: 9 } };
  private dateOfBirth: Object = {};
  private terminationDate: Object = {};
  private sucessFlag: Boolean = false;
  private errorFlag: Boolean = false;
  private sucessMsg: String = '';
  private errorMsg: String = '';
  private method: any;
  private createEvalFlag = false;
  private myDatePickerOptions: IMyDpOptions = {
    dateFormat: this.dateService.dateFormate(),
    editableDateField: false,
    openSelectorOnInputClick: true,
    disableSince: this.dateService.disableDate()
  };

  constructor(private dateService: DateService, private router: Router, private httpService: WebService,
    private activeRoute: ActivatedRoute, private builder: FormBuilder, private modalService: ModalService) {
    this.maxlength = 4000;
    this.characterleft = this.maxlength;
    this.clientNotes = '';
    this.notesMouseEvevtFlag = false;
    this.dateFormat = dateFormat;
  }

  ngOnInit() {
    this.selectedRowData = {
      'ssn': '',
      'firstName': '',
      'middleInitial': '',
      'lastName': '',
      'suffix': '',
      'dateOfBirth': '',
      'gender': '',
      'addressLine1': '',
      'addressLine2': '',
      'city': '',
      'stateId': '',
      'zipCode1': '',
      'zipCode2': '',
      'phoneNumber': '',
      'email': '',
      'terminationTypesId': '',
      'terminationDate': '',
      'dischargesId': '',
      'medicaidNo': '',
      'tracking': '',
      'addressActiveFlg': '',
      'clientNotes': ''
    };
    this.selectedRowData = {
      'address': { addressLine1: '', addressLine2: '', city: '', stateId: '', zipCode1: '', zipCode2: '' }
    };
    this.addEditConsumerForm = this.builder.group({
      'ssn': ['', Validators.required],
      'firstName': ['', Validators.required],
      'middleInitial': [''],
      'lastName': ['', Validators.required],
      'suffix': [''],
      'dateOfBirth': ['', Validators.required],
      'gender': ['', Validators.required],
      'addressLine1': ['', Validators.required],
      'addressLine2': [''],
      'city': ['', Validators.required],
      'stateId': ['', Validators.required],
      'zipCode1': ['', [Validators.required, ValidationService.zipCodeValidator]],
      'zipCode2': ['', ValidationService.zipCodeValidator],
      'phoneNumber': [''],
      'email': ['', ValidationService.emailValidator],
      'terminationTypesId': ['', Validators.required],
      'terminationDate': [''],
      'dischargesId': [{ value: '', disabled: true }],
      'medicaidNo': [''],
      'tracking': [''],
      'addressActiveFlg': [''],
      'clientNotes': ['']
    });

    this.sub = this.activeRoute.params.subscribe(params => {
      this.method = params['addEdit'];
      if (this.method === 'edit') {
        this.clientId = params['id'];
        this.addClient = false;
        this.editClient = true;
        this.getConsumerInfo();
        this.screenTitle = 'Edit Consumer';
      } else if (this.method === 'add') {
        if (params['id']) {
          this.selectedRowData.ssn = params['id'];
        } else {
          this.selectedRowData.ssn = '';
        }
        this.spinnerFlag = true;
        this.addClient = true;
        this.dateOfBirth = '';
        this.screenTitle = 'Add Consumer';
        this.getDropDownLis();
      }
    });
  }
  count(msg) {
    if (this.maxlength >= msg.length) {
      this.characterleft = (this.maxlength) - (msg.length);
    } else {
      this.clientNotes = msg.substr(0, msg.length - 1);
      // console.log(msg);
    }
  }
  mouseenter() {
    this.count(this.clientNotes);
    this.notesMouseEvevtFlag = true;
  }
  mouseleave() {
    this.count(this.clientNotes);
    this.notesMouseEvevtFlag = false;
  }
  getConsumerInfo() {
    this.spinnerFlag = true;
    this.selectedRowData['clientLegalRepViews'] = [];
    this.httpService.getRecord('viewClient?clientId=' + this.clientId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.selectedRowData = res.data;
        if (this.selectedRowData['dateOfBirth'] != null) {
          const dob: any = this.selectedRowData['dateOfBirth'].split('/');
          this.dateOfBirth = { date: { year: Number(dob[2]), month: Number(dob[0]), day: Number(dob[1]) } };
          this.selectedRowData['dateOfBirth'] = this.dateOfBirth;
        }
        if (this.selectedRowData['terminationDate'] != null) {
          const terminationDate: any = this.selectedRowData['terminationDate'].split('/');
          this.terminationDate = {
            date: {
              year: Number(terminationDate[2]), month: Number(terminationDate[0]),
              day: Number(terminationDate[1])
            }
          };
          this.selectedRowData['terminationDate'] = this.terminationDate;
        }
        if (this.selectedRowData['address'] == null) {
          this.selectedRowData['address'] = { addressLine1: '', addressLine2: '', city: '', stateId: '', zipCode1: '', zipCode2: '' };
          this.addressHist = false;
        }
        if (Number(this.selectedRowData.terminationTypesId) === 4) {
          this.addEditConsumerForm.controls['dischargesId'].reset({ value: '', disabled: false });
        }
        this.spinnerFlag = false;
      } else {
        this.spinnerFlag = false;
      }

    }, error => {
    });

    this.getDropDownLis();
  }

  getDropDownLis() {
    this.spinnerFlag = true;
    this.httpService.getRecord('dischargeTypeDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.dischargeDropDownAll = res.data;
        this.spinnerFlag = false;
      } else {
        this.spinnerFlag = false;
      }

    }, error => {
    });
    this.spinnerFlag = true;
    this.httpService.getRecord('terminationTypeDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.terminationTypeDropDown = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
  }

  gotoConsumerDetail() {
    this.router.navigate(['/dashboard/consumer-dashboard/consumer-detail', this.clientId]);
  }

  gotoConsumerDashboard() {
    this.router.navigate(['/dashboard/consumer-dashboard']);
  }

  addEditConsumerSubmit() {




   console.log('Hi');

    Object.keys(this.addEditConsumerForm.controls).forEach(field => {
      const control = this.addEditConsumerForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });

    if (this.editClient && !this.addEditConsumerForm.dirty) {
      this.errorFlag = true;
      this.errorMsg = 'Fill necessary changes before going to save';
      window.scrollTo(0, 0);
      return false;
    }

    if (this.addEditConsumerForm.valid) {

      this.data = {};
      this.spinnerFlag = true;
      this.data = this.addEditConsumerForm.value;
      this.data.ssn = String(this.data.ssn);
      this.data.ssn = this.data.ssn.replace(/\D+/g, '');
      this.data.phoneNumber = String(this.data.phoneNumber);
      this.data.phoneNumber = this.data.phoneNumber.replace(/\D+/g, '');
      this.data.status = 'Y';

      if (typeof this.data.terminationDate !== 'object') {
        const dob: any = this.data.dateOfBirth.formatted.split('/');
        this.data.dateOfBirth = dob[1] + '/' + dob[0] + '/' + dob[2];
      } else if (Object.keys(this.data.dateOfBirth).length !== 0 ) {
         this.data.dateOfBirth = this.data.dateOfBirth.date.month + '/' + this.data.dateOfBirth.date.day + '/' 
         + this.data.dateOfBirth.date.year;
      } else {
        this.data.dateOfBirth = '';
      }

      if (typeof this.data.terminationDate !== 'object') {
        const terminationDate: any = this.data.terminationDate.formatted.split('/');
        this.data.terminationDate = terminationDate[1] + '/' + terminationDate[0] + '/' + terminationDate[2];
      } else if (Object.keys(this.data.terminationDate).length !== 0 ) {
        this.data.terminationDate = this.data.terminationDate.date.month + '/' + this.data.terminationDate.date.day 
        + '/' + this.data.terminationDate.date.year;
      } else {
        this.data.terminationDate = '';
      }

      if (this.editClient === true) {
        this.ssnValidateUrl = 'duplicateSSN?ssn=' + this.data.ssn + '&clientId=' + this.clientId;
        this.data['clientsId'] = this.clientId;
        delete this.data['clientNotes'];
      } else {
        this.ssnValidateUrl = 'duplicateSSN?ssn=' + this.data.ssn + '&clientId=';
        this.data.clientNotes = [{
          'notes': this.data.clientNotes
        }];
      }

      this.data.address = {
        'addressLine1': this.data.addressLine1,
        'addressLine2': this.data.addressLine2,
        'city': this.data.city,
        'stateId': this.data.stateId,
        'zipCode1': this.data.zipCode1,
        'zipCode2': this.data.zipCode2
      };

      delete this.data['addressLine1'];
      delete this.data['addressLine2'];
      delete this.data['city'];
      delete this.data['stateId'];
      delete this.data['zipCode1'];
      delete this.data['zipCode2'];

      this.httpService.getRecord(this.ssnValidateUrl).subscribe(res => {
        if (res.global === 'successMsg@') {
            this.spinnerFlag = false;
             this.addEditConsumer();
        } else {
          this.spinnerFlag = false;
          this.errorMsg = res.inline;
          this.errorFlag = true;
          window.scrollTo(0, 0);
        }
      }, error => {
    });
  }
  }

  addEditConsumer() {
    this.spinnerFlag = true;
    this.httpService.addRecord('addConsumer', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.addConsumerFlag = true;
        this.sucessMsg = res.inline;
        this.sucessFlag = true;
        if (this.createLegalRepFlag) {
          this.router.navigate(['/dashboard/consumer-dashboard/addeditlegalrep', res.data.clientsId]);
        } else if (this.createEvalFlag) {
          this.router.navigate(['/dashboard/evaluationdashboard/createevaluation', res.data.clientsId]);
        } else {
          this.router.navigate(['/dashboard/consumer-dashboard/consumer-detail', res.data.clientsId]);
        }
      } else {
        this.spinnerFlag = false;
        this.errorMsg = res.inline;
        this.errorFlag = true;
        window.scrollTo(0, 0);
      }

    }, error => {
    });
  }
  resetLegalRepForm() {
    if (this.editClient) {
      this.getConsumerInfo();
    } else {
      this.addEditConsumerForm.reset();
    }
  }
  cancelLegalRepForm() {
    if (this.editClient) {
      this.router.navigate(['/dashboard/consumer-dashboard/consumer-detail', this.clientId]);
    } else {
      this.router.navigate(['/dashboard/consumer-dashboard']);
    }
  }
  changeConsumerStatus(statusCode) {
    if (Number(statusCode) === 4) {
      this.addEditConsumerForm.controls['dischargesId'].reset({ value: '', disabled: false });
    }
  }
  closeNotification(text) {
    if (text === 'success') {
      this.sucessFlag = false;
    } else if (text === 'error') {
      this.errorFlag = false;
    }
  }
  saveAndCreateLegal() {
    this.addEditConsumerSubmit();
    this.createLegalRepFlag = true;
  }
  saveAndCreateEval() {
    this.addEditConsumerSubmit();
    this.createEvalFlag = true;
    // this.router.navigate(['/dashboard/evaluationdashboard/createevaluation']);
  }
  onClick() {
    event.preventDefault();
    this.isActive = !this.isActive;
    this.isSpecial = !this.isSpecial;
    // event.stopPropagation();
    console.log(this.isActive);
    /* if (this.isActive == false) {
     this.addEditConsumerForm.addControl('addressLine1', new FormControl("", Validators.required));
      this.addEditConsumerForm.addControl('city', new FormControl("", Validators.required));
      this.addEditConsumerForm.addControl('stateId', new FormControl("", Validators.required));
      this.addEditConsumerForm.addControl('zipCode1', new FormControl("", Validators.required));
      alert("test if" + this.addEditConsumerForm.addControl('addressLine1', new FormControl("", Validators.required)));
    } else {
      this.addEditConsumerForm.addControl('addressLine1', new FormControl(""));
      this.addEditConsumerForm.addControl('city', new FormControl(""));
      this.addEditConsumerForm.addControl('stateId', new FormControl(""));
      this.addEditConsumerForm.addControl('zipCode1', new FormControl(""));
      alert("test else" +this.addEditConsumerForm.addControl('addressLine1', new FormControl("")));
    } */
  }
}
