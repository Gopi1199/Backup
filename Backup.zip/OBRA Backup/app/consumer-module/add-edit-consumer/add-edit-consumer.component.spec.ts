import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AddEditConsumerComponent } from './add-edit-consumer.component';

describe('AddEditConsumerComponent', () => {
  let component: AddEditConsumerComponent;
  let fixture: ComponentFixture<AddEditConsumerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddEditConsumerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditConsumerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
