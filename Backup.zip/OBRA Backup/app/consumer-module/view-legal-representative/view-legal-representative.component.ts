import { Component, OnInit, Input, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ValidationService } from '../../validation/validation.service';
@Component({
  selector: 'app-view-legal-representative',
  templateUrl: './view-legal-representative.component.html',
  styleUrls: ['./view-legal-representative.component.css']
})
export class ViewLegalRepresentativeComponent implements OnInit {
  private selectedRowData: any;
  private spinnerFlag: boolean;
  private legalRepId: number;
  private clientsId: number;
  private relationShipId: number;
  private Ids: number;
  private sub: any;
  private leaglRepStatus: Boolean;
  private relationshipDropDown: any;
  private linkLegalRefForm: any;
  @Input() modalRef: any;
  constructor(private activeRoute: ActivatedRoute, private httpService: WebService, private router: Router,
    private modalService: BsModalService, private builder: FormBuilder) {
    this.spinnerFlag = false;
    // this.selectedRowData=
  }

  ngOnInit() {

    this.selectedRowData = {
      'companyName': '',
      'addressLine1': '',
      'addressLine2': '',
      'city': '',
      'stateName': '',
      'zipCode1': '',
      'zipCode2': '',
      'stateId': '',
      'phoneNumber': ''

    };
    this.sub = this.activeRoute.params.subscribe(params => {
      this.legalRepId = Number(params['legalRepId']);
      this.clientsId = Number(params['clientId']);
      this.getConsumerInfo();
    });

    this.linkLegalRefForm = this.builder.group({
      'relationship': ['', Validators.required]

    });
  }
  getConsumerInfo() {
    this.spinnerFlag = true;
    this.selectedRowData = [];
    // console.log(this.legalRepId + this.clientsId);
    this.httpService.getRecord('viewLegalRep?legalRepId=' + this.legalRepId + '&clientsId=' + this.clientsId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.selectedRowData = res.data;
        this.relationShipId = res.data.relationshipId;
        this.leaglRepStatus = res.data.linked;
        // this.leaglRepStatus = 'I';
        this.spinnerFlag = false;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
  }
  closeRelationshipModal() {
    this.modalRef.hide();
  }
  linkLegalRefSubmit() {
    this.spinnerFlag = true;
    this.httpService.getRecord('linkLegalRep?clientsId=' + this.clientsId + '&legalRepId=' + this.legalRepId +
    '&relationShipId=' + this.linkLegalRefForm.value.relationship).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.modalRef.hide();
        this.router.navigate(['/dashboard/consumer-dashboard/consumer-detail', this.clientsId]);
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
  }
  reinkConsumerModal(reinkConsumer: TemplateRef<any>) {
    this.spinnerFlag = true;
    this.httpService.getRecord('relationshipDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.relationshipDropDown = res.data;
        this.spinnerFlag = false;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      this.spinnerFlag = false;
    });
    this.modalRef = this.modalService.show(reinkConsumer);
  }
  consumerDetails() {
    this.router.navigate(['/dashboard/consumer-dashboard/consumer-detail', this.clientsId]);
  }
  editLegalRepRouter() {
    this.router.navigate(['/dashboard/consumer-dashboard/addeditlegalrep', this.clientsId, this.legalRepId]);
  }
  ViewHistroy() {
    this.router.navigate(['/dashboard/consumer-dashboard/legalrephistroy', this.clientsId, this.legalRepId]);
   
  }
  UnLinkConsumer() {
    this.spinnerFlag = true;
    this.httpService.getRecord('unLinkLegalRep?clientsId=' + this.clientsId + '&legalRepId=' + this.legalRepId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.router.navigate(['/dashboard/consumer-dashboard/consumer-detail', this.clientsId]);
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });
  }

}
