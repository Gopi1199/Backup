import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewLegalRepresentativeComponent } from './view-legal-representative.component';

describe('ViewLegalRepresentativeComponent', () => {
  let component: ViewLegalRepresentativeComponent;
  let fixture: ComponentFixture<ViewLegalRepresentativeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewLegalRepresentativeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewLegalRepresentativeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
