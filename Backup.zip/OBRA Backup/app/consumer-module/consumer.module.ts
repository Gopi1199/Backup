import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ConsumerRouting } from './consumer.routing';
import { ValidationService } from '../validation/validation.service';
import { HttpModule } from '@angular/http';
import { ConsumerModuleComponent } from './consumer-module.component';
import { AddEditConsumerComponent } from './add-edit-consumer/add-edit-consumer.component';
import { AddEditLegalRepComponent } from './add-edit-legal-rep/add-edit-legal-rep.component';
import { SearchConsumerComponent } from '../consumer-module/search-consumer/search-consumer.component';
import { ConsumerDetailComponent } from './consumer-detail/consumer-detail.component';
import { ConsumerHistoryComponent } from './consumer-history/consumer-history.component';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedModule } from '../SharedModule/shared.module';
import { ViewLegalRepresentativeComponent } from './view-legal-representative/view-legal-representative.component';
import { ViewLegalRepHistroyComponent } from './view-legal-rep-histroy/view-legal-rep-histroy.component';

@NgModule({
  declarations: [
    ConsumerModuleComponent,
    AddEditConsumerComponent,
    SearchConsumerComponent,
    ConsumerDetailComponent,
    ConsumerHistoryComponent,
    AddEditLegalRepComponent,
    ViewLegalRepresentativeComponent,
    ViewLegalRepHistroyComponent
  ],
  imports: [
    ConsumerRouting,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    HttpModule,
    SharedModule,
    TextMaskModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [],
  bootstrap: []
})
export class ConsumerModule { }
