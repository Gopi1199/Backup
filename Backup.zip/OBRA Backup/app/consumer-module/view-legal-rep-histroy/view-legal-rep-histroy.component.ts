import { Component, OnInit, Input, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ValidationService } from '../../validation/validation.service';
@Component({
  selector: 'app-view-legal-rep-histroy',
  templateUrl: './view-legal-rep-histroy.component.html',
  styleUrls: ['./view-legal-rep-histroy.component.css']
})
export class ViewLegalRepHistroyComponent implements OnInit {
  private spinnerFlag: boolean;
  private selectedRowData: any;
  private Ids: number;
  private sub: any;
  private legalRepId: number;
  private clientsId: number;
  private leaglRepStatus: Boolean;
  private relationshipDropDown: any;
  private linkLegalRefForm: any;
  @Input() modalRef: any;
  constructor(private activeRoute: ActivatedRoute, private httpService: WebService, private router: Router,
    private modalService: BsModalService, private builder: FormBuilder) {
    this.spinnerFlag = false;
    // this.selectedRowData=
  }

  ngOnInit() {
    this.sub = this.activeRoute.params.subscribe(params => {
      this.legalRepId = Number(params['legalRepId']);
      this.clientsId = Number(params['clientId']);
      this.getConsumerInfo();
    });
    this.linkLegalRefForm = this.builder.group({
      'relationship': ['', Validators.required]

    });
  }
  getConsumerInfo() {
    this.spinnerFlag = true;
    this.selectedRowData = [];

    this.httpService.getRecord('viewLegalRepHistory?legalRepId=' + this.legalRepId + '&clientsId=' + this.clientsId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.selectedRowData = res.data;
        this.leaglRepStatus = res.data.linked;
        this.spinnerFlag = false;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      this.spinnerFlag = false;
      console.log(error);
    });
  }
  legalRepDetails() {
    this.router.navigate(['/dashboard/consumer-dashboard/legalrepresentative', this.legalRepId, this.clientsId]);
  }
  UnLinkConsumer() {
    this.httpService.getRecord('unLinkLegalRep?clientsId=' + this.clientsId + '&legalRepId=' + this.legalRepId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.selectedRowData = res.data;
        this.spinnerFlag = false;
        this.router.navigate(['/dashboard/consumer-dashboard/consumer-detail', this.clientsId]);
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      console.log(error);
    });

  }
  reinkConsumerModal(reinkConsumer: TemplateRef<any>) {
    this.spinnerFlag = true;
    this.httpService.getRecord('relationshipDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.relationshipDropDown = res.data;
        this.spinnerFlag = false;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      this.spinnerFlag = false;
    });
    this.modalRef = this.modalService.show(reinkConsumer);
  }
  linkLegalRefSubmit() {
    this.spinnerFlag = true;
    this.httpService.getRecord('linkLegalRep?clientsId=' + this.clientsId + '&legalRepId=' + this.legalRepId +
      '&relationShipId=' + this.linkLegalRefForm.value.relationship).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.modalRef.hide();
          this.router.navigate(['/dashboard/consumer-dashboard/consumer-detail', this.clientsId]);
        } else {
          this.spinnerFlag = false;
        }
      }, error => {
        console.log(error);
      });
  }
  ViewHistroy() {
    // alert('ok');
    this.router.navigate(['/dashboard/consumer-dashboard/legalrephistroy', this.legalRepId]);
  }
  consumerDetails() {
    this.router.navigate(['/dashboard/consumer-dashboard/consumer-detail', this.clientsId]);
  }
  gotoEditLegalRep() {
    this.router.navigate(['/dashboard/consumer-dashboard/addeditlegalrep', this.legalRepId]);
  }
}
