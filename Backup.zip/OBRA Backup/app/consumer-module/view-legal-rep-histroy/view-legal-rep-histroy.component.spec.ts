import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewLegalRepHistroyComponent } from './view-legal-rep-histroy.component';

describe('ViewLegalRepHistroyComponent', () => {
  let component: ViewLegalRepHistroyComponent;
  let fixture: ComponentFixture<ViewLegalRepHistroyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewLegalRepHistroyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewLegalRepHistroyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
