import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ConsumerModuleComponent } from './consumer-module.component';
import { AddEditConsumerComponent } from './add-edit-consumer/add-edit-consumer.component';
import { AddEditLegalRepComponent } from './add-edit-legal-rep/add-edit-legal-rep.component';
import { SearchConsumerComponent } from './search-consumer/search-consumer.component';
import { ConsumerDetailComponent } from './consumer-detail/consumer-detail.component';
import { ConsumerHistoryComponent } from './consumer-history/consumer-history.component';
import { ViewLegalRepresentativeComponent } from './view-legal-representative/view-legal-representative.component';
import { ViewLegalRepHistroyComponent } from './view-legal-rep-histroy/view-legal-rep-histroy.component';

const routes: Routes = [
    { path: '', component: ConsumerModuleComponent, pathMatch: 'full' },
    { path: 'consumer-dashboard', pathMatch: 'full', component: ConsumerModuleComponent },
    { path: 'consumer-search', pathMatch: 'full', component: SearchConsumerComponent },
    { path: 'consumer-search/:ssnNumber', pathMatch: 'full', component: SearchConsumerComponent },
    { path: 'add-edit-consumer/:addEdit/:id', pathMatch: 'full', component: AddEditConsumerComponent },
    { path: 'add-edit-consumer/:addEdit', pathMatch: 'full', component: AddEditConsumerComponent },
    { path: 'addeditlegalrep/:clientId/:legalRepId', pathMatch: 'full', component: AddEditLegalRepComponent },
    { path: 'addeditlegalrep/:clientId', pathMatch: 'full', component: AddEditLegalRepComponent },
    { path: 'consumer-detail/:id', pathMatch: 'full', component: ConsumerDetailComponent },
    { path: 'consumer-history/:id', pathMatch: 'full', component: ConsumerHistoryComponent },
    { path: 'legalrepresentative/:legalRepId/:clientId', pathMatch: 'full', component: ViewLegalRepresentativeComponent },
    { path: 'legalrephistroy/:clientId/:legalRepId', pathMatch: 'full', component: ViewLegalRepHistroyComponent },
    { path: '**', redirectTo: 'dashboard', pathMatch: 'full' },
];
export const ConsumerRouting: ModuleWithProviders = RouterModule.forChild(routes);
