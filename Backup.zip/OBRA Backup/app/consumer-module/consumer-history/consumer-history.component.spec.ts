import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ConsumerHistoryComponent } from './consumer-history.component';

describe('ConsumerHistoryComponent', () => {
  let component: ConsumerHistoryComponent;
  let fixture: ComponentFixture<ConsumerHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsumerHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsumerHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
