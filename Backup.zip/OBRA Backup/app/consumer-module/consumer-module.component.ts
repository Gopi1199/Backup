import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consumer-module',
  templateUrl: './consumer-module.component.html',
  styleUrls: ['./consumer-module.component.css']
})
export class ConsumerModuleComponent implements OnInit {

  constructor() { }
  ngOnInit() {
  }
}
