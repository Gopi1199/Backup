import { Component, OnInit, OnDestroy, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { CommonServiceService } from '../../Service/common-service.service';
import { WebService } from '../../Service/webservice';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { dateFormat } from '../../JSON';

@Component({
  selector: 'app-consumer-detail',
  templateUrl: './consumer-detail.component.html',
  styleUrls: ['./consumer-detail.component.css']
})
export class ConsumerDetailComponent implements OnInit, OnDestroy {
  clientId: number;
  private sub: any;
  private legalRep: any;
  private modalRef: BsModalRef;
  private obj = new Array();
  private spinnerFlag: Boolean = false;
  private activeStatus: Boolean = true;
  private selectedRowData: any;
  private clientNoteCount: any;
  private dateFormat: any;
  private addClientNotesForm: any;
  private addClientNotesSuccess: Boolean = false;
  private addClientNotesError: Boolean = false;
  private errorFlag: Boolean = false;
  private erroMsg: String;
  private statusMessage: String;
  private data: any;
  private stateObj: any = { '1': '' };
  private statusArray: any = { 'P': 'Pending', 'D': 'Denied', 'A': 'Active', 'I': 'InActive' };

  constructor(private activeRoute: ActivatedRoute, private httpService: WebService, private router: Router,
    private modalService: BsModalService, private builder: FormBuilder) {
    this.dateFormat = dateFormat;
    this.statusMessage = "No Legal Representative Assigned";
  }

  ngOnInit() {
    this.sub = this.activeRoute.params.subscribe(params => {
      this.clientId = Number(params['id']);
      this.getConsumerInfo();
    });
    this.addClientNotesForm = this.builder.group({
      'notes': ['', Validators.required]
    });
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  getConsumerInfo() {
    this.spinnerFlag = true;
    this.selectedRowData = [];
    this.selectedRowData['clientLegalRepViews'] = [];
    this.selectedRowData['address'] = [];
    this.httpService.getRecord('viewClient?clientId=' + this.clientId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.errorFlag = false;
        this.selectedRowData = res.data;
        this.clientNoteCount = res.data.clientNotes.length;
        this.selectedRowData.clientLegalRepViews.forEach(element => {
          if (element.status === "A") {
            this.activeStatus = false;
          }
        });
        this.spinnerFlag = false;

      } else {
        this.spinnerFlag = false;
        this.errorFlag = true;
        this.erroMsg = res.inline;
      }

    }, error => {
      console.log(error);
    });
  }
  gotoEditConsumer() {
    this.router.navigate(['/dashboard/consumer-dashboard/add-edit-consumer', 'edit', this.clientId]);
  }
  viewClientHistory() {
    this.router.navigate(['/dashboard/consumer-dashboard/consumer-history', this.clientId]);
  }
  viewLegalRepRouter(legalRepId) {
    this.router.navigate(['/dashboard/consumer-dashboard/legalrepresentative', legalRepId, this.clientId]);
  }
  viewClientNotesModal(viewClientNotes: TemplateRef<any>) {
    this.modalRef = this.modalService.show(viewClientNotes);
  }
  consumerSearchRouter() {
    this.router.navigate(['/dashboard/consumer-dashboard']);
  }
  addLegalRepRouter() {
    this.router.navigate(['/dashboard/consumer-dashboard/addeditlegalrep', this.clientId]);
  }
  addClientNotesSubmit() {
    this.addClientNotesSuccess = false;
    this.addClientNotesError = false;
    Object.keys(this.addClientNotesForm.controls).forEach(field => {
      const control = this.addClientNotesForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.addClientNotesForm.valid) {
      this.data = this.addClientNotesForm.value;
      this.data['clientsId'] = this.clientId;
      this.httpService.addRecord('addComment', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.addClientNotesSuccess = true;
          location.reload();

        } else {
          this.addClientNotesError = true;
          this.spinnerFlag = false;
        }

      }, error => {
        console.log(error);
      });

    }
  }
  closeClientNoteModal() {
    this.modalRef.hide();
  }
  closeNotification() {
    this.errorFlag = false;
  }
}
