import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AddEditLegalRepComponent } from './add-edit-legal-rep.component';

describe('AddEditLegalRepComponent', () => {
  let component: AddEditLegalRepComponent;
  let fixture: ComponentFixture<AddEditLegalRepComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddEditLegalRepComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditLegalRepComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
