import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { WebService } from '../../Service/webservice';
import { MyDatePicker, IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { DateService } from '../../Service/date.service';
import { ModalService } from '../../Service/modal.service';
import { dateFormat } from '../../JSON';

@Component({
  selector: 'app-add-edit-legal-rep',
  templateUrl: './add-edit-legal-rep.component.html',
  styleUrls: ['./add-edit-legal-rep.component.css']
})
export class AddEditLegalRepComponent implements OnInit {
  private addEditLegalRepForm: any;
  private clientId: number;
  private legalRepId: Number;
  private sub: any;
  private consumerDetails: any;
  private dischargeDropDownAll: any;
  private terminationTypeDropDown: any;
  private selectedRowData: any;
  private spinnerFlag: Boolean = false;
  private addLegal: Boolean = true;
  private editLegal: Boolean = false;
  private addressHist: Boolean = false;
  private addConsumerFlag: any;
  private data: any;
  private dateFormat: any;
  private screenTitle: String;
  private ssnValidateUrl: String;
  private representativeTypeDropDown: any;
  private relationshipDropDown: any;
  private clientInfo: any;
  ssnMask: any[] = [/\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  phoneMask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  private maxlength: number;
  private clientNotes: string;
  private notesMouseEvevtFlag: boolean;
  private characterleft: number;
  private dateOfBirth: Object = {};
  private terminationDate: Object = {};
  private sucessFlag: Boolean = false;
  private errorFlag: Boolean = false;
  private sucessMsg: String = '';
  private errorMsg: String = '';
  private firstName: String;
  private lastName: String;
  constructor(private dateService: DateService, private router: Router, private httpService: WebService,
    private activeRoute: ActivatedRoute, private builder: FormBuilder, private modalService: ModalService) {
    this.maxlength = 4000;
    this.characterleft = this.maxlength;
    this.clientNotes = '';
    this.notesMouseEvevtFlag = false;
    this.dateFormat = dateFormat;
  }

  ngOnInit() {

    this.selectedRowData = {
      'firstName': '',
      'middleInitial': '',
      'lastName': '',
      'companyName': '',
      'addressLine1': '',
      'addressLine2': '',
      'city': '',
      'stateId': '',
      'zipCode1': '',
      'zipCode2': '',
      'phoneNumber': '',
      'email': '',
      'representativeTypeId': '',
      'relationshipId': ''
    };
    this.selectedRowData = {
      'address': { addressLine1: '', addressLine2: '', city: '', stateId: '', zipCode1: '', zipCode2: '' }
    };
    this.getDropDownList();
    this.sub = this.activeRoute.params.subscribe(params => {
      this.clientId = Number(params['clientId']);
      this.legalRepId = Number(params['legalRepId']);
      if (this.clientId > 0 && this.legalRepId > 0) {
        this.addLegal = false;
        this.editLegal = true;
        this.screenTitle = 'Edit Legal Representatives';
        this.getLegalRep();
      } else {
        this.spinnerFlag = true;
        this.addLegal = true;
        this.editLegal = false;
        this.screenTitle = 'Add Legal Representatives';
        this.getClient();
      }
    });

    this.addEditLegalRepForm = this.builder.group({
      'firstName': ['', Validators.required],
      'middleInitial': [''],
      'lastName': ['', Validators.required],
      'companyName': [''],
      'addressLine1': ['', Validators.required],
      'addressLine2': [''],
      'city': ['', Validators.required],
      'stateId': ['', Validators.required],
      'zipCode1': ['', [Validators.required, ValidationService.zipCodeValidator]],
      'zipCode2': ['', ValidationService.zipCodeValidator],
      'phoneNumber': [''],
      'email': ['', ValidationService.emailValidator],
      'representativeTypeId': ['', Validators.required],
      'relationshipId': ['', Validators.required]
    });
  }
  addEditConsumerSubmit() {

    Object.keys(this.addEditLegalRepForm.controls).forEach(field => {
      const control = this.addEditLegalRepForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });


    if (this.addEditLegalRepForm.valid) {

      this.data = {};
      this.spinnerFlag = true;
      this.data = this.addEditLegalRepForm.value;
      this.data.phoneNumber = String(this.data.phoneNumber);
      this.data.phoneNumber = this.data.phoneNumber.replace(/\D+/g, '');

      this.data.address = {
        'addressLine1': this.data.addressLine1,
        'addressLine2': this.data.addressLine2,
        'city': this.data.city,
        'stateId': this.data.stateId,
        'zipCode1': this.data.zipCode1,
        'zipCode2': this.data.zipCode2
      };

      delete this.data['addressLine1'];
      delete this.data['addressLine2'];
      delete this.data['city'];
      delete this.data['stateId'];
      delete this.data['zipCode1'];
      delete this.data['zipCode2'];

      this.data['clientsId'] = this.clientId;
      this.data['legalRepresentativesId'] = this.legalRepId;

      this.httpService.addRecord('addLegalRep', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.addConsumerFlag = true;
          this.sucessMsg = res.inline;
          this.sucessFlag = true;
          this.router.navigate(['/dashboard/consumer-dashboard/consumer-detail', this.clientId]);
        } else {
          this.spinnerFlag = false;
          this.errorMsg = res.inline;
          this.errorFlag = true;
          // this.modalService.showAlertPopup('Error', res.inline, '');
        }

      }, error => {
        // this.modalService.showAlertPopup('Error', error, '');
      });

    }
  }
  gotoConsumerDetail() {
    this.router.navigate(['/dashboard/consumer-dashboard/consumer-detail', this.clientId]);
  }

  gotoConsumerDashboard() {
    this.router.navigate(['/dashboard/consumer-dashboard']);
  }
  getLegalRep() {
    this.spinnerFlag = true;
    this.selectedRowData['clientLegalRepViews'] = [];

    this.httpService.getRecord('viewLegalRep?legalRepId=' + this.legalRepId + '&clientsId=' + this.clientId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.selectedRowData = res.data;

        if (this.selectedRowData['address'] == null) {
          this.selectedRowData['address'] = { addressLine1: '', addressLine2: '', city: '', stateId: '', zipCode1: '', zipCode2: '' };
        } else {
          this.addressHist = true;
        }
        this.firstName = this.selectedRowData.firstName;
        this.lastName = this.selectedRowData.lastName;
        this.spinnerFlag = false;
      } else {
        this.spinnerFlag = false;
        // this.modalService.showAlertPopup('Error', res.inline, '');
      }

    }, error => {
      // this.modalService.showAlertPopup('Error', error, '');
    });
  }

  resetAddEditLegalRep() {
    if (this.editLegal) {
      this.getLegalRep();
    } else {
      this.addEditLegalRepForm.reset();
    }
  }
  viewLegalRepRouter() {
    this.router.navigate(['/dashboard/consumer-dashboard/legalrepresentative', this.legalRepId, this.clientId]);
  }
  getDropDownList() {
    this.spinnerFlag = true;
    this.httpService.getRecord('reprasentativeTypeDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.representativeTypeDropDown = res.data;
        this.spinnerFlag = false;
      } else {
        this.spinnerFlag = false;
        // this.modalService.showAlertPopup('Error', res.inline, '');
      }
    }, error => {
      this.spinnerFlag = false;
      // this.modalService.showAlertPopup('Error', error, '');
    });

    this.spinnerFlag = true;
    this.httpService.getRecord('relationshipDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.relationshipDropDown = res.data;
        this.spinnerFlag = false;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      this.spinnerFlag = false;
    });
  }
  getClient() {
    this.spinnerFlag = true;
    this.httpService.getRecord('viewClient?clientId=' + this.clientId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.clientInfo = res.data;
        this.firstName = this.clientInfo.firstName;
        this.lastName = this.clientInfo.lastName;

        this.spinnerFlag = false;
      } else {
        this.spinnerFlag = false;
        // this.modalService.showAlertPopup('Error', res.inline, '');
      }
    }, error => {
      this.spinnerFlag = false;
      // this.modalService.showAlertPopup('Error', error, '');
    });
  }

}
