import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ConsumerModuleComponent } from './consumer-module.component';

describe('ConsumerModuleComponent', () => {
  let component: ConsumerModuleComponent;
  let fixture: ComponentFixture<ConsumerModuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsumerModuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsumerModuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
