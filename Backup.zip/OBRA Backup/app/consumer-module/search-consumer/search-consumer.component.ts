import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MyDatePicker, IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { DateService } from '../../Service/date.service';
import { Router } from '@angular/router';
declare var $: any;
import { esLocale } from 'ngx-bootstrap/chronos/i18n/es';

@Component({
  selector: 'app-search-consumer',
  templateUrl: './search-consumer.component.html',
  styleUrls: ['./search-consumer.component.css']
})
export class SearchConsumerComponent implements OnInit, AfterViewInit {
  dataUrl: string;
  configUrl: string;
  searchInput: Object = {};
  private resetFlag: Boolean = false;
  private obj: any = [];
  private rolekeys: any;
  searchConsumerForm: any;
  private filter: any = { 'filters': {} };
  private data: Object;
  private selectedRowId: Number;
  private selectedRowData: any;
  private sucessFlag: boolean;
  private sucessMsg: string;
  private errorFlag: boolean;
  private errorMsg: string;
  private emptyForm: boolean;
  @ViewChild('input') input: ElementRef;
  ssnNumber: any;
  sub: any;
  mask: any[] = [/\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  datePlaceholder: string;
  private myDatePickerOptions: IMyDpOptions = {
    dateFormat: this.dateService.dateFormate(),
    editableDateField: true,
    openSelectorOnInputClick: true,
    disableSince: this.dateService.disableDate()
  };
  private model: Object = { date: { year: 2018, month: 10, day: 9 } };

  // DatePicker - Code End Here
  constructor(private router: Router, private Activatedroute: ActivatedRoute,
    private formBuilder: FormBuilder, private dateService: DateService) {
    this.sucessFlag = false;
    this.errorFlag = false;
    this.emptyForm = false;
    this.datePlaceholder = 'Date Of Birth';
  }
  ngOnInit() {
    this.sub = this.Activatedroute.params.subscribe(params => {
      if (params['ssnNumber']) {
        this.ssnNumber = params['ssnNumber'];
      } else {
        this.ssnNumber = '';
      }
    });
    this.searchConsumerForm = this.formBuilder.group({
      'ssn': [''],
      'lastName': [''],
      'firstName': [''],
      'dateOfBirth': [''],
      'medicaidNo': ['']
    });
    this.dataUrl = 'clientList';
    this.configUrl = 'ConsumerSearch.json';
  }
  ngAfterViewInit() {
    $(document).ready(function () {
      $('#datetimepicker1').datetimepicker({
        viewMode: 'years',
        format: 'MM/YYYY'
      });
    });
    $('#datetimepicker1').on('dp.change', function (e) {
      $('#datetimepicker1').data('DateTimePicker').minDate(e.date);
      console.log(e.date);
    });
  }
  searchConsumerSubmit(event) {
    if (this.searchConsumerForm.value.ssn === '' && this.searchConsumerForm.value.lastName === '' &&
      this.searchConsumerForm.value.firstName === '' && !this.searchConsumerForm.value.dateOfBirth
      && this.searchConsumerForm.value.medicaidNo === '') {
      this.sucessFlag = false;
      this.emptyForm = true;

    } else {
      this.searchConsumerForm.value.ssn = String(this.searchConsumerForm.value.ssn);
      this.searchConsumerForm.value.ssn = this.searchConsumerForm.value.ssn.replace(/\D+/g, '');
      this.emptyForm = false;
      this.resetFlag = false;
      this.obj = [];
      if (this.searchConsumerForm.value.dateOfBirth instanceof Object) {
        const dateOfBirth = this.searchConsumerForm.value.dateOfBirth.formatted;
        this.searchConsumerForm.value.dateOfBirth = dateOfBirth;
      } else if (!this.searchConsumerForm.value.dateOfBirth) {
        this.searchConsumerForm.value.dateOfBirth = '';
      }
      this.rolekeys = Object.keys(this.searchConsumerForm.value);
      for (let i = 0; i < this.rolekeys.length; i++) {
        const jsonData: any = {};
        let j = this.rolekeys[i];
        j = j.replace(/"/g, '\\"');
        jsonData.id = this.rolekeys[i];
        jsonData.value = this.searchConsumerForm.value[j];
        this.obj.push(jsonData);
      }
      this.filter.filters = this.obj;
      this.getConsumerList();
    }
  }
  mouseEnter() {
    this.datePlaceholder = 'mm/dd/yyyy';
  }
  mouseLeave() {
    this.datePlaceholder = 'Date Of Birth';
  }
  emptyFormClose() {
    this.emptyForm = false;
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.clientsId;
    this.router.navigate(['/dashboard/consumer-dashboard/consumer-detail', this.selectedRowId]);
  }
  getMessage(data: any): void {
    if (data.global === 'successMsg@') {
      this.sucessFlag = true;
      this.errorFlag = false;
      this.sucessMsg = data.inline;
    } else if (data.global === 'errorMsg@') {
      this.errorFlag = true;
      this.sucessFlag = false;
      this.errorMsg = data.inline;
    }
  }
  getConsumerList() {
    if (this.resetFlag === true) {
      this.searchInput = {
        'search': JSON.stringify({})
      };
    } else {
      this.searchInput = {
        'search': JSON.stringify(this.filter)
      };
    }
  }
  consumerSearchReset() {
    this.searchConsumerForm.reset();
    this.resetFlag = true;
  }
  closeNotification(text) {
    if (text === 'success') {
      this.sucessFlag = false;
    } else if (text === 'error') {
      this.errorFlag = false;
    }
  }

}
