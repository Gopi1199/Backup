import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EvaluationQueueComponent } from './evaluation-queue.component';

describe('EvaluationQueueComponent', () => {
  let component: EvaluationQueueComponent;
  let fixture: ComponentFixture<EvaluationQueueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EvaluationQueueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EvaluationQueueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
