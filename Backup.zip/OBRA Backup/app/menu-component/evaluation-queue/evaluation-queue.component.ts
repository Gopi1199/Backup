import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'app-evaluation-queue',
  templateUrl: './evaluation-queue.component.html',
  styleUrls: ['./evaluation-queue.component.css']
})
export class EvaluationQueueComponent implements OnInit {
  dataUrl: string;
  configUrl: string;
  name: string;
  private id;
  private sub;
  private sucessFlag: boolean;
  private sucessMsg: string;
  private errorFlag: boolean;
  private errorMsg: string;
  private emptyForm: boolean;
  searchInput: Object = {};
  noSSN: boolean = true;
  evalStatus: string = '2';
  constructor(private Activatedroute: ActivatedRoute, private router: Router) {
  }
  ngOnInit() {
    this.dataUrl = 'evaluationQueueList';
    this.sub = this.Activatedroute.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number
      this.EvaluationQueueChange();
    });
  }
  EvaluationQueueChange() {
    if (this.id === 1) {
      this.name = ' Level 1';
      this.configUrl = 'EvaluationQueue.json';
      this.noSSN = false;
    } else if (this.id === 2) {
      this.noSSN = false;
      this.configUrl = 'EvaluationQueue.json';
      this.name = ' ARR';
    } else if (this.id === 3) {
      this.noSSN = false;
      this.configUrl = 'EvaluationQueue.json';
      this.name = ' CIC';
    } else if (this.id === 4) {
      this.name = ' HED';
      this.noSSN = false;
      this.configUrl = 'EvaluationQueue.json';
    } else if (this.id === 5) {
      this.name = ' REV';
      this.configUrl = 'EvaluationQueue.json';
      this.noSSN = false;
    } else if (this.id === 0) {
      this.name = ' No SSN';
      this.configUrl = 'Evaluation_SSN.json';
      this.noSSN = true;
    } else if (this.id === 6) {
      this.id = 0;
      this.configUrl = 'Evaluation_INP.json';
      this.name = ' INP';
      this.evalStatus = '6';
      this.noSSN = false;
    } else if (this.id === 7) {
      this.id = 0;
      this.configUrl = 'Evaluation_ALL.json';
      this.name = ' ALL';
      this.noSSN = false;
    }
    this.searchInput = {
      "search": "{\"filters\":[{\"id\":\"evaluationTypeStr\",\"value\":\"" + this.id + "\"},{\"id\":\"evaluationStatusStr\",\"value\":\"" + this.evalStatus + "\"},{\"id\":\"noSSN\",\"value\":\"" + this.noSSN + "\"}]}"
    };
  }


  getMessage(data: any): void {
    if (data.global === 'successMsg@') {
      this.sucessFlag = true;
      this.errorFlag = false;
      this.sucessMsg = data.inline;
    } else if (data.global === 'errorMsg@') {
      this.errorFlag = true;
      this.sucessFlag = false;
      this.errorMsg = data.inline;
    }
  }

  emptyFormClose() {
    this.emptyForm = false;
  }
  closeNotification(text) {
    if (text === 'success') {
      this.sucessFlag = false;
    } else if (text === 'error') {
      this.errorFlag = false;
    }
  }
  onNotify(data: any): void {
    console.log(data);
    this.router.navigate(['/dashboard/evaluationdashboard/createevaluation', data.evaluationId]);
  }

}
