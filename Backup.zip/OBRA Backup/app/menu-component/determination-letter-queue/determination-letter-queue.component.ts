import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-determination-letter-queue',
  templateUrl: './determination-letter-queue.component.html',
  styleUrls: ['./determination-letter-queue.component.css']
})
export class DeterminationLetterQueueComponent implements OnInit {

  dataUrl: string;
  configUrl: string; 
  private sucessFlag: boolean;
  private sucessMsg: string;
  private errorFlag: boolean;
  private errorMsg: string;
  private emptyForm: boolean;
  
  searchInput: Object = {};
  constructor(private Activatedroute: ActivatedRoute) {
  }
  ngOnInit() {
    this.dataUrl = 'letterQueueList';
    this.configUrl = 'LetterQueue.json';
    this.searchInput = {
      "search":"{\"filters\":[{\"id\":\"\",\"value\":\"\"}]}"
    };
  }

  getMessage(data: any): void {
    if (data.global === 'successMsg@') {
      this.sucessFlag = true;
      this.errorFlag = false;
      this.sucessMsg = data.inline;
    } else if (data.global === 'errorMsg@') {
      this.errorFlag = true;
      this.sucessFlag = false;
      this.errorMsg = data.inline;
    }
  }
  emptyFormClose() {
    this.emptyForm = false;
  }



  closeNotification(text) {
    if (text === 'success') {
      this.sucessFlag = false;
    } else if (text === 'error') {
      this.errorFlag = false;
    }
  }

}
