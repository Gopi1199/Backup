import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeterminationLetterQueueComponent } from './determination-letter-queue.component';

describe('DeterminationLetterQueueComponent', () => {
  let component: DeterminationLetterQueueComponent;
  let fixture: ComponentFixture<DeterminationLetterQueueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeterminationLetterQueueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeterminationLetterQueueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
