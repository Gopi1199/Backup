import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MenuComponent } from '../menu-component/menu-component.component';
import { EvaluationQueueComponent } from './evaluation-queue/evaluation-queue.component';
import { PendingQueueComponent } from './pending-queue/pending-queue.component';
import { CosQueueComponent } from './cos-queue/cos-queue.component';
import { DeterminationLetterQueueComponent } from './determination-letter-queue/determination-letter-queue.component';
const routes: Routes = [
  { path: '', component: MenuComponent, pathMatch: 'full' },
  { path: 'dashboard', pathMatch: 'full', component: MenuComponent },
  { path: 'evaluationqueue/:id', pathMatch: 'full', component: EvaluationQueueComponent },
  { path: 'pendingQueue', pathMatch: 'full', component: PendingQueueComponent },
  { path: 'cosQueue', pathMatch: 'full', component: CosQueueComponent },
  { path: 'letterQueue', pathMatch: 'full', component: DeterminationLetterQueueComponent },
  { path: 'userDashboard', loadChildren: 'app/users-module/users-module#UsersModule' },
  { path: 'consumer-dashboard', loadChildren: 'app/consumer-module/consumer.module#ConsumerModule' },
  { path: 'appealsdashboard', loadChildren: 'app/appeals-module/appeals.module#AppealsModule' },
  { path: 'adminDashboard', loadChildren: 'app/admin-module/admin.module#AdminModule' },
  { path: 'evaluationdashboard', loadChildren: 'app/evaluation-module/evaluation.module#EvalutionModule' },
  { path: 'billing-dashboard', loadChildren: 'app/billing-module/billing.module#BillingModule' },
  { path: 'assessmentDashboard',  loadChildren: 'app/assessment-module/assessment.module#AssessmentModule' },
  { path: 'reportsDashboard',  loadChildren: 'app/reports/report-modules#ReportModule' },
  { path: '**', redirectTo: '/dashboard', pathMatch: 'full' }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
