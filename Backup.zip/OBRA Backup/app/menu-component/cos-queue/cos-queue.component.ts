import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-cos-queue',
  templateUrl: './cos-queue.component.html',
  styleUrls: ['./cos-queue.component.css']
})
export class CosQueueComponent implements OnInit {

  dataUrl: string;
  configUrl: string;
  private sucessFlag: boolean;
  private sucessMsg: string;
  private errorFlag: boolean;
  private errorMsg: string;
  private emptyForm: boolean;
  
  searchInput: Object = {};
  customColumns: any = {
    'columns': [
      {
        'columnName': 'Approve',
        'columnTemplate': 'approveButton',
        'model': ''
      },
      {
        'columnName': 'Reject',
        'columnTemplate': 'rejectButton',
        'model': ''
      }
    ]
  };
  constructor(private Activatedroute: ActivatedRoute) {
  }
  ngOnInit() {
    this.dataUrl = 'cosQueueList';
    this.configUrl = 'cosQueue.json';
    this.searchInput = {
      "search": "{\"filters\":[{\"id\":\"\",\"value\":\"\"}]}"
    };
  }
  emptyFormClose() {
    this.emptyForm = false;
  }
  getMessage(data: any): void {
    if (data.global === 'successMsg@') {
      this.sucessFlag = true;
      this.errorFlag = false;
      this.sucessMsg = data.inline;
    } else if (data.global === 'errorMsg@') {
      this.errorFlag = true;
      this.sucessFlag = false;
      this.errorMsg = data.inline;
    }
  }

  buttonClicked(event, row) {
    alert(row);
  }
  onNotify(data: any): void {
    console.log(data);
  }
  closeNotification(text) {
    if (text === 'success') {
      this.sucessFlag = false;
    } else if (text === 'error') {
      this.errorFlag = false;
    }
  }

}
