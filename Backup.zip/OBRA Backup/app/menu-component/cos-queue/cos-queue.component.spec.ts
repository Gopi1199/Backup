import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CosQueueComponent } from './cos-queue.component';

describe('CosQueueComponent', () => {
  let component: CosQueueComponent;
  let fixture: ComponentFixture<CosQueueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CosQueueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CosQueueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
