import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MenuComponent } from '../menu-component/menu-component.component';
import { routing } from '../menu-component/menu-routing';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { HttpModule } from '@angular/http';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedModule } from '../SharedModule/shared.module';
import { AdminMainComponent } from '../admin-module/admin-main/admin-main.component';
import { ValidationService } from '../validation/validation.service';
import { EvaluationQueueComponent } from './evaluation-queue/evaluation-queue.component';
import { PendingQueueComponent } from './pending-queue/pending-queue.component';
import { CosQueueComponent } from './cos-queue/cos-queue.component';
import { DeterminationLetterQueueComponent } from './determination-letter-queue/determination-letter-queue.component';


@NgModule({
    imports: [
        routing,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        HttpModule,
        TextMaskModule,
        // NgxPaginationModule,
        SharedModule
    ],
    declarations: [
        MenuComponent,
        DashboardComponent,
        EvaluationQueueComponent,
        PendingQueueComponent,
        CosQueueComponent,
        DeterminationLetterQueueComponent
    ],
    providers: [ValidationService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class MenuModule {

}
