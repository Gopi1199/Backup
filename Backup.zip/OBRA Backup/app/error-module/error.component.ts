import { Component, OnDestroy, AfterViewInit } from '@angular/core';
import { ErrorService } from '../Service/error-service';
import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent implements AfterViewInit, OnDestroy {
  private message: any;
  private status: string;
  subscription: Subscription;
  constructor(private errorService: ErrorService, private router: Router) {
    this.subscription = this.errorService.update$.subscribe(
      message => {
        this.message = message;
        console.log(this.message);
      });
  }
  ngAfterViewInit() {
    if (this.message.data.status === 'P') {
      this.status = 'pending';
    } else if (this.message.data.status === 'I') {
      this.status = 'inactive';
    } else if (this.message.data.status === 'D') {
      this.status = 'denied';
    }

  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
