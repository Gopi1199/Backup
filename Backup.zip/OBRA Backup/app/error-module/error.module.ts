import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ErrorRouting } from './error.routing';
import { ValidationService } from '../validation/validation.service';
import { HttpModule } from '@angular/http';
import { SharedModule } from '../SharedModule/shared.module';
import { ErrorComponent } from './error.component';
import { AccesDeniedComponent } from './acces-denied/acces-denied.component';
import { InternalServerErrorComponent } from './internal-server-error/internal-server-error.component';
import { UnknownErrorComponent } from './unknown-error/unknown-error.component';

@NgModule({
    declarations: [
        ErrorComponent,
        AccesDeniedComponent,
        InternalServerErrorComponent,
        UnknownErrorComponent
    ],
    imports: [
        ErrorRouting,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        HttpModule,
        SharedModule,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    providers: [],
    bootstrap: []
})
export class ErrorModule { }
