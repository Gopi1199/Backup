import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ErrorComponent } from './error.component';
import { AccesDeniedComponent } from './acces-denied/acces-denied.component';
import { InternalServerErrorComponent } from './internal-server-error/internal-server-error.component';
import { UnknownErrorComponent } from './unknown-error/unknown-error.component';

const routes: Routes = [
    // { path: '', component: ErrorComponent, pathMatch: 'full' },
    // { path: 'errordashboard', pathMatch: 'full', component: ErrorComponent },
    { path: 'user', pathMatch: 'full', component: ErrorComponent },
    { path: 'accessdenied', pathMatch: 'full', component: AccesDeniedComponent },
    { path: 'internalserver', pathMatch: 'full', component: InternalServerErrorComponent },
    { path: 'error/:id', pathMatch: 'full', component: UnknownErrorComponent },
    // { path: '**', redirectTo: 'consumerdashboard', pathMatch: 'full' }
];
export const ErrorRouting: ModuleWithProviders = RouterModule.forChild(routes);
