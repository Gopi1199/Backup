import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-acces-denied',
  templateUrl: './acces-denied.component.html',
  styleUrls: ['./acces-denied.component.css']
})
export class AccesDeniedComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  returnClick() {
    this.router.navigate(['dashboard']);
  }
}
