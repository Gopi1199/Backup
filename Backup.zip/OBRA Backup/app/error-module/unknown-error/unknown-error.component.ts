import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'unknown-error',
  templateUrl: './unknown-error.component.html',
  styleUrls: ['./unknown-error.component.css']
})
export class UnknownErrorComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  returnClick() {
    this.router.navigate(['dashboard']);
  }
}
