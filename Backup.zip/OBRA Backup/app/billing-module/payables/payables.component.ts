import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { WebService } from '../../Service/webservice';
import { HttpClient } from '@angular/common/http';
import { dateFormat } from '../../JSON';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
declare var $: any;

@Component({
  selector: 'app-payables',
  templateUrl: './payables.component.html',
  styleUrls: ['./payables.component.css']
})
export class PayablesComponent implements OnInit, AfterViewInit {
  private cmhId: number;
  private sub: any;
  private spinnerFlag;
  private payableInfo: any;
  private dateFormat: any;
  private payableId;
  private savePayableForm: any;
  index: any;
  private fiscalTear;


  private fiscalYear;
  private computedPay;
  private AdjustedPay;
  private data: Object;
  private sucessFlag: boolean;
  private errorFlag: boolean;
  private sucessMsg: String;
  private errorMsg: String;

  constructor(private formBuilder: FormBuilder, private activeRoute: ActivatedRoute,
    private http: HttpClient, private router: Router, private httpService: WebService) { }

  ngOnInit() {

    this.sucessFlag = false;
    this.errorFlag = false;
    this.sucessMsg = '';
    this.errorMsg = '';

    this.dateFormat = dateFormat;
    this.sub = this.activeRoute.params.subscribe(params => {
      this.cmhId = Number(params['id']);
      this.getPayables();
    });

    this.savePayableForm = this.formBuilder.group({
      'fiscalYear': ['', Validators.required],
      'computedPayable': ['', Validators.required],
      'adjustedPayable': ['', Validators.required]
    });
  }
  ngAfterViewInit() {
    $(document).ready(function () {
      $('#fiscalYear').datetimepicker({
        viewMode: 'years',
        format: 'YYYY',
        useCurrent: true,
        showClear: false
      });

      $('#fiscalYear').on('dp.show dp.update dp.change', function (e) {
        $('tbody tr td:first-child', '.payables-data').each(function() {
          $('span.year:contains(' + $(this).text() + ')').addClass('disabled');
        });
      });
    });
  }

  disableManualEntry() {
    return false;
  }

  setFiscalYear(fiscalYear) {
    this.savePayableForm.controls['fiscalYear'].setValue(fiscalYear);
  }

  viewPayables() {
    this.router.navigate(['/dashboard/billing-dashboard/billing-payables/', this.cmhId]);
  }
  routeToBilling() {
    this.router.navigate(['/dashboard/billing-dashboard/search-billing', this.cmhId]);
  }

  getPayables() {
    this.spinnerFlag = true;
    this.httpService.getRecord('viewPayables?cmhId=' + this.cmhId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.payableInfo = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      this.spinnerFlag = false;
    });
  }

  deletePayable(id) {
    this.spinnerFlag = true;
    this.sucessFlag = false;
    this.errorFlag = false;
    this.httpService.deleteRecord('deletePayable?payableId=' + id).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.sucessFlag = true;
        this.sucessMsg = 'Payable Deleted Successfully';
        setTimeout(() => {
          this.sucessFlag = false;
        }, 3000);
        this.getPayables();
      } else {
        this.errorFlag = true;
        this.errorMsg = res.inline;
        setTimeout(() => {
          this.errorFlag = false;
        }, 3000);
        this.spinnerFlag = false;
      }
    }, error => {
      this.spinnerFlag = false;
    });

  }


  savePayable() {
    Object.keys(this.savePayableForm.controls).forEach(field => {
      const control = this.savePayableForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.savePayableForm.valid) {
      this.spinnerFlag = true;
      this.data = this.savePayableForm.value;
      this.data['cmhBoardsId'] = this.cmhId;

      this.httpService.addRecord('savePayable', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.reset();
          this.getPayables();
        } else {
          this.spinnerFlag = false;
        }
      }, error => {
        this.spinnerFlag = false;
      });
    }
  }

  reset() {
    this.savePayableForm.reset();
  }

   mouseOvered(payablesId){
    this.index = this.payableInfo.indexOf(payablesId);
    let element = document.getElementsByClassName('payables-row'+ this.index);
    for(var i = 0; i < element.length; i++)
    {
          element[i].classList.add('payables-hover');

    }    
   }

   mouseLeave(payablesId){
    this.index = this.payableInfo.indexOf(payablesId);
  let element = document.getElementsByClassName('payables-row'+ this.index);
   for(var i = 0; i < element.length; i++)
   {
       element[i].classList.remove('payables-hover');
   }    
  
 }


}
