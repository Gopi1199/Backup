import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BillingRouting } from './billing.routing';
import { ValidationService } from '../validation/validation.service';
import { HttpModule } from '@angular/http';
import { BillingModuleComponent } from './billing-module.component';
import { SearchBillingComponent } from './search-billing/search-billing.component';
import { BillingRatesComponent } from './billing-rates/billing-rates.component';
import { BillingMemoComponent } from './billing-memo/billing-memo.component';
import { PayablesComponent } from './payables/payables.component';
import { SharedModule } from '../SharedModule/shared.module';
import { TextMaskModule } from 'angular2-text-mask';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import {ModalModule} from 'ngx-bootstrap';

@NgModule({
  imports: [
    BillingRouting,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    HttpModule,
    SharedModule,
    TextMaskModule,
    AngularMultiSelectModule,
    ModalModule
          ],
  declarations: [
    BillingModuleComponent,
    SearchBillingComponent,
    BillingRatesComponent,
    BillingMemoComponent,
    PayablesComponent
  ],
  providers: [ValidationService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})


  export class BillingModule {

   }
