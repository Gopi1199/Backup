import { Component, OnInit, TemplateRef, ViewChild, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ModalDirective } from 'ngx-bootstrap';
import { WebService } from '../../Service/webservice';

declare var $: any;

@Component({
  selector: 'app-billing-rates',
  templateUrl: './billing-rates.component.html',
  styleUrls: ['./billing-rates.component.css']
})
export class BillingRatesComponent implements OnInit, AfterViewInit {
  cmhId: number;
  private sub: any;
  private modalRef: BsModalRef;
  private spinnerFlag;
  private billingRates: any;
  private columns: any = [];
  private serviceUrl: String;
  private isListingAll: boolean;
  private indirectRateForm: any;
  private sucessFlag: boolean;
  private errorFlag: boolean;
  private notificationFlag: boolean;
  private successMsg: String;
  private errorMsg: String;
  private data: any;
  private successFlag: boolean;
  private beginDate: any;
  private endDate: any;
  private itration;
  private changedListCount: any;
  private indirectRateInvalidFlag: boolean;
  private federalRateInvalidFlag: boolean;

  @ViewChild('indirectBill') public indirectBill: ModalDirective;

  constructor(private httpService: WebService, private modalService: BsModalService,
    private formBuilder: FormBuilder, private activeRoute: ActivatedRoute, private router: Router) { }

  newIndirectBillModal() {
    this.indirectBill.show();
  }

  closeIndirectBillingModal() {
    this.indirectBill.hide();
  }
  ngOnInit() {

    this.sucessFlag = false;
    this.errorFlag = false;
    this.successMsg = '';
    this.errorMsg = '';

    this.sub = this.activeRoute.params.subscribe(params => {
      this.cmhId = Number(params['cmhId']);
      if (this.cmhId !== null && this.cmhId > 0) {
        this.isListingAll =  false;
      } else {
        this.isListingAll =  true;
      }
      this.getViewRate();
    });

    this.indirectRateForm = this.formBuilder.group({
      'beginDate': ['', Validators.required],
      'endDate': ['', Validators.required],
      'indirectRate': ['', Validators.required],
      'federalRate': ['', Validators.required]
    });
  }

  ngAfterViewInit() {
    $(document).ready(function () {
      $('#beginDateField, #endDateField').datetimepicker({
        viewMode: 'years',
        format: 'MM/YYYY'
      });
    });
  }

  setBeginDate(beginDate) {
    if (beginDate != null) {
      const x = beginDate.split('/'); // x[0] => Month  x[1] => Year
      // const days = new Date(x[1], x[0], 0).getDate();
      this.indirectRateForm.controls['beginDate'].setValue(beginDate);
      this.beginDate  = x[0] + '/01/' + x[1];
    } else {
      this.indirectRateForm.controls['beginDate'].setValue('');
      this.beginDate  = '';
    }
  }
  setEndDate(endDate) {
    if (endDate != null) {
      const x = endDate.split('/'); // x[0] => Month  x[1] => Year
      const days = new Date(x[1], x[0], 0).getDate();
      this.indirectRateForm.controls['endDate'].setValue(endDate);
      this.endDate  = x[0] + '/' + days + '/' + x[1];
    } else {
      this.indirectRateForm.controls['beginDate'].setValue('');
      this.endDate  = '';
    }
  }

  onKey(field, val) {
    if (val > 100 || val <= 0) {
      if (field === 'indirectRate') {
        this.indirectRateInvalidFlag = true;
        this.indirectRateForm.controls.indirectRate.invalid = false;
      } else {
        this.federalRateInvalidFlag = true;
        this.indirectRateForm.controls.federalRate.invalid = false;
      }
    } else if (val > 0 && val < 100) {
      if (field === 'indirectRate') {
        this.indirectRateInvalidFlag = false;
      } else {
        this.federalRateInvalidFlag = false;
      }
    }
  }
  getAllViewRateRouting() {
    this.router.navigate(['/dashboard/billing-dashboard/billing-rates']);
  }
  routeToViewRatById(cmhId) {
    this.router.navigate(['/dashboard/billing-dashboard/billing-rates', cmhId]);
  }
  // onFocusFederal() {
  //   this.itration = 1;
  //   if ( this.itration === 1) {
  //     this.indirectRateForm.controls['federalRate'].setValue(75);
  //   }
  //   this.itration++;
  // }

  getViewRate() {
    this.columns = [];
    this.spinnerFlag = true;
    if (this.cmhId !== null && this.cmhId > 0) {
      this.serviceUrl = 'viewRates?cmhId=' + this.cmhId;
    } else {
      this.serviceUrl = 'viewRates';
    }
    this.httpService.getRecord(this.serviceUrl).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.billingRates = res.data;
        for (const key in this.billingRates) {
          if (this.billingRates.hasOwnProperty(key)) {
            const val = this.billingRates[key];
            val['key']  = key;
            val['value']  = val[0]['cmhBoardsName'];
            this.columns.push(val);
          }
        }
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      this.spinnerFlag = false;
    });
  }

  toggleRate(billingRateId, status) {
    this.spinnerFlag = true;
    this.httpService.getRecord('toggleRateActive?billingRateId=' + billingRateId + '&status=' + status).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.sucessFlag = true;
        this.successMsg = 'Status Updated Successfully';
        setTimeout(() => {
          this.sucessFlag = false;
        }, 3000);
        this.getViewRate();
       } else {
        this.errorFlag = true;
        this.errorMsg = res.inline;
        setTimeout(() => {
          this.errorFlag = false;
        }, 3000);
        this.spinnerFlag = false;
      }
    }, error => {
    });
  }

  routeToBilling() {
    if (this.isListingAll === false) {
      this.router.navigate(['/dashboard/billing-dashboard/search-billing', this.cmhId]);
    } else {
      this.router.navigate(['/dashboard/billing-dashboard']);
    }
  }

  indirectRateSubmit() {

    this.data = {};
    this.successFlag = false;
    this.errorFlag = false;
    this.notificationFlag = false;

    Object.keys(this.indirectRateForm.controls).forEach(field => {
      const control = this.indirectRateForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });

    if (this.indirectRateForm.value['beginDate'] !== '') {
      this.indirectRateForm.value['beginDate']  = this.beginDate;
    }

    if (this.indirectRateForm.value['endDate'] !== '') {
      this.indirectRateForm.value['endDate']  = this.endDate;
    }

    this.indirectRateForm.value['cmhboardsId']  = this.cmhId;

    if (this.indirectRateForm.valid && this.indirectRateInvalidFlag === false && this.federalRateInvalidFlag === false) {
      this.spinnerFlag = true;
      this.data = this.indirectRateForm.value;

      this.httpService.addRecord('saveBillingRate', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.indirectRateForm.reset();
          this.spinnerFlag = false;
          this.notificationFlag = true;
          this.changedListCount = res.data.changedList.length;
          this.indirectBill.hide();
          setTimeout(() => {
            this.getViewRate();
          }, 3000);
        } else {
          this.errorFlag = true;
          this.spinnerFlag = false;
          this.errorMsg = res.inline;
          this.indirectBill.hide();
          setTimeout(() => {
            this.errorFlag = false;
          }, 3000);
        }
      }, error => {
        this.spinnerFlag = false;
        this.indirectBill.hide();
      });

    }
  }
  closeNotification(text) {
    if (text === 'success') {
      this.sucessFlag = false;
    } else if (text === 'error') {
      this.errorFlag = false;
    } else if (text === 'notification') {
      this.notificationFlag = false;
    }
  }
}
