import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-billing-module',
  templateUrl: './billing-module.component.html',
  styleUrls: ['./billing-module.component.css']
})
export class BillingModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
