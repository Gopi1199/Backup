import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ActivatedRoute, Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { WebService } from '../../Service/webservice';
import { HttpClient } from '@angular/common/http';
import { MyDatePicker, IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { DateService } from '../../Service/date.service';

@Component({
  selector: 'app-search-billing',
  templateUrl: './search-billing.component.html',
  styleUrls: ['./search-billing.component.css']
})
export class SearchBillingComponent implements OnInit {
  private modalRef: BsModalRef;
  BillId: number;
  searchBillingForm: any;
  addBillingNotesForm: any;
  search: any;
  cmhboardsId: any;
  dataUrl: string;
  configUrl: string;
  private billexit: boolean;
  private billingCards: boolean;
  private data: Object;
  private sub: any;
  private billResult: any;
  private selectedCmhBoard: any;
  private selectedCmhYear: any;
  private billingAll: any;
  private addFiscalyear: any;
  private filterCols: any;
  private spinnerFlag;
  private payableInfo;
  private billingNotes: any;
  private obj: any = [];
  private filter: any = { 'filters': {} };
  private successFlag: boolean;
  private errorFlag: boolean;
  private billingsId: any;
  private cmhId: any;
  private billingInfo: any;
  private editBillingForm: any;
  private billingAction: any;
  private paymentDate: Object = {};
  private successMsg: any;
  private errorMsg: any;
  private actionUrl: any;
  private addYearForm: any;
  private billnotexit: boolean;
  private billexistMsg: String;
  private fiscalYear: any;
  private cmhRequiredMsg: String;
  private currentYr: any;
  private fiscalYrLength: any;
  private payableDisable: boolean;
  private cmhRequiredFlag: boolean;
  private monthMap: any;
  private monthStr: any;
  costMask: any[] = [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, '.', /\d/, /\d/];
  pattern = '[a-zA-Z ]*';
  private openclose: boolean;
  @Input() cmhBoardAll: any;
  @Input() cmhBoardYear: any;
  @ViewChild('viewBillingNotes') private viewBillingNotes;
  @ViewChild('editBilling') private editBilling;
  @ViewChild('currentBilling') private currentBilling;
  @ViewChild('addYear') private addYear;

  private myDatePickerOptions: IMyDpOptions = {
    dateFormat: this.dateService.dateFormate(),
    editableDateField: false,
    openSelectorOnInputClick: true,
    disableSince: this.dateService.disableDate()
  };

  constructor(private dateService: DateService, private formBuilder: FormBuilder, private http: HttpClient, private httpService: WebService,
    private modalService: BsModalService, private router: Router, private activeRoute: ActivatedRoute) {
    this.billnotexit = false;
    this.fiscalYear = '';
    this.openclose = false;
    this.payableDisable = false;
  }

  ngOnInit() {
    this.monthMap = {
      '1': 'January', '2': 'February', '3': 'March', '4': 'April', '5': 'May', '6': 'June', '7': 'July', '8': 'August',
      '9': 'September', '10': 'October', '11': 'November', '12': 'December'
    };
    this.billexit = false;
    this.billingCards = false;
    this.spinnerFlag = false;
    this.successFlag = false;
    this.errorFlag = false;
    this.searchBillingForm = this.formBuilder.group({
      'cmhboardsId': [''],
      'fiscalYear': [{ value: '', disabled: true }]

    });




    this.addBillingNotesForm = this.formBuilder.group({
      'notes': ['', Validators.required],
      'memoFlag': ['']
    });

    this.addYearForm = this.formBuilder.group({
      'fiscalYear': ['2018', Validators.required]
    });

    this.editBillingForm = this.formBuilder.group({
      'directLabor': ['', Validators.required],
      'otherLabor': ['', Validators.required],
      'otherCosts': ['', Validators.required],
      'numberOfReviews': ['', Validators.required],
      'paymentDate': ['']
    });

    this.cmhboarddropdown();

    this.sub = this.activeRoute.params.subscribe(params => {
      this.cmhId = Number(params['cmhId']);
    });


  }

  cmhboarddropdown() {
    this.spinnerFlag = true;
    this.httpService.getRecord('cmhBoardDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.cmhBoardAll = res.data;
        if (this.cmhId !== null && this.cmhId > 0) {
          this.searchBillingForm.controls['cmhboardsId'].setValue(this.cmhId);
          this.changeCmh(this.cmhId);
        }

      } else {
        this.spinnerFlag = true;
      }
    }, error => {
    });
  }

  changeCmh(cmhboardsId) {
    this.spinnerFlag = true;
    this.cmhRequiredFlag = false;
    this.cmhId = cmhboardsId;
    this.httpService.getRecord('getYears?cmhId=' + this.cmhId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        if (res.data.length) {
          this.cmhBoardYear = res.data;
          this.fiscalYrLength = res.data.length;
          this.currentYr = this.cmhBoardYear[0];
          this.searchBillingForm.controls['fiscalYear'].reset({ value: res.data[0], disabled: false });
          this.searchBillingForm.controls['payable'].reset({ disabled: true });
          this.getBilling(1);
          this.billnotexit = false;
        } else {
          this.billingAll = [];
          this.cmhBoardYear = [];
          this.fiscalYrLength = 0;
          this.currentYr = '';
          this.searchBillingForm.controls['fiscalYear'].reset({ value: res.data[0], disabled: true });
          this.billexistMsg = res.inline;
          this.billnotexit = true;
        }
      } else {
        this.spinnerFlag = false;
      }

    }, error => {
      this.spinnerFlag = false;
    });
  }

  getBilling(loadFrom: any) {
    this.spinnerFlag = true;
    if (loadFrom === 2) { //  1 - Cmh Dropdown  2 - Add New Bill Yr
      this.searchBillingForm.value['fiscalYear'] = this.fiscalYear;
      this.cmhBoardYear = [this.fiscalYear];
      this.searchBillingForm.controls['fiscalYear'].reset({ value: this.fiscalYear, disabled: false });
    }

    if (this.searchBillingForm.controls['fiscalYear'].value === '') {
      this.spinnerFlag = false;
      this.cmhRequiredMsg = 'CMH Required';
      this.cmhRequiredFlag = true;
      return false;
    }

    this.filterCols = Object.keys(this.searchBillingForm.value);

    this.obj = [];
    this.billingAll = [];

    for (let i = 0; i < this.filterCols.length; i++) {
      const jsonData: any = {};
      let j = this.filterCols[i];
      j = j.replace(/"/g, '\\"');
      jsonData.id = this.filterCols[i];
      jsonData.value = this.searchBillingForm.value[j];
      this.obj.push(jsonData);
    }

    this.filter.filters = this.obj;

    this.data = {
      'max': 100,
      'skip': 0,
      'orderBy': '',
      'orderType': 'asc',
      'search': JSON.stringify(this.filter)
    };

    this.httpService.getRecordList('billingList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        if (res.data.length) {
          this.billingCards = true;
          this.billingAll = res.data;
        }
      } else {
        this.spinnerFlag = false;
      }

    }, error => {
      this.spinnerFlag = false;
    });
  }

  notifyEditBilling(billingsInfo: any) {
    this.billingAction = billingsInfo.action;
    if (billingsInfo.billDetails.billingsId !== null) {
      this.spinnerFlag = true;
      this.httpService.getRecord('viewBilling?billingId=' + billingsInfo.billDetails.billingsId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.billingInfo = res.data;
          this.monthStr = this.monthMap[res.data.month];
          if (this.billingInfo['paymentDate'] != null) {
            const paymentDate: any = this.billingInfo['paymentDate'].split('/');
            this.paymentDate = {
              date: {
                year: Number(paymentDate[2]), month: Number(paymentDate[0]),
                day: Number(paymentDate[1])
              }
            };
            this.billingInfo['paymentDate'] = this.paymentDate;
          }
          if (this.billingInfo.endDate !== '' && this.billingInfo.endDate !== null) {
            this.checkRate();
          }
        } else {
          this.spinnerFlag = false;
        }
      }, error => {
        this.spinnerFlag = false;
      });
    } else {
      this.billingInfo = billingsInfo;
      this.checkRate();
    }
  }

  checkRate() {
    this.spinnerFlag = true;
    this.httpService.getRecord('checkRates?cmhId=' + this.cmhId + '&rateDate=' + this.billingInfo.endDate).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.modalRef = this.modalService.show(this.editBilling);
      } else {
        this.spinnerFlag = false;
        this.modalRef = this.modalService.show(this.currentBilling);
      }
    }, error => {
      this.spinnerFlag = false;
    });
  }

  createBill() {
    this.spinnerFlag = true;
    this.httpService.getRecord('checkRates?cmhId=' + this.cmhId + '&rateDate=').subscribe(res => {
      if (res.global !== 'errorMsg@') {
        this.spinnerFlag = false;
        this.modalRef = this.modalService.show(this.currentBilling);
      } else {
        this.spinnerFlag = false;
        this.modalRef = this.modalService.show(this.addYear);
      }
    }, error => {
      this.spinnerFlag = false;
    });
  }



  notifyBillingNotes(billingsId: any, loadingType: any): void { //  1 - Loading Html //  2- From TS
    this.spinnerFlag = true;
    this.billingsId = billingsId;
    this.httpService.getRecord('loadNotes?billingsId=' + billingsId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        if (res.data.length) {
          this.billingCards = true;
          this.billingNotes = res.data;
          if (loadingType === 1) {
            this.modalRef = this.modalService.show(this.viewBillingNotes);
          }
        }
      } else {
        this.spinnerFlag = false;
      }

    }, error => {
      this.spinnerFlag = false;
    });
  }

  closeModal() {
    this.modalRef.hide();
  }


  addBillingNotesSubmit() {
    this.data = {};
    this.spinnerFlag = true;
    this.successFlag = false;
    this.errorFlag = false;
    Object.keys(this.addBillingNotesForm.controls).forEach(field => {
      const control = this.addBillingNotesForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.addBillingNotesForm.valid) {

      this.data = this.addBillingNotesForm.value;
      this.data['billingsId'] = this.billingsId;
      if (this.data['memoFlag'] === true) {
        this.data['memoFlag'] = 'Y';
      }
      this.httpService.addRecord('addBillingNote', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.successFlag = true;
          this.addBillingNotesForm.reset();
          this.notifyBillingNotes(this.billingsId, 2);
          setTimeout(() => {
            this.successFlag = false;
          }, 3000);
        } else {
          this.errorFlag = true;
          this.spinnerFlag = false;
        }

      }, error => {
        console.log(error);
      });

    }
  }

  saveYear() {
    if (this.addYearForm.valid) {
      this.fiscalYear = this.addYearForm.value.fiscalYear;
      this.modalRef.hide();
      this.getBilling(2);
    }
  }

  viewBillingRate() {
    if (this.cmhId) {
      this.router.navigate(['/dashboard/billing-dashboard/billing-rates/', this.cmhId]);
    } else {
      this.router.navigate(['/dashboard/billing-dashboard/billing-rates']);
    }
  }

  viewAllBillingRate() {
    this.router.navigate(['/dashboard/billing-dashboard/billing-rates']);
  }

  viewBillingRatepopup() {
    this.modalRef.hide();
    if (this.cmhId) {
      this.router.navigate(['/dashboard/billing-dashboard/billing-rates/', this.cmhId]);
    } else {
      this.router.navigate(['/dashboard/billing-dashboard/billing-rates']);
    }
  }

  saveBilling() {
    this.successFlag = false;
    this.errorFlag = false;
    this.successMsg = '';
    this.errorMsg = '';
    this.actionUrl = 'saveBilling';
    if (this.editBillingForm.valid) {
      this.spinnerFlag = true;
      this.data = this.editBillingForm.value;

      this.data['endDate'] = this.billingInfo['endDate'];
      this.data['month'] = this.billingInfo['month'];
      this.data['fiscalYear'] = this.billingInfo['fiscalYear'];
      this.data['cmhBoardsId'] = this.billingInfo['cmhBoardsId'];
      if (this.billingAction === 2) { // 1 - Edit Billing 2 - Adjustment Billing
        this.data['billingsId'] = this.billingInfo['billingsId'];
        this.actionUrl = 'saveBillingAdjustment';
      }

      if (typeof this.data['paymentDate'] !== 'object') {
        const dob: any = this.data['paymentDate'].formatted.split('/');
        this.data['paymentDate'] = dob[1] + '/' + dob[0] + '/' + dob[2];
      } else if (Object.keys(this.data['paymentDate']).length !== 0) {
        this.data['paymentDate'] = this.data['paymentDate'].date.month + '/' + this.data['paymentDate'].date.day + '/'
          + this.data['paymentDate'].date.year;
      } else {
        this.data['paymentDate'] = '';
      }

      this.httpService.addRecord(this.actionUrl, this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.successMsg = 'Successfully Updated Billing';
          this.successFlag = true;
          setTimeout(() => {
            this.successFlag = false;
          }, 3000);
          this.modalRef.hide();
          this.getBilling(1);
        } else {
          this.spinnerFlag = false;
          this.errorMsg = 'Failed to Updated Billing';
          this.errorFlag = true;
          setTimeout(() => {
            this.successFlag = false;
          }, 3000);
          this.modalRef.hide();
        }
      }, error => {
        console.log(error);
      });
    }

  }

  onlyDecimalNumberKey(event) {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode !== 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    } else {
      return true;
    }
  }

  viewPayables() {
    if (this.cmhId) {
      this.router.navigate(['/dashboard/billing-dashboard/billing-payables/', this.cmhId]);
      this.getPayables();
    } else {
      this.router.navigate(['/dashboard/billing-dashboard/billing-payables']);
    }
  }

  getPayables() {
    this.spinnerFlag = true;
    this.httpService.getRecord('viewPayables?cmhId=' + this.cmhId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.payableInfo = res.data;
      } else {
        this.spinnerFlag = false;
      }
    }, error => {
      this.spinnerFlag = false;
    });
  }

  routeToBillingMemo() {
    const cmhboardsId = this.searchBillingForm.value['cmhboardsId'];
    const fiscalYear = this.searchBillingForm.value['fiscalYear'];
    if (cmhboardsId) {
      this.router.navigate(['/dashboard/billing-dashboard/billing-memo/', cmhboardsId, fiscalYear]);
      this.getPayables();
    } else {
      this.router.navigate(['/dashboard/billing-dashboard/billing-memo']);
    }
  }

  openall() {
    this.openclose = true;
  }
  closeall() {
    this.openclose = false;
  }
}
