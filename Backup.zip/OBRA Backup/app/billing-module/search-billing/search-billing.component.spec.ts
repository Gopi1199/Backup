import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchBillingComponent } from './search-billing.component';

describe('SearchBillingComponent', () => {
  let component: SearchBillingComponent;
  let fixture: ComponentFixture<SearchBillingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchBillingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchBillingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
