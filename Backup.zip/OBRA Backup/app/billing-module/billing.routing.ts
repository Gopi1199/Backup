import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BillingModuleComponent } from './billing-module.component';
import { SearchBillingComponent } from './search-billing/search-billing.component';
import { BillingRatesComponent } from './billing-rates/billing-rates.component';
import { BillingMemoComponent } from './billing-memo/billing-memo.component';
import { PayablesComponent } from './payables/payables.component';

const routes: Routes = [
    { path: '', component: BillingModuleComponent, pathMatch: 'full' },
    { path: 'billing-dashboard', pathMatch: 'full', component: BillingModuleComponent },
    { path: 'search-billing', pathMatch: 'full', component: SearchBillingComponent },
    { path: 'search-billing/:cmhId', pathMatch: 'full', component: SearchBillingComponent },
    { path: 'billing-rates', pathMatch: 'full', component: BillingRatesComponent },
    { path: 'billing-rates/:cmhId', pathMatch: 'full', component: BillingRatesComponent },
    { path: 'billing-memo', pathMatch: 'full', component: BillingMemoComponent },
    { path: 'billing-memo/:cmhId/:fiscalYear', pathMatch: 'full', component: BillingMemoComponent },
    { path: 'billing-payables/:id', pathMatch: 'full', component: PayablesComponent },
    { path: '**', redirectTo: 'dashboard', pathMatch: 'full' }
];
export const BillingRouting: ModuleWithProviders = RouterModule.forChild(routes);
