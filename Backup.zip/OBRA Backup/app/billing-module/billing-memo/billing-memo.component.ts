
import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ActivatedRoute, Router} from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { WebService } from '../../Service/webservice';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-billing-memo',
  templateUrl: './billing-memo.component.html',
  styleUrls: ['./billing-memo.component.css']
})


export class BillingMemoComponent implements OnInit {
  BillId: number;
  billingMemoForm: any;
  addBillingNotesForm: any;
  search: any;
  cmhboardsId: any;
  dataUrl: string;
  configUrl: string;
  private billexit: boolean;
  private billingCards: boolean;
  private data: Object;
  private sub: any;
  private billResult: any;
  private selectedCmhBoard: any;
  private selectedCmhYear: any;
  private billingAll: any;
  private addFiscalyear: any;
  private filterCols: any;
  private spinnerFlag;
  private payableInfo;
  private billingNotes: any;
  private obj: any = [];
  private filter: any = { 'filters': {} };
  private addBillingNotesSuccess: boolean;
  private addBillingNotesError: boolean;
  private billingsId: any;
  private cmhId: any;
  private fiscalYear: any;
  private billingInfo: any;
  private str: any;
  private monthList: any;
  private monthListData: any;
  private settingsMonth: any;
  private isListingAll: boolean;
  @Input() cmhBoardAll: any;
  @Input() cmhBoardYear: any;
  @ViewChild('viewBillingNotes') private viewBillingNotes;
  constructor(private formBuilder: FormBuilder, private http: HttpClient, private httpService: WebService,
    private modalService: BsModalService, private router: Router, private eleRef: ElementRef, private activeRoute: ActivatedRoute) { }

  ngOnInit() {
    this.billexit = false;
    this.billingCards = false;
    this.spinnerFlag = false;
    this.addBillingNotesSuccess = false;
    this.addBillingNotesError = false;
    this.isListingAll = true;
    this.loadRoleMultiselect(true);

    this.billingMemoForm = this.formBuilder.group({
      'cmhboardsId': [''],
      'fiscalYear': [{ value: '', disabled: true }],
      'reportMonth' : []
     });

     this.cmhboarddropdown();

      this.sub = this.activeRoute.params.subscribe(params => {
        this.cmhId = Number(params['cmhId']);
        this.fiscalYear = Number(params['fiscalYear']);
      });
  }

  cmhboarddropdown() {
    this.spinnerFlag = true;
    this.httpService.getRecord('cmhBoardDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.cmhBoardAll = res.data;
        if (this.cmhId !== null && this.cmhId > 0) {
          this.isListingAll = false;
          this.billingMemoForm.controls['cmhboardsId'].setValue(this.cmhId);
          this.changeCmh(this.cmhId);
        }

       } else {
        this.spinnerFlag = true;
      }
    }, error => {
    });
  }

  changeCmh(cmhboardsId) {
    this.spinnerFlag = true;
    this.cmhId  = cmhboardsId;
    this.httpService.getRecord('getYears?cmhId=' + this.cmhId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        if (res.data.length) {
          this.cmhBoardYear = res.data;
          if (this.fiscalYear !== null && this.fiscalYear > 0) {
            this.billingMemoForm.controls['fiscalYear'].reset({ value: this.fiscalYear, disabled: false });
            this.getMonth();
          } else {
            this.billingMemoForm.controls['fiscalYear'].reset({ value: '', disabled: false });
          }
        } else {
          this.billingAll = [];
        }
      } else {
        this.spinnerFlag = false;
      }

    }, error => {
      this.spinnerFlag = false;
    });
  }

  getMonth() {
    this.spinnerFlag = true;
    this.data = this.billingMemoForm.value;
    this.httpService.getRecord('getMonths?cmhId=' + this.data['cmhboardsId'] + '&financialYear=' + this.data['fiscalYear']).
    subscribe(res => {
      if (res.global === 'successMsg@') {
        this.monthList = res.data;
        if (this.monthList.length > 0) {
          this.str = JSON.stringify(this.monthList);
          this.str = this.str.replace(/value/g, 'itemName');
          this.monthListData = JSON.parse(this.str);
          this.loadRoleMultiselect(false);
        }
        this.spinnerFlag = false;
      } else {
        this.spinnerFlag = false;
      }

    }, error => {
      this.spinnerFlag = false;
    });
  }

  loadRoleMultiselect(disableVal: any) {
    this.settingsMonth = {
      singleSelection: false,
      text: 'Select Month',
      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: false,
      badgeShowLimit: 1,
      selectedLabel: 'Month selected',
      classes: '',
      disabled: disableVal,
      searchPlaceholderText: 'Search',
      showCheckbox: true,
      noDataLabel: 'No Data Available',
      searchAutofocus: true
    };
  }
  routeToBilling() {
    if (this.isListingAll === false) {
      this.router.navigate(['/dashboard/billing-dashboard/search-billing', this.cmhId]);
    } else {
      this.router.navigate(['/dashboard/billing-dashboard']);
    }
  }

}
