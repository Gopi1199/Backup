import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingMemoComponent } from './billing-memo.component';

describe('BillingMemoComponent', () => {
  let component: BillingMemoComponent;
  let fixture: ComponentFixture<BillingMemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillingMemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingMemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
