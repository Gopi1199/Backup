
import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import 'rxjs/Rx';

@Injectable()
export class DateService {

    private dateFomate = "mm/dd/yyyy";

    private config = {
        FROMDATE_ERROR: "From Date shouldn't be greater than To  Date",
        FROMDATE_NULLERROR: "From Date shouldn't be empty",
        TODATE_NULLERROR: "To Date shouldn't be empty"
    };
    private invoiceConfig = {
        FROMDATE_ERROR: "From Invoice Date shouldn't be greater than To Invoice Date",
        FROMDATE_NULLERROR: "From Invoice Date shouldn't be empty",
        TODATE_NULLERROR: "To Invoice Date shouldn't be empty"
    };

    setConfig(option, value) {
        this.config[option] = value;
    }

    getConfig() {
        return this.config;
    }
    getInvoiceConfig() {
        return this.invoiceConfig;
    }
    constructor(private http: Http) { }

    dateFormate() {
        return this.dateFomate;
    }

    today_Date() {
        today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1;

        var yyyy = today.getFullYear();

        if (dd < 10) {
            dd = '0' + dd;
        }
        if (mm < 10) {
            mm = '0' + mm;
        }
        var today = dd + '/' + mm + '/' + yyyy;
        return today;
    }

    assignDate(value) {
        if (value) {
            var _date = value.split("/");

            var dd = _date[0];
            var mm = _date[1];
            var yyyy = _date[2];

            _date = mm + "/" + dd + "/" + yyyy;

            _date = new Date(_date);
            dd = _date.getDate();
            mm = _date.getMonth() + 1;
            yyyy = _date.getFullYear();

            return { date: { year: yyyy, month: mm, day: dd } };
        } else {
            return '';
        }
    }

    disableDate() {
        var _date = new Date();
        var numberOfDaysToAdd = 1;

        _date.setDate(_date.getDate() + numberOfDaysToAdd);

        var dd = _date.getDate();
        var mm = _date.getMonth() + 1;
        var yyyy = _date.getFullYear();

        return { year: yyyy, month: mm, day: dd };

    }

    compareDates(fromDate, toDate) {
        var tempFromDate: any = ((fromDate) ? fromDate.split("/") : '');
        var tempToDate: any = ((toDate) ? toDate.split("/") : '');

        tempFromDate = tempFromDate[0] + "/" + tempFromDate[1] + "/" + tempFromDate[2];
        tempToDate = tempToDate[0] + "/" + tempToDate[1] + "/" + tempToDate[2];

        tempFromDate = new Date(tempFromDate);
        tempToDate = new Date(tempToDate);
        if (tempFromDate > tempToDate) {
            return true;
        } else {
            return false;
        }

    }
}