import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Router } from '@angular/router';

@Injectable()
export class ErrorService {

    private updateSubject: BehaviorSubject<string> = new BehaviorSubject<string>('');

    update$: Observable<string> = this.updateSubject.asObservable();
    constructor(private router: Router) { }
    updateMessage(message: any) {
        this.updateSubject.next(message);
        if (message.status === 500) {
            this.router.navigate(['/internalserver']);
        } else if (message.global.httpCode === 403) {
             this.router.navigate(['/accessdenied']);
        } else if (message.global.httpCode === 401) {
            if (message.data) {
                if (message.data.status === 'P') {
                    this.router.navigate(['user']);
                } else if (message.data.status === 'I') {
                    this.router.navigate(['user']);
                } else if (message.data.status === 'D') {
                    this.router.navigate(['user']);
                } else if (message.data.status === 'N'){
                    this.router.navigate(['/newuser']);
                }
            }
            else{
                this.router.navigate(['/login']);
            }            
        }
    }
}
