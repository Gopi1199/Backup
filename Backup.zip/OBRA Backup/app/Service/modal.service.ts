import { Injectable, TemplateRef, ViewChild, ComponentFactoryResolver, ViewContainerRef, ComponentFactory } from '@angular/core';
import { ModalComponent } from '../SharedModule/modal/modal.component';
import { BsModalService } from 'ngx-bootstrap';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
// import { LoaderComponent } from '../loader/loader.component'
// import { NotificationsService } from 'angular2-notifications-lite';
// const NOTIFICATIONTYPES = { SUCCESS: 'success', ERROR: 'error', INFO: 'info' };
@Injectable()

export class ModalService {
    @ViewChild('popupHolder', { read: ViewContainerRef })
    public static popupHolder;
    public static alertTemplate: TemplateRef<any>;
    public static alertConfig: any = {
        animated: true,
        keyboard: false,
        backdrop: true,
        ignoreBackdropClick: false
    };
    private alertPopup: BsModalRef;
    constructor(private bsModalService: BsModalService,
        // private notificationService: NotificationsService,
        private componentFactoryResolver: ComponentFactoryResolver) {

    }

    showAlertPopup(title, content, okCallBack) {
        const componentFactory = this.componentFactoryResolver.resolveComponentFactory(ModalComponent);
        const componentRef = ModalService.popupHolder.createComponent(componentFactory);
        const modalInstance = <ModalComponent>componentRef.instance;
        modalInstance.openModal(title, content, true, () => {
            if (typeof okCallBack === 'function') {
                okCallBack();
                componentRef.destroy();
            }
        }, () => { });
    }

    showConfirmPopup(title, content, okCallBack, cancelCallBack) {
        const componentFactory = this.componentFactoryResolver.resolveComponentFactory(ModalComponent);
        const componentRef = ModalService.popupHolder.createComponent(componentFactory);
        const modalInstance = <ModalComponent>componentRef.instance;
        modalInstance.openModal(title, content, false, () => {
            if (typeof okCallBack === 'function') {
                okCallBack();
                componentRef.destroy();
            }
        }, () => {
            if (typeof cancelCallBack === 'function') {
                cancelCallBack();
                componentRef.destroy();
            }
        });
    }

    // showLoader() {
    //     LoaderComponent.showLoader();
    // }

    // hideLoader() {
    //     LoaderComponent.hideLoader();
    // }

    // showNotification(type, title, content) {
    //     if (NOTIFICATIONTYPES[type]) {
    //         this.notificationService[NOTIFICATIONTYPES[type]](title, content, { timeOut: '3000' });
    //     } else {
    //         console.log('Wrong notification type!');
    //     }
    // }
    // hideNotification() {
    //     this.notificationService.remove();
    // }
}
