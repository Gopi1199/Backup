import { Injectable } from '@angular/core';
import { CommonServiceService } from './common-service.service';
@Injectable()
export class WebService {
  constructor(private commonService: CommonServiceService) {
  }
  getRecordList(url, params) {
    return this.commonService.post(url, params);
  }
  getRecord(url) {
    return this.commonService.get(url);
  }
  searchRecord(url, params) {
    return this.commonService.post(url, params);
  }
  deleteRecord(url) {
    return this.commonService.get(url);
  }
  addRecord(url, params) {
    return this.commonService.post(url, params);
  }
  updateRecord(url, params) {
    return this.commonService.post(url, params);
  }
  generateReport(url, data) {
    const formurl = this.commonService.getBaseUrl() + '/' + url;
    const tabName = 'ViewReport';
    const form = document.createElement('form');
    form.setAttribute('id', 'reportform');
    form.setAttribute('method', 'post');
    form.setAttribute('action', formurl);
    form.setAttribute('target', tabName);
    form.setAttribute('style', 'display: none;');
    for (const prop of Object.keys(data)) {
      const field = document.createElement('input'); // add a post data value
      field.setAttribute('name', data[prop].id);
      field.setAttribute('value', data[prop].value);
      form.appendChild(field);
    }

    document.body.appendChild(form);
    window.open('about:blank', tabName); // open form in new window
    form.submit();
  }
}
