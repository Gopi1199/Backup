import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { WebService } from '../Service/webservice';
import { CommonServiceService } from '../Service/common-service.service';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { forkJoin } from 'rxjs/observable/forkJoin';

@Injectable()
export class AuthenticationService {
    public token: string;
    constructor(private http: Http, private httpService: WebService, private commonServiceData: CommonServiceService) {
        // set token if saved in local storage
        const currentUser = localStorage.getItem('currentUser');
        this.token = currentUser;
    }

    login(username: string, password: string) {
        return this.httpService.getRecord('login?userName=' + username).map(res => {
            if (res.data.authorities[0].authority !== 'NEWUSER') {
                localStorage.setItem('authorities', JSON.stringify(res.data.authorities));
                localStorage.setItem('currentUser', username);
                localStorage.setItem('userProfileId', res.data.userProfile.userProfileId);
                this.token = username;
                return true;
            } else {
                localStorage.setItem('currentUser', '');
                return false;
            }
        }, error => {
            localStorage.setItem('currentUser', '');
            return false;
        });
    }

    getRoleCode() {
        if (this.token !== '') {
            return this.httpService.getRecord('findUserPermissions?userName=' + this.token).map(res => {
                if (res.data !== '') {
                    // return res.data.authorities;
                    return res.data;
                } else {
                    return false;
                }
            }, error => {
                return false;
            });
        }
    }

    getNotification() {
        return this.httpService.getRecord('getAllDashboardCounts').map(res => {
            if (res.global === 'successMsg@') {
                // return res.data.authorities;
                return res.data;
            } else {
                return false;
            }
        }, error => {
            return false;
        });
    }

    logout(): void {
        localStorage.removeItem('users');
        localStorage.removeItem('currentUser');
    }
}
