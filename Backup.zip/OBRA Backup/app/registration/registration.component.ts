
import {
  OnInit, OnDestroy, Component, AfterViewInit
} from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ValidationService } from '../validation/validation.service';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../Service/webservice';
import { forkJoin } from 'rxjs/observable/forkJoin';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  loginForm: FormGroup;
  userRegForm: FormGroup;
  loginFlag = true;
  UserRegFlag = false;
  regFlag = false;
  regSuccessFlag = false;
  regAccessDenied = false;
  private id;
  private sub;
  data: any;
  url: any;
  spinnerFlag: boolean = false;
  private UserRegFrmError: boolean = false;
  private firstNameError: boolean = false;
  private lastNameErrors: boolean = false;
  private userTypeErrors: boolean = false;
  private userRegistrationForm: any;
  private isActive: boolean = true;
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private str: any = '';
  private forkResponse: any;
  private qualificationsAll: any;
  private cmhBoardAll: any;
  private agenciesAll: any;

  itemList = [];
  selectedItems = [];
  settings = {};
  private chmBoardList: any;
  private agenciesList: any;
  qualificationList: any = [];
  private currentUser: any;

  constructor(private router: Router, private Activatedroute: ActivatedRoute, private builder: FormBuilder,
    private httpService: WebService,
    // private modalService: ModalService
  ) { }

  ngOnInit() {
    this.userRegistrationForm = this.builder.group({
      'ssoUserID': ['ssoUserID'],
      'firstName': ['', Validators.required],
      'middleInitial': [''],
      'lastName': ['', Validators.required],
      'phoneNumber': [''],
      'email': ['', ValidationService.emailValidator],
      'userType': ['', Validators.required],
      'positionTitle': [{ value: '', disabled: true }],
      'cmhBoardsId': [{ value: '', disabled: true }],
      'newUserRegistration': [{ value: 'true' }],
      'agenciesId': [{ value: '', disabled: true }],
      'qualification': [{ value: '', disabled: true }]
    });
    const qualificationsDropDown = this.httpService.getRecord('qualificationsDropDown');
    const cmhBoardDropDown = this.httpService.getRecord('cmhBoardDropDown');
    const agenciesDropDown = this.httpService.getRecord('agenciesDropDown');

    forkJoin([qualificationsDropDown, cmhBoardDropDown, agenciesDropDown]).subscribe(results => {
      this.qualificationsAll = results[0];
      this.cmhBoardAll = results[1];
      this.agenciesAll = results[2];

      if (this.qualificationsAll.global === 'successMsg@'
        && this.cmhBoardAll.global === 'successMsg@' && this.qualificationsAll.global === 'successMsg@') {
        this.qualificationsAll = this.qualificationsAll.data;
        this.cmhBoardAll = this.cmhBoardAll.data;
        this.agenciesAll = this.agenciesAll.data;
        this.spinnerFlag = false;
        this.regFlag = false;
        this.UserRegFlag = true;
        this.loadActiveMultiSelect(true);
      }
    });
  }
  loadActiveMultiSelect(vl) {
    this.str = JSON.stringify(this.qualificationsAll);
    this.str = this.str.replace(/name/g, 'itemName');
    this.itemList = JSON.parse(this.str);
    this.selectedItems = [];
    this.settings = {
      singleSelection: false,
      text: 'Select',
      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: false,
      badgeShowLimit: 1,
      selectedLabel: 'Qualifications selected',
      classes: '',
      disabled: vl,
      searchPlaceholderText: 'Search',
      showCheckbox: true,
      noDataLabel: 'No Data Available',
      searchAutofocus: true
    };
  }

  onSelectAll(items: any) {
    this.qualificationList = [];
    this.selectedItems.forEach(element => {
      this.qualificationList.push(element.id);
    });
  }

  OnItemDeSelect(item: any) {
    this.qualificationList = [];
    this.selectedItems.forEach(element => {
      this.qualificationList.push(element.id);
    });
  }
  onDeSelectAll(items: any) {
    this.qualificationList = [];
    this.selectedItems.forEach(element => {
      this.qualificationList.push(element.id);
    });
  }
  userTypeChange(val) {
    val = Number(val);
    if (val === 3) {
      this.userRegistrationForm.controls['positionTitle'].reset({ value: '', disabled: false });
      this.userRegistrationForm.controls['cmhBoardsId'].reset({ value: '', disabled: false });
      this.userRegistrationForm.controls['agenciesId'].reset({ value: '', disabled: false });
      this.loadActiveMultiSelect(true);
    } else if (val === 4) {
      this.userRegistrationForm.controls['positionTitle'].reset({ value: '', disabled: true });
      this.userRegistrationForm.controls['cmhBoardsId'].reset({ value: '', disabled: true });
      this.userRegistrationForm.controls['agenciesId'].reset({ value: '', disabled: true });
      this.loadActiveMultiSelect(false);
    } else if (val === 5) {
      this.userRegistrationForm.controls['positionTitle'].reset({ value: '', disabled: false });
      this.userRegistrationForm.controls['cmhBoardsId'].reset({ value: '', disabled: false });
      this.userRegistrationForm.controls['agenciesId'].reset({ value: '', disabled: false });
      this.loadActiveMultiSelect(false);
    } else {
      this.userRegistrationForm.controls['positionTitle'].reset({ value: '', disabled: true });
      this.userRegistrationForm.controls['cmhBoardsId'].reset({ value: '', disabled: true });
      this.userRegistrationForm.controls['agenciesId'].reset({ value: '', disabled: true });
      this.loadActiveMultiSelect(true);
    }
  }
  userRegistrationSubmit() {

    Object.keys(this.userRegistrationForm.controls).forEach(field => {
      const control = this.userRegistrationForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.userRegistrationForm.valid) {
      let phone = String(this.userRegistrationForm.value.phoneNumber);
      phone = phone.replace(/\D+/g, '');
      this.userRegistrationForm.value.phoneNumber = phone;
      this.data = this.userRegistrationForm.value;
      this.data.qualificationList = this.qualificationList;
      this.data['ssoUserID'] = 'ssoUserID';
      this.data['newUserRegistration'] = true;
      this.spinnerFlag = true;
      this.httpService.addRecord('addUser', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.router.navigateByUrl('/regsuccess');
        } else {
          this.router.navigateByUrl('/regdenied');
        }
      }, error => {
        // console.log(error);
      });
    }
  }
}
