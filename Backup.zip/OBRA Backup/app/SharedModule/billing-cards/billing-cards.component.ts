import { Component, OnInit , Input, Output, EventEmitter} from '@angular/core';
import { WebService } from '../../Service/webservice';
import { Router , ActivatedRoute} from '@angular/router';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-billing-cards',
  templateUrl: './billing-cards.component.html',
  styleUrls: ['./billing-cards.component.css']
})
export class BillingCardsComponent implements OnInit {

  private billingsId: boolean;
  private subtotal: any;
  private total: any;
  private costClient: any;
  private badgeClass: any;
  private isEditable: boolean;
  private monthMap: any;
  private monthStr: String;
  private spinnerFlag;
  private noteCount: any;
  private billingObj: any = {};
  // private url: any;
  @Input() billDetails: any;
  @Input() openclose: any;
  @Output() notifyBillingsId: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();
  @Output() editBillingId: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();

  constructor(private httpService: WebService, private router: Router) {
    this.monthMap  = {'1': 'January', '2': 'February', '3': 'March', '4': 'April', '5' : 'May', '6' : 'June', '7': 'July', '8' : 'August',
    '9': 'September', '10' : 'October', '11' : 'November', '12': 'December'};
  }


  ngOnInit() {
    this.billingsId = this.billDetails.billingsId;
    this.subtotal = this.billDetails.directLabor + this.billDetails.otherLabor + this.billDetails.otherCosts;
    this.total =  this.subtotal + this.billDetails.computedIndirect;
    this.costClient = this.total / this.billDetails.numberOfReviews;
    this.monthStr = this.monthMap[this.billDetails.month];
    if (this.billDetails.rateChanged === 'T') {
      this.badgeClass  = 'badge-red';
      this.isEditable = false;
    } else {
      this.badgeClass  = 'badge-green';
      this.isEditable = true;
    }
    if (this.billDetails.billingsId !== null) {
      this.spinnerFlag = true;
      this.httpService.getRecord('countNotes?billingsId=' + this.billDetails.billingsId).subscribe(res => {
          this.spinnerFlag = false;
          this.noteCount =  res;
      }, error => {
        this.spinnerFlag = false;
        this.noteCount =  0;
      });
    }
  }

  getBillingNotes(billingsId) {
    this.notifyBillingsId.emit(billingsId);
  }
  editBilling(billDetails, action) { // 1- Edit Billing   2  - Adjustment
    this.billingObj.billDetails = billDetails;
    this.billingObj.action = action;
    this.editBillingId.emit(this.billingObj);
  }

}
