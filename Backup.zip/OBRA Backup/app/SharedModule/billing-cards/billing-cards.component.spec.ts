import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingCardsComponent } from './billing-cards.component';

describe('BillingCardsComponent', () => {
  let component: BillingCardsComponent;
  let fixture: ComponentFixture<BillingCardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillingCardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
