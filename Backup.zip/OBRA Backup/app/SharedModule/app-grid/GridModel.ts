import { ColumnModel } from './ColumnModel';
import { HttpClient } from '@angular/common/http';
export class GridModel {

  gridTitle: string;
  columns: ColumnModel[];
  maxRows: number = 10;
  startIndex: number = 0;
  searchString: string;
  orderBy: string;
  orderType: string;
  jsonData: any;
  dataUrl: string;

  constructor() {
  }

}
