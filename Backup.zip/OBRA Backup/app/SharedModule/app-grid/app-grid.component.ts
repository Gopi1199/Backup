import { Component, OnInit, TemplateRef, AfterViewInit, EventEmitter, Output } from '@angular/core';
import { GridModel } from './GridModel';
import { Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { ActivatedRoute } from '@angular/router';
import { OnChanges } from '@angular/core/src/metadata/lifecycle_hooks';
import { ModalService } from '../../Service/modal.service';
import { dateFormat } from '../../JSON';
import { Router } from '@angular/router';

@Component({
  selector: 'app-app-grid',
  templateUrl: './app-grid.component.html',
  styleUrls: ['./app-grid.component.css']
})
export class AppGridComponent implements AfterViewInit, OnChanges {
  @Input() configUrl: string;
  @Input() dataUrl: string;
  @Input() customColumns: any;
  @Input() template1: TemplateRef<any>;
  @Input() template2: TemplateRef<any>;
  @Input() searchInput: any;
  private gridModel: GridModel;
  data: any;
  errorMessage: string;
  private spinnerFlag: boolean;
  private key: any;
  private selectedRow: any;
  private selectedIndex: any;
  private skip: number;
  private showEntries: number;
  private id;
  private sub;
  private totalRecords: number;
  private messageObj: any = {};
  private dateFormat: any;
  private serviceData: any;
  private columns: any = [];
  private url: any = [];
  private gridDataFlag: boolean;
  @Output() message: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();
  @Output() notify: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();
  constructor(private http: HttpClient, private httpService: WebService, private Activatedroute: ActivatedRoute,
    private modalService: ModalService, private router: Router) {
    this.gridModel = new GridModel();
    this.spinnerFlag = false;
    this.skip = 0;
    this.skip = 0;
    this.showEntries = 10;
    this.dateFormat = dateFormat;
    this.gridDataFlag = false;

  }
  ngAfterViewInit() {
    this.sub = this.Activatedroute.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number
      this.url = this.router.url.split('/');
      if (this.url[2] !== 'consumer-dashboard' && !this.gridDataFlag) {
        this.readJsonConfig();
      }
    });
  }
  ngOnChanges() {
    this.url = this.router.url.split('/');
    if (this.url[2] === 'consumer-dashboard' || 'evaluationdashboard') {
      this.readJsonConfig();
      this.gridDataFlag = true;
    }
  }
  readJsonConfig() {
    this.columns = [];
    this.http.get('/assets/Jsons/' + this.configUrl)
      .subscribe(response => {
        this.gridModel.gridTitle = response['gridTitle'];
        this.gridModel.columns = response['columns'];
        for (let i = 0; i < this.gridModel.columns.length; i++) {
          this.columns.push(this.gridModel.columns[i]);
        }
        this.gridModel.orderBy = response['orderBy'];
        this.gridModel.orderType = response['orderType'];
        this.RefreshAgneciesModal();
      });
  }

  RefreshAgneciesModal() {
    this.data = '';
    this.gridModel.startIndex = this.skip * this.showEntries;
    this.gridModel.maxRows = this.showEntries;
    this.serviceData = {
      'max': this.gridModel.maxRows,
      'skip': this.gridModel.startIndex,
      'orderBy': this.gridModel.orderBy,
      'orderType': this.gridModel.orderType,
      'search': this.searchInput.search

    };
    if (this.serviceData.search) {
      this.spinnerFlag = true;
      this.httpService.getRecordList(this.dataUrl, this.serviceData).subscribe(res => {
        this.messageObj.inline = res.inline;
        this.messageObj.global = res.global;
        this.message.emit(this.messageObj);
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.data = res.data;
          this.totalRecords = res.data.length;
        } else {
          this.spinnerFlag = false;
          // this.modalService.showAlertPopup('Warning', res.statusText, '');
        }
      }, error => {
        this.spinnerFlag = false;
        this.errorMessage = error;
      });
    }
  }
  selectRow(event: any, item: any, selectedIndex: any) {
    this.selectedRow = item;
    this.selectedIndex = selectedIndex;
    this.notify.emit(item);
  }

  selectSortField(value: any) {
    this.gridModel.orderBy = value;
    this.RefreshAgneciesModal();
  }

  sortOrderClick() {
    this.skip = 0;
    if (this.gridModel.orderType === 'asc') {
      this.gridModel.orderType = 'desc';
    } else {
      this.gridModel.orderType = 'asc';
    }
    this.RefreshAgneciesModal();
  }

  showEntriesChange(value: any) {
    this.skip = 0;
    this.showEntries = value;
    this.RefreshAgneciesModal();
  }

  prevClick() {
    if (this.skip > 0) {
      this.skip = this.skip - 1;
    }
    this.RefreshAgneciesModal();
  }

  nextClick() {
    this.skip = this.skip + 1;
    this.RefreshAgneciesModal();
  }
}
