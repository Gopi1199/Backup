import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'ssnFormate'
})
export class SSSNFormate implements PipeTransform {
    transform(value) {
        let str = value.replace(/[A-Za-z$-()\.]/g, '');
        str = str.replace(/[^0-9]/g, '');
        str = str.replace(/[^\d]/g, '');
        str = str.replace(/(\d{3})(\d{2})(\d{4})/, '$1-$2-$3');
        return str;
    }
}
