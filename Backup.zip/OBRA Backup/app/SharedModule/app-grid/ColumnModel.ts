export class ColumnModel {
  columnName: string;
  dataField: string;
  sort: boolean;
  type: string;
  isPrimary: boolean;
}
