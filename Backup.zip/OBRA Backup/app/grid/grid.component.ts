import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {
  @Input() recordSet: any;
  @Input() paginationNumber: any;
  @Input() pageSize: any;
  isDesc: boolean = false;
  column: String = 'name';
  direction: number;
  private key: any;
  private selectedRow: Number;
  @Output() notify: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();
  constructor(
  ) { }

  ngOnInit() {
  }
  sort(property) {
    this.isDesc = !this.isDesc;
    this.column = property;
    this.direction = this.isDesc ? 1 : -1;
  }
  selectRow(event: any, item: any) {
    this.key = this.recordSet['primaryKey'];
    this.selectedRow = item[this.key];
    this.notify.emit(item);
  }
}
