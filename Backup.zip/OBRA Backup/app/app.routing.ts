import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { RegistrationLinkComponent } from './registration-link/registration-link.component';
import { UserRegSuccessComponent } from './user-reg-success/user-reg-success.component';
import { UserRegDeniedComponent } from './user-reg-denied/user-reg-denied.component';
const routes: Routes = [
    { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
    { path: 'login', pathMatch: 'full', component: LoginComponent },
    { path: 'registration', pathMatch: 'full', component: RegistrationComponent },
    { path: 'newuser', pathMatch: 'full', component: RegistrationLinkComponent },
    { path: 'regsuccess', pathMatch: 'full', component: UserRegSuccessComponent },
    { path: 'regdenied', pathMatch: 'full', component: UserRegDeniedComponent },
    { path: 'dashboard', loadChildren: 'app/menu-component/menu-module#MenuModule' },
    { path: '**', redirectTo: '/dashboard', pathMatch: 'full' }
];
export const routing: ModuleWithProviders = RouterModule.forRoot(routes, { useHash: true });
