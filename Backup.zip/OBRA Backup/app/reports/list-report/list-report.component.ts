import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../../Service/authentication.service';
import { CommonServiceService } from '../../Service/common-service.service';
import { WebService } from '../../Service/webservice';

@Component({
  selector: 'app-list-report',
  templateUrl: './list-report.component.html',
  styleUrls: ['./list-report.component.css']
})
export class ListReportComponent implements OnInit, OnDestroy {
    private id;
    private sub;
    roleCodes: any;
    spinnerFlag: boolean = false;
    afterLoad: boolean = false;
    private notificationAll = {};
    private message: any;
    private currentUser: any;
    private reportViews: any;

    constructor(private router: Router, private Activatedroute: ActivatedRoute,
            private commonServiceData: CommonServiceService, private httpService: WebService) {

            this.currentUser = localStorage.getItem('currentUser');

            if (this.currentUser !== null) {
              this.spinnerFlag = true;
              this.httpService.getRecord('fetchRreportListByUser?userName=' + this.currentUser).subscribe(res => {
                if (res.global === 'successMsg@') {
                  this.commonServiceData.sendAuthentication(res);
                  this.spinnerFlag = false;
                  this.reportViews = res.data;
                  this.afterLoad = true;
                } else {
                  // console.log('error');
                }
              }, error => {
                // console.log(error);
              });
            }
    }
    ngOnInit() {
      this.sub = this.Activatedroute.params.subscribe(params => {
        this.id = +params['id']; // (+) converts string 'id' to a number
      });

    }
    

    ngOnDestroy() {
      this.sub.unsubscribe();
    }
    
}
