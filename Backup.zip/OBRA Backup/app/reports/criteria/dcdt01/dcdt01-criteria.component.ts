import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd, Event } from '@angular/router';
import { ValidationService } from '../../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice'; 
import { CommonServiceService } from '../../../Service/common-service.service';

@Component( {
    selector: 'dcdt01-criteria',
    templateUrl: './dcdt01-criteria.component.html',
    styleUrls: ['./dcdt01-criteria.component.css']
} )
export class DCDT01CriteriaReportComponent implements OnInit, OnDestroy {
    private id;
    private sub;
    private currentUser: any;
    private reportCriteriaForm: any;
    private model: any;  
    private dropdownList : any;
    private selectedItems : any;
    dropdownSettings = {};
    private reportTitle : String = '';
    private reportCode:  String = '';
    spinnerFlag: boolean = false;
    afterLoad: boolean = false;
    private message: any;
    private data: any;
    private str: any;
    private startDate: any;
    private endDate: any;
    private datePlaceholder: string = "mm/dd/yyyy";
    constructor( private router: Router, private Activatedroute: ActivatedRoute, private builder: FormBuilder,private http: HttpClient, 
        private commonServiceData: CommonServiceService, private httpService: WebService) {
        console.log(this.reportCode);

    }

    ngOnInit() {
        this.sub = this.Activatedroute.params.subscribe(params => {
            this.reportCode =  params['reportCode']; // (+) converts string 'id' to a number
        });
        
         this.reportCriteriaForm = this.builder.group({
            'cmhboards': ['', Validators.required],
             'startDate': ['', Validators.required] ,
             'endDate': ['', Validators.required]  
          });
        this.FetchCriteria();
       }


     loadCMHMultiselect() {
        this.str = JSON.stringify(this.dropdownList);
        this.str = this.str.replace(/name/g, 'itemName');
        this.dropdownList = JSON.parse(this.str);
        this.selectedItems = [];
        this.dropdownSettings = {
                singleSelection: false,
                text: 'Select',
                enableCheckAll: true,
                selectAllText: 'Select All',
                unSelectAllText: 'UnSelect All',
                enableSearchFilter: false,
                badgeShowLimit: 1,
                selectedLabel: 'Roles selected',
                classes: '',
                disabled: false,
                searchPlaceholderText: 'Search',
                showCheckbox: true,
                noDataLabel: 'No Data Available',
                searchAutofocus: true
        };
      }

      ngOnDestroy() {
        this.sub.unsubscribe();
      }
     
    FetchCriteria() { 
        this.spinnerFlag = true;
        this.httpService.getRecord('criteria?reportCode=' + this.reportCode).subscribe( res => {           
            if ( res.global === 'successMsg@' ) {
                this.spinnerFlag = false; 
                this.model = res.data;
              //  this.reportCode = this.model.reportCode;
                this.reportTitle =  this.model.headerName;
                this.dropdownList = this.model.objects; 
                this.loadCMHMultiselect();
            } else if ( res.global === 'errorMsg@' ) {
                this.spinnerFlag = false;
            }
        }, error => {
            this.spinnerFlag = false;
        } );
    }

    generateReport() {
        this.spinnerFlag = false;
        Object.keys(this.reportCriteriaForm.controls).forEach(field => {
            const control = this.reportCriteriaForm.get(field);
            control.markAsTouched({ onlySelf: true });
          });
        if (this.reportCriteriaForm.valid) { 
            this.data = new Array();
            var selectedValues = "";
             this.selectedItems.forEach(element => {
                selectedValues  = selectedValues +"" +element.id;
              });  
            this.data.push({'id' : 'param_boardId', 'value' : selectedValues}); 
            this.data.push({'id' : 'param_startDate', 'value' : this.startDate.formatted});   
            this.data.push({'id' : 'param_endDate', 'value' : this.endDate.formatted});                  
            this.httpService.generateReport('generatereport?reportCode='+this.reportCode, this.data);
        }
       
    }
}
