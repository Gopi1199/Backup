import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ReportsComponent } from './reports.component';
import { ReportRoutes } from './report-routing';
import { ValidationService } from '../validation/validation.service';
import { HttpModule } from '@angular/http';
import { ListReportComponent } from './list-report/list-report.component';
import { CriteriaReportComponent } from './criteria-report/criteria-report.component';
import { SharedModule } from '../SharedModule/shared.module';  
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { TextMaskModule } from 'angular2-text-mask'; 
import { DCDT01CriteriaReportComponent } from './criteria/dcdt01/dcdt01-criteria.component'; 

@NgModule({
    imports: [
        ReportRoutes,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        HttpModule,
        SharedModule,
        AngularMultiSelectModule,
        TextMaskModule,
            ],
    declarations: [
        ReportsComponent,
        ListReportComponent ,
        CriteriaReportComponent,
        DCDT01CriteriaReportComponent
    ],
    providers: [ValidationService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ReportModule {

}
