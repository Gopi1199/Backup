import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReportsComponent } from './reports.component';
import { ListReportComponent } from './list-report/list-report.component'; 
import { CriteriaReportComponent } from './criteria-report/criteria-report.component'; 
import { DCDT01CriteriaReportComponent } from './criteria/dcdt01/dcdt01-criteria.component'; 
const routes: Routes = [
    { path: '', component: ReportsComponent, pathMatch: 'full' },
    { path: 'list', pathMatch: 'full', component: ListReportComponent }, 
    { path: 'criteria-dcdt01/:reportCode', pathMatch: 'full', component: DCDT01CriteriaReportComponent },
    { path: '**', redirectTo: 'dashboard', pathMatch: 'full' }
];

export const ReportRoutes: ModuleWithProviders = RouterModule.forChild(routes);
