import { Component, AfterViewInit, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { SlimLoadingBarService } from 'ng2-slim-loading-bar';
import { NavigationCancel, Event, NavigationEnd, NavigationError, NavigationStart, Router } from '@angular/router';
import { ModalService } from './Service/modal.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
  title = 'app';

  @ViewChild('popupHolder', { read: ViewContainerRef })
  public popupHolder;
  constructor(private _loadingBar: SlimLoadingBarService, private _router: Router, private modalService: ModalService,
    private viewRef: ViewContainerRef) {
    // subscribe to our router's event here
    this._router.events.subscribe((event: Event) => {
      this.navigationInterceptor(event);

    });
  }
  ngAfterViewInit() {
    ModalService.popupHolder = this.popupHolder;
  }
  /**
   * This is used to intercept and show Loading bar based on the current state of our
   * Router navigation
   * @param {Event} event
   */
  private navigationInterceptor(event: Event): void {
    if (event instanceof NavigationStart) {
      this._loadingBar.start();
    }
    if (event instanceof NavigationEnd) {
      this._loadingBar.complete();
    }

    // Set loading state to false in both of the below events to hide the loader in case a request fails
    if (event instanceof NavigationCancel) {
      this._loadingBar.stop();
    }
    if (event instanceof NavigationError) {
      this._loadingBar.stop();
    }
  }
  isLoginPage() {
    /*if ("LOGIN" == window.location.href.split('/')[3].toUpperCase() || "LOGIN" == window.location.href.split('/')[5].toUpperCase())
      return false;
    else
      return true;*/

    if (window.location.href.indexOf('login') > -1) {
      return false;
    } else {
      return true;
    }

  }
}
