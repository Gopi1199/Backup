import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { CommonServiceService } from '../Service/common-service.service';
import { WebService } from '../Service/webservice';
import { ModalService } from '../Service/modal.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy {
  private id;
  private sub;
  roleCodes: any;
  spinnerFlag: boolean;
  afterLoad: boolean;
  private notificationAll = {};
  private message: any;

  constructor(private router: Router, private Activatedroute: ActivatedRoute,
    private commonServiceData: CommonServiceService, private httpService: WebService, private modalService: ModalService) {

    this.spinnerFlag = true;
    this.httpService.getRecord('findUserPermissions').subscribe(res => {
      // console.log(res);
      if (res.global === 'successMsg@') {
        this.commonServiceData.sendAuthentication(res);
        this.spinnerFlag = false;
        this.roleCodes = res.data;
        this.afterLoad = true;
      } else {
        console.log(res.statusText);
        // this.modalService.showAlertPopup('Warning', res.statusText, '');
      }
    }, error => {
      console.log(error);
    });

  }
  ngOnInit() {
    this.sub = this.Activatedroute.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number
    });
  }
  gotoConsumer() {
    this.router.navigateByUrl('/dashboard/consumer-dashboard');
  }
  gotoEvaluation() {
    this.router.navigateByUrl('/dashboard/evaluationdashboard');
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
