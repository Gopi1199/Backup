import { BrowserModule, } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { routing } from './app.routing';
import { LoginComponent } from './login/login.component';
import { CommonServiceService } from './Service/common-service.service';
import { HttpClientModule } from '@angular/common/http';
import { WebService } from './Service/webservice';
import { HttpModule } from '@angular/http';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ModalModule } from 'ngx-bootstrap/modal';
import { SlimLoadingBarModule } from 'ng2-slim-loading-bar';
import { TextMaskModule } from 'angular2-text-mask';
import { TooltipModule } from 'ngx-bootstrap';
import { RootValidationComponent } from './validation/root-validation/root-validation.component';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { SharedModule } from './SharedModule/shared.module';
import { DateService } from './Service/date.service';
import { ModalService } from './Service/modal.service';
import { ModalComponent } from './SharedModule/modal/modal.component';
import { ModalContentComponent } from './SharedModule/modal/modal.component';
import { ErrorService } from './Service/error-service';
import { ErrorModule } from './error-module/error.module';
// import { RouteReuseStrategy } from '@angular/router';
// import { AppRouteReuseStrategy } from './router-state-manager';
import { RegistrationComponent } from './registration/registration.component';
import { RegistrationLinkComponent } from './registration-link/registration-link.component';
import { UserRegSuccessComponent } from './user-reg-success/user-reg-success.component';
import { UserRegDeniedComponent } from './user-reg-denied/user-reg-denied.component';
import { FormWizardModule } from 'angular2-wizard';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RootValidationComponent,
    ModalComponent,
    ModalContentComponent,
    RegistrationComponent,
    RegistrationLinkComponent,
    UserRegSuccessComponent,
    UserRegDeniedComponent,
  ],
  imports: [
    BrowserModule,
    routing,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    HttpModule,
    TextMaskModule,
    AngularMultiSelectModule,
    SlimLoadingBarModule.forRoot(),
    ModalModule.forRoot(),
    TooltipModule.forRoot(),
    SharedModule,
    ErrorModule
    

  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  entryComponents: [
    ModalComponent, ModalContentComponent
  ],
  providers: [CommonServiceService, WebService, BsModalService, DateService, ModalService, ErrorService,
    //    {
    //   provide: RouteReuseStrategy,
    //   useClass: AppRouteReuseStrategy
    // }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
