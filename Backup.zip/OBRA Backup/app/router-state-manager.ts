import { ActivatedRouteSnapshot, DetachedRouteHandle, RouteReuseStrategy } from '@angular/router';

export interface IHandles {
    [key: string]: DetachedRouteHandle;
}

export class AppRouteReuseStrategy implements RouteReuseStrategy {
    private _handles: IHandles = {};

    get handles(): IHandles {
        return this._handles;
    }

    shouldDetach(route: ActivatedRouteSnapshot): boolean {
        // console.log('shouldDetach');
        const key = this.getKey(route);
        const result = !(!route.routeConfig || route.routeConfig.loadChildren);
        /* console.log('shouldDetach:');
        console.log(route);
        console.log(key);
        console.log(result);
        console.log('--------------------------------'); */
        return result;
    }

    store(route: ActivatedRouteSnapshot, handle: DetachedRouteHandle): void {
        // console.log('store');
        const key = this.getKey(route);
        this._handles[key] = handle;
        // console.log(this._handles);
        /* console.log('store:');
        console.log(route);
        console.log(key);
        console.log('--------------------------------'); */
    }

    shouldAttach(route: ActivatedRouteSnapshot): boolean {
        // console.log('shouldAttach');
        const key = this.getKey(route);
        const result = !!route.routeConfig && !!this._handles[key];
        /* console.log('shouldAttach:');
        console.log(route);
        console.log(key);
        console.log(result);
        console.log('--------------------------------'); */
        return result;
    }

    retrieve(route: ActivatedRouteSnapshot): DetachedRouteHandle {
        // console.log('retrieve');
        /* console.log(route.routeConfig); */
        if (!route.routeConfig) {
            return null;
        }
        const key = this.getKey(route);
        return this._handles[key];
    }

    shouldReuseRoute(future: ActivatedRouteSnapshot, curr: ActivatedRouteSnapshot): boolean {
        // console.log('shouldReuseRoute');
        const futureKey = this.getKey(future);
        const currKey = this.getKey(curr);
        /* if (future && future.routeConfig && future.routeConfig.loadChildren) {
            console.log('INSIDE--------------------');
            delete this._handles[currKey];
            return false;
        } */
        /* console.log('shouldReuseRoute:');
        console.log(futureKey);
        console.log(currKey);
        console.log('--------------------------------'); */
        // console.log(futureKey === currKey);
        return false;
    }

    private getUrl(route: ActivatedRouteSnapshot): string {
        if (route.url) {
            if (route.url.length) {
                return route.url.join('/');
            } else {
                if (typeof route.component === 'function') {
                    return `[${route.component.name}]`;
                } else if (typeof route.component === 'string') {
                    return `[${route.component}]`;
                } else {
                    return `[null]`;
                }
            }
        } else {
            return '(null)';
        }
    }

    private getKey(route: ActivatedRouteSnapshot): string {
        return route.pathFromRoot.map(it => this.getUrl(it)).join('/');
    }
}

