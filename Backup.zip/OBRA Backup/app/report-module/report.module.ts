import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { reportRoutes } from './report.routing';
import { ValidationService } from '../validation/validation.service';
import { HttpModule } from '@angular/http';
import { ReportModuleComponent } from './report-module.component';
import { ReportsComponent } from './reports/reports.component';
@NgModule({
    imports: [
        reportRoutes,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        HttpModule,
       
            ],
    declarations: [
        ReportModuleComponent,
        ReportsComponent
    ],
    providers: [ValidationService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ReportModule {

}