import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-module',
  templateUrl: './report-module.component.html',
  styleUrls: ['./report-module.component.css']
})
export class ReportModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
