import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportModuleComponent } from './report-module.component';

describe('ReportModuleComponent', () => {
  let component: ReportModuleComponent;
  let fixture: ComponentFixture<ReportModuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportModuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportModuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
