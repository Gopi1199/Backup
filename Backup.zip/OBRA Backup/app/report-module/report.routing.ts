import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReportModuleComponent } from './report-module.component';
import { ReportsComponent } from './reports/reports.component';
const routes: Routes = [
    { path: '', component: ReportModuleComponent, pathMatch: 'full' },
    { path: 'reportsDashboard', pathMatch: 'full', component: ReportModuleComponent },
    { path: 'reports', pathMatch: 'full', component: ReportsComponent },
    { path: '**', redirectTo: 'dashboard', pathMatch: 'full' }
];
export const reportRoutes: ModuleWithProviders = RouterModule.forChild(routes);