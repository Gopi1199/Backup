import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotificationMethodComponent } from './notification-method.component';

describe('NotificationMethodComponent', () => {
  let component: NotificationMethodComponent;
  let fixture: ComponentFixture<NotificationMethodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotificationMethodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotificationMethodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
