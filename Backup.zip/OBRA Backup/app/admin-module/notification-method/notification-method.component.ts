import { Component, OnInit, TemplateRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ValidationService } from '../../validation/validation.service';
import { ControllerMessageComponent } from '../../validation/controller-message/controller-message.component';
import { recordslimitOptions } from '../../JSON';

@Component({
  selector: 'app-notification-method',
  templateUrl: './notification-method.component.html',
  styleUrls: ['./notification-method.component.css']
})
export class NotificationMethodComponent implements OnInit {
  private modalRef: BsModalRef;
  private selectedRowId: Number;
  private selectedRowData: any;
  private deactiveMsgFlag: boolean = false;
  private deactiveMsg: String = '';
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private spinnerFlag: boolean = false;
  NotificationMethodList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  NotificationMethodGridData: any = {
    'gridName': 'Notification Method',
    'primaryKey': 'notificationMethodsId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Description', dataField: 'description', width: '80%', sort: true, sortColumn: 'description' },
      { caption: 'Default Flag', dataField: 'defaultFlag', width: '10%', sort: true, sortColumn: 'defaultFlag' },
      { caption: 'Active', dataField: 'active', width: '10%', sort: true, sortColumn: 'active' }
    ]
  };
  mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {
    // this.data = {
    //   'InputFields': [{ 'cmhBoardId': 100 }],
    //   'SortFields': [{ 'cmhBoardId': 100 }],
    //   'startIndex': 0,
    //   'maxResults': 100,
    //   'orderBy': 'cmhBoardId'
    // };
    this.limitOptions = recordslimitOptions;
    this.RefreshNotificationMethodModal();
  }
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.NotificationMethodList.length / event);
    this.pageSize = event;
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.notificationMethodsId;

  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
  }
  AddNotificationMethodModal(AddNotificationMethod: TemplateRef<any>) {
    this.messageFlag = false;
    this.notifyMsg = '';
    this.modalRef = this.modalService.show(AddNotificationMethod);
  }
  RefreshNotificationMethodModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('notificationMethodList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.NotificationMethodList = res.data;
        this.NotificationMethodGridData.tableData = this.NotificationMethodList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
  EditNotificationMethodModal(EditNotificationMethod: TemplateRef<any>, SelectNotificationMethod: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.spinnerFlag = true;
      this.messageFlag = false;
      this.notifyMsg = '';
      this.httpService.getRecord('findNotificationMethodListById?notificationMethodListById=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
          this.modalRef = this.modalService.show(EditNotificationMethod);
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });


    } else {
      this.modalRef = this.modalService.show(SelectNotificationMethod);
    }
  }
  ViewNotificationMethodModal(ViewNotificationMethod: TemplateRef<any>, SelectNotificationMethod: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(ViewNotificationMethod);
      this.spinnerFlag = true;
      this.httpService.deleteRecord('findNotificationMethodListById?notificationMethodListById=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectNotificationMethod);
    }
  }
  DeleteNotificationMethodModal(DeleteNotificationMethod: TemplateRef<any>, SelectNotificationMethod: TemplateRef<any>) {
    this.deactiveMsgFlag = false;
    this.deactiveMsg = '';
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(DeleteNotificationMethod);
    } else {
      this.modalRef = this.modalService.show(SelectNotificationMethod);
    }
  }
  SearchNotificationMethodModal(SearchNotificationMethod: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchNotificationMethod);
  }
}
