import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import {dateFormat} from '../../../JSON';
@Component({
  selector: 'app-edit-notification-method',
  templateUrl: './edit-notification-method.component.html',
  styleUrls: ['./edit-notification-method.component.css']
})
export class EditNotificationMethodComponent implements OnInit {
  private editNotificationMethodForm: any;
  private data: Object;
  spinnerFlag: boolean = false;
  private disablePre: Boolean = false;
  private disableNxt: Boolean = false;
  private currentIdx: any;
  private currentRecId: any;
  private nextIdx: any;
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private selectedRowId: Number;
  private setClickedRow: Function;
  private dateFormat: any;
  NotificationMethodList: Array<any> = [];
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  private recordsAll: any;
  private recCount: any;
  @Input() NotificationMethodGridData: any;
  @Input() modalRef: any;
  @Output() currentId: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();
  @Input() selectedRowData: any;
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) {
    this.dateFormat = dateFormat;
   }

  ngOnInit() {
    this.recordsAll = JSON.parse(localStorage.getItem('recAll'));
    this.recCount = this.recordsAll.length - 1;
    if (Number(localStorage.getItem('currentIndex')) === 1) {
      this.disablePre = true;
    } else if (Number(localStorage.getItem('currentIndex')) === this.recCount) {
      this.disableNxt = true;
    }
    this.editNotificationMethodForm = new FormGroup({
      'description': new FormControl('', [Validators.required]),
      'defaultFlag': new FormControl('', [Validators.required]),
      'active': new FormControl('', [Validators.required]),
      'createdBy': new FormControl(''),
      'createdOn': new FormControl(''),
      'modifiedBy': new FormControl(''),
      'modifiedOn': new FormControl('')
    });
  }
  RefreshNotificationMethodModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('notificationMethodList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.NotificationMethodList = res.data;
        this.NotificationMethodGridData.tableData = this.NotificationMethodList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
  editNotificationMethodSubmit(event: any) {
    console.log(this.editNotificationMethodForm.valid);
    Object.keys(this.editNotificationMethodForm.controls).forEach(field => {
      const control = this.editNotificationMethodForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.editNotificationMethodForm.valid) {
      this.data = this.editNotificationMethodForm.value;
      this.data['notificationMethodsId'] = this.selectedRowData.notificationMethodsId;
      this.spinnerFlag = true;
      this.notifyMsg = '';
      this.messageFlag = false;
      this.httpService.updateRecord('editNotificationMethods', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.messageFlag = true;
          this.notifyMsg = 'Record updated successfully';
          setTimeout(() => {
            this.modalRef.hide();
          }, 2000);
          this.RefreshNotificationMethodModal();
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });

    }
  }

  EditNotificationMethodModal(id) {
    this.spinnerFlag = true;
    this.httpService.getRecord('findNotificationMethodListById?notificationMethodListById=' + id).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.selectedRowData = res.data;

      } else {
        console.log('error');
      }
    }, error => {
      console.log(error);
    });
  }
  recordNavigation(action) {

    this.disablePre = false;
    this.disableNxt = false;
    const recordsAll: any = JSON.parse(localStorage.getItem('recAll'));
    this.currentIdx = localStorage.getItem('currentIndex');

    if (action === 'previous') {
      this.currentRecId = recordsAll[Number(this.currentIdx) - 1];
      this.currentIdx = Number(this.currentIdx) - 1;
    } else {
      this.currentRecId = recordsAll[Number(this.currentIdx) + 1];
      this.currentIdx = Number(this.currentIdx) + 1;
    }
    if (this.currentIdx === 1) {
      this.disablePre = true;
    }
    if (this.currentIdx === this.recCount) {
      this.disableNxt = true;
    }
    localStorage.setItem('currentIndex', this.currentIdx);
    const list = Array.from(document.getElementById('gridTable').querySelectorAll('tbody tr'));
    list.forEach(function(node) { node.className = ''; }) ;
    document.getElementById(this.currentRecId).classList.add('highlighted');
    this.EditNotificationMethodModal(this.currentRecId);
    this.currentId.emit(this.currentRecId);
  }


}
