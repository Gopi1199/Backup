import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditNotificationMethodComponent } from './edit-notification-method.component';

describe('EditNotificationMethodComponent', () => {
  let component: EditNotificationMethodComponent;
  let fixture: ComponentFixture<EditNotificationMethodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditNotificationMethodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditNotificationMethodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
