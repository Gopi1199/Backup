import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteNotificationMethodComponent } from './delete-notification-method.component';

describe('DeleteNotificationMethodComponent', () => {
  let component: DeleteNotificationMethodComponent;
  let fixture: ComponentFixture<DeleteNotificationMethodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteNotificationMethodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteNotificationMethodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
