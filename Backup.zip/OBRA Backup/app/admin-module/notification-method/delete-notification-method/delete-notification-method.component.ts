import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';

@Component({
  selector: 'app-delete-notification-method',
  templateUrl: './delete-notification-method.component.html',
  styleUrls: ['./delete-notification-method.component.css']
})
export class DeleteNotificationMethodComponent implements OnInit {
  spinnerFlag: boolean = false;
  @Input() selectedRowId: any;
  @Input() modalRef: any;
  @Input() NotificationMethodGridData: any;
  data: Object;
  NotificationMethodList: Array<any> = [];
  private deactiveMsgFlag: boolean = false;
  private deactiveMsg: String = '';
  constructor(private httpService: WebService) {
  }
  ngOnInit() {
  }
  deleteNotificationMethod() {
    // console.log(this.selectedRowId);
    this.spinnerFlag = true;
    this.httpService.deleteRecord('deleteNotificationMethodListById?notificationMethodListById=' + this.selectedRowId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.deactiveMsgFlag = true;
        this.deactiveMsg = 'Record deactivated successfully';
        setTimeout(() => {
          this.modalRef.hide();
        }, 2000);
        this.RefreshNotificationMethodModal();
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
  RefreshNotificationMethodModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('notificationMethodList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.NotificationMethodList = res.data;
        this.NotificationMethodGridData.tableData = this.NotificationMethodList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
}
