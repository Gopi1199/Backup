import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ValidationService } from '../../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { WebService } from '../../../Service/webservice';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

@Component({
  selector: 'app-add-notification-method',
  templateUrl: './add-notification-method.component.html',
  styleUrls: ['./add-notification-method.component.css']
})
export class AddNotificationMethodComponent implements OnInit {
  @Input() modalRef: any;
  @Input() NotificationMethodGridData: any;
  private addNotificationMethodForm: any;
  private data: Object;
  private addAgenciesValidateFlag: boolean = false;
  private addAgenciesValidationMsg: String = '';
  spinnerFlag: boolean = false;
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  NotificationMethodList: Array<any> = [];
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  // mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.addNotificationMethodForm = new FormGroup({
      'description': new FormControl('', [Validators.required]),
      'defaultFlag': new FormControl('', [Validators.required]),
      'active': new FormControl('', [Validators.required]),
      'createdBy': new FormControl(''),
      'createdOn': new FormControl(''),
      'modifiedBy': new FormControl(''),
      'modifiedOn': new FormControl('')
    });
  }
  RefreshNotificationMethodModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('notificationMethodList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.NotificationMethodList = res.data;
        this.NotificationMethodGridData.tableData = this.NotificationMethodList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }

  addNotificationMethodSubmit(event: any) {
    Object.keys(this.addNotificationMethodForm.controls).forEach(field => {
      const control = this.addNotificationMethodForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.addNotificationMethodForm.valid) {
      this.data = this.addNotificationMethodForm.value;
      this.spinnerFlag = true;
      this.messageFlag = false;
      this.notifyMsg = '';
      this.httpService.addRecord('editNotificationMethods', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.messageFlag = true;
          this.notifyMsg = 'Record added successfully';
          this.RefreshNotificationMethodModal();
          setTimeout(() => {
            this.modalRef.hide();
          }, 2000);
          this.RefreshNotificationMethodModal();
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });

    }
    // console.log('addNotificationMethodForm:' + JSON.stringify(this.addNotificationMethodForm.value));
  }
}
