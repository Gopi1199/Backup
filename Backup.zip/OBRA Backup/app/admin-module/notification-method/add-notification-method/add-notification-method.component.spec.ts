import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNotificationMethodComponent } from './add-notification-method.component';

describe('AddNotificationMethodComponent', () => {
  let component: AddNotificationMethodComponent;
  let fixture: ComponentFixture<AddNotificationMethodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddNotificationMethodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddNotificationMethodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
