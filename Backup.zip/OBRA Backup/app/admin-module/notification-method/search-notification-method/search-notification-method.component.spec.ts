import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchNotificationMethodComponent } from './search-notification-method.component';

describe('SearchNotificationMethodComponent', () => {
  let component: SearchNotificationMethodComponent;
  let fixture: ComponentFixture<SearchNotificationMethodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchNotificationMethodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchNotificationMethodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
