import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AdminRoutes } from './admin-routing';
import { ValidationService } from '../validation/validation.service';
// import { AdminDashboardComponent } from '.-dashboard/admin-dashboard.component';
import { AgenciesComponent } from './agencies/agencies.component';
import { AxisOneTwoComponent } from './axis-one-two/axis-one-two.component';
import { DeterminationComponent } from './determination/determination.component';
import { DiagnosisCategoriesComponent } from './diagnosis-categories/diagnosis-categories.component';
import { MissingInformationComponent } from './missing-information/missing-information.component';
import { TerminationComponent } from './termination/termination.component';
// import { HeaderComponent } from '../header-component/header-component.component';
import { Axis3Component } from './axis3/axis3.component';
import { CareFacilitiesComponent } from './care-facilities/care-facilities.component';
import { CMHBoardComponent } from './cmhboard/cmhboard.component';
import { CMHRecommendationComponent } from './cmhrecommendation/cmhrecommendation.component';
import { DischargeComponent } from './discharge/discharge.component';
import { EvaluationTypeComponent } from './evaluation-type/evaluation-type.component';
import { FacilityTypesComponent } from './facility-types/facility-types.component';
import { NotificationMethodComponent } from './notification-method/notification-method.component';
import { NotifiedPersonComponent } from './notified-person/notified-person.component';
import { RelationshipComponent } from './relationship/relationship.component';
import { RepresentativeTypeComponent } from './representative-type/representative-type.component';
import { ServiceProvidersComponent } from './service-providers/service-providers.component';
// import { OrderrByPipe } from '../grid/orderPipe';
import { HttpModule } from '@angular/http';
// import { GridComponent } from '../grid/grid.component';
import { TextMaskModule } from 'angular2-text-mask';
// import { ControllerMessageComponent } from '../validation/controller-message/controller-message.component';
// import { NgxPaginationModule } from 'ngx-pagination';
import { AddItemsComponent } from './/agencies/add-items/add-items.component';
import { EditItemComponent } from './agencies/edit-item/edit-item.component';
import { ViewItemComponent } from './agencies/view-item/view-item.component';
import { DeleteItemComponent } from './agencies/delete-item/delete-item.component';
import { SearchItemComponent } from './agencies/search-item/search-item.component';
import { AddDiagnosesComponent } from './axis-one-two/add-diagnoses/add-diagnoses.component';
import { EditDiagnosesComponent } from './axis-one-two/edit-diagnoses/edit-diagnoses.component';
import { ViewDiagnosesComponent } from './axis-one-two/view-diagnoses/view-diagnoses.component';
import { DeleteDiagnosesComponent } from './axis-one-two/delete-diagnoses/delete-diagnoses.component';
import { SearchDiagnosesComponent } from './axis-one-two/search-diagnoses/search-diagnoses.component';
import { AddICDDiagnosesComponent } from './axis3/add-icddiagnoses/add-icddiagnoses.component';
import { EditICDDiagnosesComponent } from './axis3/edit-icddiagnoses/edit-icddiagnoses.component';
import { ViewICDDiagnosesComponent } from './axis3/view-icddiagnoses/view-icddiagnoses.component';
import { DeleteICDDiagnosesComponent } from './axis3/delete-icddiagnoses/delete-icddiagnoses.component';
import { SearchICDDiagnosesComponent } from './axis3/search-icddiagnoses/search-icddiagnoses.component';
import { AddFacilitiesComponent } from './care-facilities/add-facilities/add-facilities.component';
import { EditFacilitiesComponent } from './care-facilities/edit-facilities/edit-facilities.component';
import { ViewFacilitiesComponent } from './care-facilities/view-facilities/view-facilities.component';
import { DeleteFacilitiesComponent } from './care-facilities/delete-facilities/delete-facilities.component';
import { SearchFacilitiesComponent } from './care-facilities/search-facilities/search-facilities.component';
import { AddCMHBoardsComponent } from './cmhboard/add-cmhboards/add-cmhboards.component';
import { EditCMHBoardsComponent } from './cmhboard/edit-cmhboards/edit-cmhboards.component';
import { ViewCMHBoardsComponent } from './cmhboard/view-cmhboards/view-cmhboards.component';
import { DeleteCMHBoardsComponent } from './cmhboard/delete-cmhboards/delete-cmhboards.component';
import { SearchCMHBoardsComponent } from './cmhboard/search-cmhboards/search-cmhboards.component';
import { ViewRecommendationComponent } from './cmhrecommendation/view-recommendation/view-recommendation.component';
import { SearchRecommendationComponent } from './cmhrecommendation/search-recommendation/search-recommendation.component';
import { ViewDeterminationComponent } from './determination/view-determination/view-determination.component';
import { SearchDeterminationComponent } from './determination/search-determination/search-determination.component';
import { ViewDiagnosisCategoriesComponent } from './diagnosis-categories/view-diagnosis-categories/view-diagnosis-categories.component';
import { SearchDiagnosisCategoriesComponent } from './diagnosis-categories/search-diagnosis-categories/search-diagnosis-categories.component';
import { ViewDischargeComponent } from './discharge/view-discharge/view-discharge.component';
import { SearchDischargeComponent } from './discharge/search-discharge/search-discharge.component';
import { ViewEvaluationComponent } from './evaluation-type/view-evaluation/view-evaluation.component';
import { SearchEvaluationComponent } from './evaluation-type/search-evaluation/search-evaluation.component';
import { AddFacilityTypeComponent } from './facility-types/add-facility-type/add-facility-type.component';
import { ViewFacilityTypeComponent } from './facility-types/view-facility-type/view-facility-type.component';
import { EditFacilityTypeComponent } from './facility-types/edit-facility-type/edit-facility-type.component';
import { DeleteFacilityTypeComponent } from './facility-types/delete-facility-type/delete-facility-type.component';
import { SearchFacilityTypeComponent } from './facility-types/search-facility-type/search-facility-type.component';
import { ViewMissingTypeComponent } from './missing-information/view-missing-type/view-missing-type.component';
import { SearchMissingTypeComponent } from './missing-information/search-missing-type/search-missing-type.component';
import { AddNotifiedPersonComponent } from './notified-person/add-notified-person/add-notified-person.component';
import { EditNotifiedPersonComponent } from './notified-person/edit-notified-person/edit-notified-person.component';
import { ViewNotifiedPersonComponent } from './notified-person/view-notified-person/view-notified-person.component';
import { DeleteNotifiedPersonComponent } from './notified-person/delete-notified-person/delete-notified-person.component';
import { SearchNotifiedPersonComponent } from './notified-person/search-notified-person/search-notified-person.component';
import { AddNotificationMethodComponent } from './notification-method/add-notification-method/add-notification-method.component';
import { EditNotificationMethodComponent } from './notification-method/edit-notification-method/edit-notification-method.component';
import { ViewNotificationMethodComponent } from './notification-method/view-notification-method/view-notification-method.component';
import { DeleteNotificationMethodComponent } from './notification-method/delete-notification-method/delete-notification-method.component';
import { SearchNotificationMethodComponent } from './notification-method/search-notification-method/search-notification-method.component';
import { AddRelationshipComponent } from './relationship/add-relationship/add-relationship.component';
import { EditRelationshipComponent } from './relationship/edit-relationship/edit-relationship.component';
import { ViewRelationshipComponent } from './relationship/view-relationship/view-relationship.component';
import { DeleteRelationshipComponent } from './relationship/delete-relationship/delete-relationship.component';
import { SearchRelationshipComponent } from './relationship/search-relationship/search-relationship.component';
import { AddRepresentativeComponent } from './representative-type/add-representative/add-representative.component';
import { EditRepresentativeComponent } from './representative-type/edit-representative/edit-representative.component';
import { ViewRepresentativeComponent } from './representative-type/view-representative/view-representative.component';
import { DeleteRepresentativeComponent } from './representative-type/delete-representative/delete-representative.component';
import { SearchRepresentativeComponent } from './representative-type/search-representative/search-representative.component';
import { AddServiceProvidersComponent } from './service-providers/add-service-providers/add-service-providers.component';
import { EditServiceProvidersComponent } from './service-providers/edit-service-providers/edit-service-providers.component';
import { ViewServiceProvidersComponent } from './service-providers/view-service-providers/view-service-providers.component';
import { DeleteServiceProvidersComponent } from './service-providers/delete-service-providers/delete-service-providers.component';
import { SearchServiceProvidersComponent } from './service-providers/search-service-providers/search-service-providers.component';
import { SearchTerminationComponent } from './termination/search-termination/search-termination.component';
import { ViewTerminationComponent } from './termination/view-termination/view-termination.component';
import { AdminMainComponent } from './admin-main/admin-main.component';
import { SharedModule } from '../SharedModule/shared.module';
import { RolesComponent } from './roles/roles.component';
import { SearchRoleComponent } from './roles/search-role/search-role.component';
import { AddRolesComponent } from './roles/add-roles/add-roles.component';
import { RoleDetailComponent } from './roles/role-detail/role-detail.component';
import { EditRoleComponent } from './roles/edit-role/edit-role.component';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
@NgModule({
    imports: [
        AdminRoutes,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        TextMaskModule,
        SharedModule,
        AngularMultiSelectModule
    ],
    declarations: [
        AgenciesComponent,
        AxisOneTwoComponent,
        DeterminationComponent,
        DiagnosisCategoriesComponent,
        MissingInformationComponent,
        AdminMainComponent,
        // HeaderComponent,
        TerminationComponent,
        Axis3Component,
        CareFacilitiesComponent,
        CMHBoardComponent,
        CMHRecommendationComponent,
        DischargeComponent,
        EvaluationTypeComponent,
        FacilityTypesComponent,
        NotificationMethodComponent,
        NotifiedPersonComponent,
        RelationshipComponent,
        RepresentativeTypeComponent,
        ServiceProvidersComponent,
        // OrderrByPipe,
        // GridComponent,
        // ControllerMessageComponent,
       
        AddItemsComponent,
        EditItemComponent,
        ViewItemComponent,
        DeleteItemComponent,
        SearchItemComponent,
        AddDiagnosesComponent,
        EditDiagnosesComponent,
        ViewDiagnosesComponent,
        DeleteDiagnosesComponent,
        SearchDiagnosesComponent,
        AddICDDiagnosesComponent,
        EditICDDiagnosesComponent,
        ViewICDDiagnosesComponent,
        DeleteICDDiagnosesComponent,
        SearchICDDiagnosesComponent,
        AddFacilitiesComponent,
        EditFacilitiesComponent,
        ViewFacilitiesComponent,
        DeleteFacilitiesComponent,
        SearchFacilitiesComponent,
        AddCMHBoardsComponent,
        EditCMHBoardsComponent,
        ViewCMHBoardsComponent,
        DeleteCMHBoardsComponent,
        SearchCMHBoardsComponent,
        ViewRecommendationComponent,
        SearchRecommendationComponent,
        ViewDeterminationComponent,
        SearchDeterminationComponent,
        ViewDiagnosisCategoriesComponent,
        SearchDiagnosisCategoriesComponent,
        ViewDischargeComponent,
        SearchDischargeComponent,
        ViewEvaluationComponent,
        SearchEvaluationComponent,
        AddFacilityTypeComponent,
        ViewFacilityTypeComponent,
        EditFacilityTypeComponent,
        DeleteFacilityTypeComponent,
        SearchFacilityTypeComponent,
        ViewMissingTypeComponent,
        SearchMissingTypeComponent,
        AddNotifiedPersonComponent,
        EditNotifiedPersonComponent,
        ViewNotifiedPersonComponent,
        DeleteNotifiedPersonComponent,
        SearchNotifiedPersonComponent,
        AddNotificationMethodComponent,
        EditNotificationMethodComponent,
        ViewNotificationMethodComponent,
        DeleteNotificationMethodComponent,
        SearchNotificationMethodComponent,
        AddRelationshipComponent,
        EditRelationshipComponent,
        ViewRelationshipComponent,
        DeleteRelationshipComponent,
        SearchRelationshipComponent,
        AddRepresentativeComponent,
        EditRepresentativeComponent,
        ViewRepresentativeComponent,
        DeleteRepresentativeComponent,
        SearchRepresentativeComponent,
        AddServiceProvidersComponent,
        EditServiceProvidersComponent,
        ViewServiceProvidersComponent,
        DeleteServiceProvidersComponent,
        SearchServiceProvidersComponent,
        SearchTerminationComponent,
        ViewTerminationComponent,
        RolesComponent,
        SearchRoleComponent,
        AddRolesComponent,
        EditRoleComponent,
        RoleDetailComponent
    ],
    providers: [ValidationService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AdminModule {

}
