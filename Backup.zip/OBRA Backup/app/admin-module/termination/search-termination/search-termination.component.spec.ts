import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchTerminationComponent } from './search-termination.component';

describe('SearchTerminationComponent', () => {
  let component: SearchTerminationComponent;
  let fixture: ComponentFixture<SearchTerminationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchTerminationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchTerminationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
