import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-search-termination',
  templateUrl: './search-termination.component.html',
  styleUrls: ['./search-termination.component.css']
})
export class SearchTerminationComponent implements OnInit {
  private searchTerminationForm: any;
  private searchMsgFlag: boolean = true;
  private searchError: String;
  spinnerFlag: boolean = false;
  data: Object;
  private filter: any;
  private searchInput: Object;
  private searchsuccess: String;
  private searchErrorMsgFlag: boolean = false;
  @Input() terminationGridData: any;
  @Input() modalRef: any;
  terminationList: Array<any> = [];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.searchTerminationForm = this.formBuilder.group({
      'id': [''],
      'value': ['']
    });
  }
  SearchReset() {
    this.searchTerminationForm.reset();
  }
  SearchTerminationSubmit() {
    this.filter = { filters: [this.searchTerminationForm.value] };
    this.searchInput = {
      'max': 100,
      'skip': 0,
      'orderBy': '',
      'orderType': 'asc',
      'search': JSON.stringify(this.filter)
    };
    this.spinnerFlag = true;
    this.httpService.searchRecord('terminationTypeList', this.searchInput).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.terminationList = res.data;
        this.terminationGridData.tableData = this.terminationList;
        if (res.data.length === 0) {
          this.searchErrorMsgFlag = true;
          this.searchMsgFlag = false;
          this.searchError = 'Records Not found';

        } else {
          this.searchMsgFlag = true;
          this.searchErrorMsgFlag = false;
          this.searchsuccess = 'Records found';
        }
        
      } else {
        this.searchMsgFlag = true;
        this.searchMsgFlag = false;
        this.searchError = 'No records found';
        
      }

    }, error => {
      console.log(error);
    });
  }

}
