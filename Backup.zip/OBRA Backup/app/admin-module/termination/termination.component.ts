import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { recordslimitOptions } from '../../JSON';

@Component({
  selector: 'app-termination',
  templateUrl: './termination.component.html',
  styleUrls: ['./termination.component.css']
})
export class TerminationComponent implements OnInit {
  private modalRef: BsModalRef;
  private selectedRowData: any;
  private selectedRowId: Number;
  private spinnerFlag: boolean = false;
  terminationList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  terminationGridData: any = {
    'gridName': 'CMH Terminations',
    'primaryKey': 'terminationTypesId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Code', dataField: 'code', width: '10%', sort: true, sortColumn: 'code' },
      { caption: 'Description', dataField: 'description', width: '70%', sort: true, sortColumn: 'description' },
      { caption: 'Default Flag', dataField: 'defaultFlag', width: '10%', sort: true, sortColumn: 'defaultFlag' },
      { caption: 'Active', dataField: 'active', width: '10%', sort: true, sortColumn: 'active' }
    ]
  };

  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.limitOptions = recordslimitOptions;
    this.refreshTerminationModal();
  }
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.terminationList.length / event);
    this.pageSize = event;
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.terminationTypesId;
  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
  }
  refreshTerminationModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('terminationTypeList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.terminationList = res.data;
        this.terminationGridData.tableData = this.terminationList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }

  ViewTerminationModal(ViewTermination: TemplateRef<any>, SelectTermination: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(ViewTermination);
      this.spinnerFlag = true;
      this.httpService.deleteRecord('viewTerminationType?terminationTypeId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectTermination);
    }
  }

  SearchTerminationModal(SearchTermination: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchTermination);
  }
}
