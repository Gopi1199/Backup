import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchDischargeComponent } from './search-discharge.component';

describe('SearchDischargeComponent', () => {
  let component: SearchDischargeComponent;
  let fixture: ComponentFixture<SearchDischargeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchDischargeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchDischargeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
