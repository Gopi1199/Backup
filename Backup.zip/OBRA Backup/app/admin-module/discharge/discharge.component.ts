import { Component, OnInit, TemplateRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ValidationService } from '../../validation/validation.service';

@Component({
  selector: 'app-discharge',
  templateUrl: './discharge.component.html',
  styleUrls: ['./discharge.component.css']
})

export class DischargeComponent implements OnInit {
  private modalRef: BsModalRef;
  private selectedRow: Number;
  private selectedRowData: any;
  private selectedRowId: Number;
  private spinnerFlag: boolean = false;
  dischargeList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  dischargeGridData: any = {
    'gridName': 'Discharge',
    'primaryKey': 'dischargesId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Description', dataField: 'description', width: '35%', sort: true, sortColumn: 'description' },
      { caption: 'Short Name', dataField: 'defaultFlag', width: '10%',  sort: true, sortColumn: 'defaultFlag' },
      { caption: 'Active', dataField: 'active', width: '10%',  sort: true, sortColumn: 'active' }
    ]
  };

  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.RefreshDischargeModal();
  }
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.dischargeList.length / event);
    this.pageSize = event;
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.dischargesId;

  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
  }
  RefreshDischargeModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('searchDischargess', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.dischargeList = res.data;
        this.dischargeGridData.tableData = this.dischargeList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }

  ViewDischargeModal(ViewDischarge: TemplateRef<any>, SelectDischarge: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(ViewDischarge);
      this.spinnerFlag = true;
      this.httpService.deleteRecord('viewDischarges?dischargesId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectDischarge);
    }
  }

  SearchDischargeModal(SearchDischarge: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchDischarge);
  }

}
