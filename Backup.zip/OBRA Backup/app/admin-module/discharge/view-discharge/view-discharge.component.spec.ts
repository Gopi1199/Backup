import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewDischargeComponent } from './view-discharge.component';

describe('ViewDischargeComponent', () => {
  let component: ViewDischargeComponent;
  let fixture: ComponentFixture<ViewDischargeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewDischargeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewDischargeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
