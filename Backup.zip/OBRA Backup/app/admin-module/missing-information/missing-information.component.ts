import { Component, OnInit, TemplateRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ValidationService } from '../../validation/validation.service';
import { recordslimitOptions } from '../../JSON';

@Component({
  selector: 'app-missing-information',
  templateUrl: './missing-information.component.html',
  styleUrls: ['./missing-information.component.css']
})
export class MissingInformationComponent implements OnInit {
  private modalRef: BsModalRef;
  private selectedRowData: any;
  private selectedRowId: Number;
  private spinnerFlag: boolean = false;
  missingTypeList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  missingTypeGridData: any = {
    'gridName': 'MissingType',
    'primaryKey': 'missingInformationTypesId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Description', dataField: 'description', width: '70%', sort: true, sortColumn: 'description' },
      { caption: 'Source Type', dataField: 'sourceType', width: '20%', sort: true, sortColumn: 'sourceType'  },
      { caption: 'Active', dataField: 'active', width: '10%', sort: true, sortColumn: 'active'  }
    ]
  };

  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.limitOptions = recordslimitOptions;
    this.RefreshMissingTypeModal();
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.missingInformationTypesId;
  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
  }
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.missingTypeList.length / event);
    this.pageSize = event;
  }
  RefreshMissingTypeModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('missingInfoTypeList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.missingTypeList = res.data;
        this.missingTypeGridData.tableData = this.missingTypeList;
      } else {
        console.log('error');
      }
    }, error => {
      console.log(error);
    });
  }

  ViewMissingTypeModal(ViewMissingType: TemplateRef<any>, SelectMissingType: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(ViewMissingType);
      this.spinnerFlag = true;
      this.httpService.deleteRecord('viewMissingInfoTypes?missingInfoTypesId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
        } else {
          console.log('error');
        }
      }, error => {
        console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectMissingType);
    }
  }
  SearchMissingTypeModal(SearchMissingType: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchMissingType);
  }
}
