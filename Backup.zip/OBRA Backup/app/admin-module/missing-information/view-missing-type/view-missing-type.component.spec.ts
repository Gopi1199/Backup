import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMissingTypeComponent } from './view-missing-type.component';

describe('ViewMissingTypeComponent', () => {
  let component: ViewMissingTypeComponent;
  let fixture: ComponentFixture<ViewMissingTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewMissingTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewMissingTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
