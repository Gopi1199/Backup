import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchMissingTypeComponent } from './search-missing-type.component';

describe('SearchMissingTypeComponent', () => {
  let component: SearchMissingTypeComponent;
  let fixture: ComponentFixture<SearchMissingTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchMissingTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchMissingTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
