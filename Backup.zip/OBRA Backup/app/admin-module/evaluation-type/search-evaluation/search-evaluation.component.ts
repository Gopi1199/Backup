import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-search-evaluation',
  templateUrl: './search-evaluation.component.html',
  styleUrls: ['./search-evaluation.component.css']
})
export class SearchEvaluationComponent implements OnInit {
  private searchEvaluationForm: any;
  private searchMsgFlag: boolean = true;
  private searchError: String = '';
  spinnerFlag: boolean = false;
  data: Object;
  private filter: any;
  private searchInput: Object;
  private searchsuccess: String = '';
  private searchErrorMsgFlag: boolean = false;
  @Input() evaluationGridData: any;
  @Input() modalRef: any;
  evaluationList: Array<any> = [];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) { }
  ngOnInit() {
    this.searchEvaluationForm = this.formBuilder.group({
      'id': [''],
      'value': ['']
    });
  }
  SearchReset() {
    this.searchEvaluationForm.reset();
  }
  searchEvaluationSubmit() {

    this.searchError = '';
    this.searchsuccess = '';
    this.filter = { filters: [this.searchEvaluationForm.value] };
    this.searchInput = {
      'max': 100,
      'skip': 0,
      'orderBy': '',
      'orderType': 'asc',
      'search': JSON.stringify(this.filter)
    };

    this.spinnerFlag = true;
    this.httpService.searchRecord('evaluationTypeList', this.searchInput).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.evaluationList = res.data;
        this.evaluationGridData.tableData = this.evaluationList;
        if (res.data.length === 0) {
          this.searchErrorMsgFlag = true;
          this.searchMsgFlag = false;
          this.searchError = 'Records Not found';

        } else {
          this.searchMsgFlag = true;
          this.searchErrorMsgFlag = false;
          this.searchsuccess = 'Records found';
        }
        
      } else {
        this.searchErrorMsgFlag = true;
        this.searchMsgFlag = false;
        this.searchError = 'No records found';
        
      }
    }, error => {
      console.log(error);
    });
  }
}
