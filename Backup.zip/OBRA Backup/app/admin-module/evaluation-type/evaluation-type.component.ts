import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { recordslimitOptions } from '../../JSON';

@Component({
  selector: 'app-evaluation-type',
  templateUrl: './evaluation-type.component.html',
  styleUrls: ['./evaluation-type.component.css']
})
export class EvaluationTypeComponent implements OnInit {
  private modalRef: BsModalRef;
  private selectedRowData: any;
  private selectedRowId: Number;
  private spinnerFlag: boolean = false;
  evaluationList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  evaluationGridData: any = {
    'gridName': 'Evaluation Type',
    'primaryKey': 'evaluationTypeId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Evaluation Type', dataField: 'evaluationType', width: '30%', sort: true, sortColumn: 'evaluationType' },
      { caption: 'Name', dataField: 'name', width: '60%', sort: true, sortColumn: 'name' },
      { caption: 'Active', dataField: 'active', width: '10%', sort: true, sortColumn: 'active' }
    ]
  };

  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.limitOptions = recordslimitOptions;
    this.refreshEvaluationModal();
  }
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.evaluationList.length / event);
    this.pageSize = event;
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.evaluationTypeId;

  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
  }
  refreshEvaluationModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('evaluationTypeList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.evaluationList = res.data;
        this.evaluationGridData.tableData = this.evaluationList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }

  ViewEvaluationModal(ViewEvaluation: TemplateRef<any>, SelectEvaluation: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(ViewEvaluation);
      this.spinnerFlag = true;
      this.httpService.deleteRecord('viewEvaluationType?evaluationTypeId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectEvaluation);
    }
  }

  SearchEvaluationModal(SearchEvaluation: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchEvaluation);
  }

}

