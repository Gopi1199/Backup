import { Component, OnInit, TemplateRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ValidationService } from '../../validation/validation.service';
import { ControllerMessageComponent } from '../../validation/controller-message/controller-message.component';
import { recordslimitOptions } from '../../JSON';

@Component({
  selector: 'app-axis-one-two',
  templateUrl: './axis-one-two.component.html',
  styleUrls: ['./axis-one-two.component.css']
})
export class AxisOneTwoComponent implements OnInit {

  private result: any;
  private agenciesList: any;
  private searchForm: any;
  private modalRef: BsModalRef;
  private selectedRowId: Number;
  private setClickedRow: Function;
  private selectedRowData: any;
  private deactiveMsgFlag: boolean = false;
  private deactiveMsg: String = '';
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private spinnerFlag: boolean = false;
  diagnosesList: Array<any> = [];
  private data: Object;
  private searchMsgFlag: boolean = true;
  private searchError: String;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  diagnosesGridData: any = {
    'gridName': 'Axis I & II (DSM Diagnoses)',
    'primaryKey': 'dsmDiagnosesId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Code', dataField: 'code', width: '10%', sort: true, sortColumn: 'code' },
      { caption: 'Description', dataField: 'description', width: '80%', sort: true, sortColumn: 'description' },
      { caption: 'Active', dataField: 'active', width: '10%', sort: true, sortColumn: 'active' }
    ]
  };
  agenciesGridData: any = {
    'gridName': 'Agenices',
    'primaryKey': 'agenciesId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Agency Name', dataField: 'name', width: '10%', sort: true, sortColumn: 'name' },
      { caption: 'Coordinator Last Name', dataField: 'coordinatorLastName', width: '15%', sort: false },
      { caption: 'Coordinator First Name', dataField: 'coordinatorFirstName', width: '15%', sort: false },
      { caption: 'Phone', dataField: 'phone', width: '20%', sort: false },
      { caption: 'CMH Board', dataField: 'cmhBoard', width: '20%', sort: false },
      { caption: 'Active', dataField: 'active', width: '20%', sort: false }
    ]
  };
  mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {

    this.data = {
      'InputFields': [{ 'cmhBoardId': 100 }],
      'SortFields': [{ 'cmhBoardId': 100 }],
      'startIndex': 0,
      'maxResults': 100,
      'orderBy': 'cmhBoardId'
    };
    this.limitOptions = recordslimitOptions;
    this.RefreshDiagnosesModal();
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.dsmDiagnosesId;
  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
  }
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.diagnosesList.length / event);
    this.pageSize = event;
  }
  AddDiagnosesModal(AddDiagnoses: TemplateRef<any>) {
    this.messageFlag = false;
    this.notifyMsg = '';
    this.modalRef = this.modalService.show(AddDiagnoses);
  }
  RefreshDiagnosesModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('dsmDiagnosesList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.diagnosesList = res.data;
        this.diagnosesGridData.tableData = this.diagnosesList;
      } else {
      }

    }, error => {
    });
  }
  EditDiagnosesModal(EditDiagnoses: TemplateRef<any>, SelectDiagnoses: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.spinnerFlag = true;
      this.messageFlag = false;
      this.notifyMsg = '';
      this.httpService.getRecord('viewDSMDiagnoses?dsmDiagnosesId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
          this.modalRef = this.modalService.show(EditDiagnoses);
        } else {
        }

      }, error => {
      });

    } else {
      this.modalRef = this.modalService.show(SelectDiagnoses);
    }
  }
  ViewDiagnosesModal(ViewDiagnoses: TemplateRef<any>, SelectDiagnoses: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.spinnerFlag = true;
      this.httpService.deleteRecord('viewDSMDiagnoses?dsmDiagnosesId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.selectedRowData = res.data;
          this.spinnerFlag = false;
          this.modalRef = this.modalService.show(ViewDiagnoses);
        } else {
        }

      }, error => {
      });
    } else {
      this.modalRef = this.modalService.show(SelectDiagnoses);
    }
  }
  DeleteDiagnosesModal(DeleteDiagnoses: TemplateRef<any>, SelectDiagnoses: TemplateRef<any>) {
    this.deactiveMsgFlag = false;
    this.deactiveMsg = '';
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(DeleteDiagnoses);
    } else {
      this.modalRef = this.modalService.show(SelectDiagnoses);
    }
  }
  SearchDiagnosesModal(SearchDiagnoses: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchDiagnoses);
  }

  SearchReset() {
    this.searchForm.reset();
  }
  SearchSubmit() {
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.spinnerFlag = true;
    this.httpService.searchRecord('dsmDiagnosesList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.diagnosesList = res.data;
        this.diagnosesGridData.tableData = this.diagnosesList;
        this.modalRef.hide();
      } else {
        this.searchMsgFlag = true;
        this.searchError = 'No records found';
      }

    }, error => {
    });
  }
}
