import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchDiagnosesComponent } from './search-diagnoses.component';

describe('SearchDiagnosesComponent', () => {
  let component: SearchDiagnosesComponent;
  let fixture: ComponentFixture<SearchDiagnosesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchDiagnosesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchDiagnosesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
