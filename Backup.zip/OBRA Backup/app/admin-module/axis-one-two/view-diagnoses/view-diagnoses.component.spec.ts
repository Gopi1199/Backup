import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewDiagnosesComponent } from './view-diagnoses.component';

describe('ViewDiagnosesComponent', () => {
  let component: ViewDiagnosesComponent;
  let fixture: ComponentFixture<ViewDiagnosesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewDiagnosesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewDiagnosesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
