import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { dateFormat } from '../../../JSON';

@Component({
  selector: 'app-edit-diagnoses',
  templateUrl: './edit-diagnoses.component.html',
  styleUrls: ['./edit-diagnoses.component.css']
})
export class EditDiagnosesComponent implements OnInit {
  private editDiagnosesForm: any;
  data: Object;
  spinnerFlag: boolean = false;
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private selectedRowId: Number;
  private setClickedRow: Function;
  private disablePre: Boolean = false;
  private disableNxt: Boolean = false;
  private currentIdx: any;
  private currentRecId: any;
  private nextIdx: any;
  diagnosesList: Array<any> = [];
  @Input() modalRef: any;
  @Input() selectedRowData: any;
  @Input() diagnosesGridData: any;
  @Output() currentId: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  private recordsAll: any;
  private recCount: any;
  private dateFormat: any;
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) {
    this.dateFormat = dateFormat;
  }
 
  ngOnInit() {
    this.recordsAll = JSON.parse(localStorage.getItem('recAll'));
    this.recCount = this.recordsAll.length - 1;
    if (Number(localStorage.getItem('currentIndex')) === 1) {
      this.disablePre = true;
    } else if (Number(localStorage.getItem('currentIndex')) === this.recCount) {
      this.disableNxt = true;
    }
    this.editDiagnosesForm = this.formBuilder.group({
      'code': ['', Validators.required],
      'description': ['', Validators.required],
      'active': ['', Validators.required],
      'createdBy': [{ value: '', disabled: true }],
      'createdOn': [{ value: '', disabled: true }],
      'modifiedBy': [{ value: '', disabled: true }],
      'modifiedOn': [{ value: '', disabled: true }]
    });

  }
  editDiagnosesSubmit(event: any) {
    console.log(this.editDiagnosesForm.valid);
    Object.keys(this.editDiagnosesForm.controls).forEach(field => {
      const control = this.editDiagnosesForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.editDiagnosesForm.valid) {
      this.data = this.editDiagnosesForm.value;
      this.data['dsmDiagnosesId'] = this.selectedRowData.dsmDiagnosesId;
      this.spinnerFlag = true;
      this.notifyMsg = '';
      this.messageFlag = false;
      this.httpService.updateRecord('editDSMDiagnoses', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.messageFlag = true;
          this.notifyMsg = 'Record updated successfully';
          setTimeout(() => {
            this.modalRef.hide();
          }, 2000);
          this.RefreshDiagnosesModal();
        } else {
        }

      }, error => {
      });

    }
  }
  RefreshDiagnosesModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('dsmDiagnosesList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.diagnosesList = res.data;
        this.totalPages = Math.ceil(this.diagnosesList.length / this.pageSize);
        this.diagnosesGridData.tableData = this.diagnosesList;
      } else {
        console.log('error');
      }

    }, error => {
    });
  }
  private dateChanged(newDate) {
    this.selectedRowData.createdOn = new Date(newDate);
  }

  EditDiagnosesModal(id) {
    this.spinnerFlag = true;
    this.httpService.getRecord('viewDSMDiagnoses?dsmDiagnosesId=' + id).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.selectedRowData = res.data;

      } else {
      }
    }, error => {
    });
  }

  recordNavigation(action) {

    this.disablePre = false;
    this.disableNxt = false;
    const recordsAll: any = JSON.parse(localStorage.getItem('recAll'));
    this.currentIdx = localStorage.getItem('currentIndex');

    if (action === 'previous') {
      this.currentRecId = recordsAll[Number(this.currentIdx) - 1];
      this.currentIdx = Number(this.currentIdx) - 1;
    } else {
      this.currentRecId = recordsAll[Number(this.currentIdx) + 1];
      this.currentIdx = Number(this.currentIdx) + 1;
    }
    if (this.currentIdx === 1) {
      this.disablePre = true;
    }
    if (this.currentIdx === this.recCount) {
      this.disableNxt = true;
    }
    localStorage.setItem('currentIndex', this.currentIdx);
    const list = Array.from(document.getElementById('gridTable').querySelectorAll('tbody tr'));
    list.forEach(function (node) { node.className = ''; });
    document.getElementById(this.currentRecId).classList.add('highlighted');
    this.EditDiagnosesModal(this.currentRecId);
    this.currentId.emit(this.currentRecId);
  }
}
