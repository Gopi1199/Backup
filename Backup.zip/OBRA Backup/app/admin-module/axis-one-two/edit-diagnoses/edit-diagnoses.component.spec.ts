import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EditDiagnosesComponent } from './edit-diagnoses.component';

describe('EditDiagnosesComponent', () => {
  let component: EditDiagnosesComponent;
  let fixture: ComponentFixture<EditDiagnosesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditDiagnosesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDiagnosesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
