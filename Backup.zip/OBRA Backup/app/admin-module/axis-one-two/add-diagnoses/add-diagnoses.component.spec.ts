import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AddDiagnosesComponent } from './add-diagnoses.component';

describe('AddDiagnosesComponent', () => {
  let component: AddDiagnosesComponent;
  let fixture: ComponentFixture<AddDiagnosesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddDiagnosesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDiagnosesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
