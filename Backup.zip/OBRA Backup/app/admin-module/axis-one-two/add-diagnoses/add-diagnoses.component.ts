import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-diagnoses',
  templateUrl: './add-diagnoses.component.html',
  styleUrls: ['./add-diagnoses.component.css']
})

export class AddDiagnosesComponent implements OnInit {
  private addDiagnosesForm: any;
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private spinnerFlag: boolean = false;
  data: Object;
  @Input() modalRef: any;
  @Input() diagnosesGridData: any;
  diagnosesList: Array<any> = [];
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) { }

  ngOnInit() {

    this.addDiagnosesForm = this.formBuilder.group({
      'code': ['', Validators.required],
      'description': ['', Validators.required],
      'active': ['', Validators.required],
      'createdBy': [{ value: '', disabled: true }],
      'createdOn': [{ value: '', disabled: true }],
      'modifiedBy': [{ value: '', disabled: true }],
      'modifiedOn': [{ value: '', disabled: true }]
    });

  }
  addDiagnosesSubmit(event: any) {
    Object.keys(this.addDiagnosesForm.controls).forEach(field => {
      const control = this.addDiagnosesForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.addDiagnosesForm.valid) {
      this.data = this.addDiagnosesForm.value;
      this.spinnerFlag = true;
      this.messageFlag = false;
      this.notifyMsg = '';
      this.httpService.addRecord('editDSMDiagnoses', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.messageFlag = true;
          this.notifyMsg = 'Record added successfully';
          this.RefreshDiagnosesModal();
          setTimeout(() => {
            this.modalRef.hide();
          }, 2000);
          this.RefreshDiagnosesModal();
        } else {
        }

      }, error => {
      });
    }
  }
  RefreshDiagnosesModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('dsmDiagnosesList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.diagnosesList = res.data;
        this.totalPages = Math.ceil(this.diagnosesList.length / this.pageSize);
        this.diagnosesGridData.tableData = this.diagnosesList;
      } else {
      }

    }, error => {
    });
  }
}
