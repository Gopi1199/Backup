import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DeleteDiagnosesComponent } from './delete-diagnoses.component';

describe('DeleteDiagnosesComponent', () => {
  let component: DeleteDiagnosesComponent;
  let fixture: ComponentFixture<DeleteDiagnosesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteDiagnosesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteDiagnosesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
