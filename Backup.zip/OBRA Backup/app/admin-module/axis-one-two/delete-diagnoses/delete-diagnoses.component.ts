import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';

@Component({
  selector: 'app-delete-diagnoses',
  templateUrl: './delete-diagnoses.component.html',
  styleUrls: ['./delete-diagnoses.component.css']
})
export class DeleteDiagnosesComponent implements OnInit {
  spinnerFlag: boolean = false;
  data: Object;
  diagnosesList: Array<any> = [];
  @Input() selectedRowId: any;
  @Input() modalRef: any;
  @Input() diagnosesGridData: any;
  private deactiveMsgFlag: boolean = false;
  private deactiveMsg: String = '';
  private deactiveErrorMsgFlag: boolean = false;
  private deactiveErrorMsg: String = '';
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  constructor(private httpService: WebService) { }

  ngOnInit() {
  }
  deleteDiagnoses() {    
    this.spinnerFlag = true;
    this.httpService.deleteRecord('deleteDSMDiagnoses?dsmDiagnosesId=' + this.selectedRowId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.deactiveMsgFlag = true;
        this.deactiveMsg = 'Record deactivated successfully';
        setTimeout(() => {
          this.modalRef.hide();
        }, 2000);
        this.RefreshDiagnosesModal();
      } else if (res.global === 'errorMsg@') {
        this.deactiveErrorMsgFlag = true;
        this.deactiveErrorMsg = res.data;
      }

    }, error => {      
    });
  }
  RefreshDiagnosesModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('dsmDiagnosesList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.diagnosesList = res.data;
        this.totalPages = Math.ceil(this.diagnosesList.length / this.pageSize);
        this.diagnosesGridData.tableData = this.diagnosesList;
      } else {
      }

    }, error => {
    });
  }
}
