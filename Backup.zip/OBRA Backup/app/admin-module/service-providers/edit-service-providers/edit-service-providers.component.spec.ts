import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditServiceProvidersComponent } from './edit-service-providers.component';

describe('EditServiceProvidersComponent', () => {
  let component: EditServiceProvidersComponent;
  let fixture: ComponentFixture<EditServiceProvidersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditServiceProvidersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditServiceProvidersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
