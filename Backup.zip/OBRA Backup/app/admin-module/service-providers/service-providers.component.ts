import { Component, OnInit, TemplateRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ValidationService } from '../../validation/validation.service';
import { ControllerMessageComponent } from '../../validation/controller-message/controller-message.component';
import { recordslimitOptions } from '../../JSON';

@Component({
  selector: 'app-service-providers',
  templateUrl: './service-providers.component.html',
  styleUrls: ['./service-providers.component.css']
})
export class ServiceProvidersComponent implements OnInit {
  private modalRef: BsModalRef;
  private selectedRowId: Number;
  private selectedRowData: any;
  private deactiveMsgFlag: boolean = false;
  private deactiveMsg: String = '';
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private spinnerFlag: boolean = false;
  ServiceProvidersList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  serviceProvidersGridData: any = {
    'gridName': 'Service Providers',
    'primaryKey': 'serviceProvidersId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Name', dataField: 'name', width: '90%', sort: true, sortColumn: 'name' },
      { caption: 'Active', dataField: 'active', width: '10%', sort: true, sortColumn: 'active' }
    ]
  };
  mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {

    this.data = {
      'InputFields': [{ 'serviceProvidersId': 100 }],
      'SortFields': [{ 'serviceProvidersId': 100 }],
      'startIndex': 0,
      'maxResults': 100,
      'orderBy': 'serviceProvidersId'
    };
    this.limitOptions = recordslimitOptions;
    this.RefreshServiceProvidersModal();
  }
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.ServiceProvidersList.length / event);
    this.pageSize = event;
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.serviceProvidersId;

  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
  }
  AddServiceProvidersModal(AddServiceProviders: TemplateRef<any>) {
    this.messageFlag = false;
    this.notifyMsg = '';
    this.modalRef = this.modalService.show(AddServiceProviders);
  }
  RefreshServiceProvidersModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('serviceProvidersList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.ServiceProvidersList = res.data;
        this.serviceProvidersGridData.tableData = this.ServiceProvidersList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
  EditServiceProvidersModal(EditServiceProviders: TemplateRef<any>, SelectAgnecies: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.spinnerFlag = true;
      this.messageFlag = false;
      this.notifyMsg = '';
      this.httpService.getRecord('findProvidersListById?providersListById=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
          this.modalRef = this.modalService.show(EditServiceProviders);
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });


    } else {
      this.modalRef = this.modalService.show(SelectAgnecies);
    }
  }
  ViewServiceProvidersModal(ViewServiceProviders: TemplateRef<any>, SelectAgnecies: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(ViewServiceProviders);
      this.spinnerFlag = true;
      this.httpService.getRecord('findProvidersListById?providersListById=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectAgnecies);
    }
  }
  DeleteServiceProvidersModal(DeleteServiceProviders: TemplateRef<any>, SelectAgnecies: TemplateRef<any>) {
    this.deactiveMsgFlag = false;
    this.deactiveMsg = '';
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(DeleteServiceProviders);
    } else {
      this.modalRef = this.modalService.show(SelectAgnecies);
    }
  }
  SearchServiceProvidersModal(SearchServiceProviders: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchServiceProviders);
  }
}
