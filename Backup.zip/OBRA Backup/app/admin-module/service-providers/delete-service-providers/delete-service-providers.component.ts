import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';

@Component({
  selector: 'app-delete-service-providers',
  templateUrl: './delete-service-providers.component.html',
  styleUrls: ['./delete-service-providers.component.css']
})
export class DeleteServiceProvidersComponent implements OnInit {
  spinnerFlag: boolean = false;
  @Input() selectedRowId: any;
  @Input() modalRef: any;
  @Input() serviceProvidersGridData: any;
  data: Object;
  ServiceProvidersList: Array<any> = [];
  private deactiveMsgFlag: boolean = false;
  private deactiveMsg: String = '';
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  constructor(private httpService: WebService) {
  }
  ngOnInit() {
  }
  deleteServiceProviders() {
    this.spinnerFlag = true;
    this.httpService.deleteRecord('deleteProvidersListById?providersListById=' + this.selectedRowId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.deactiveMsgFlag = true;
        this.deactiveMsg = 'Record deactivated successfully';
        setTimeout(() => {
          this.modalRef.hide();
        }, 2000);
        this.RefreshServiceProvidersModal();
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
  RefreshServiceProvidersModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('serviceProvidersList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.ServiceProvidersList = res.data;
        this.serviceProvidersGridData.tableData = this.ServiceProvidersList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
}
