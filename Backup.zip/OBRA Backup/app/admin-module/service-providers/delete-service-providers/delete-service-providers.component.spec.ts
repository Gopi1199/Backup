import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteServiceProvidersComponent } from './delete-service-providers.component';

describe('DeleteServiceProvidersComponent', () => {
  let component: DeleteServiceProvidersComponent;
  let fixture: ComponentFixture<DeleteServiceProvidersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteServiceProvidersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteServiceProvidersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
