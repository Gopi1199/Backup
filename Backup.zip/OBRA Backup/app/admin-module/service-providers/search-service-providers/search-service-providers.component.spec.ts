import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchServiceProvidersComponent } from './search-service-providers.component';

describe('SearchServiceProvidersComponent', () => {
  let component: SearchServiceProvidersComponent;
  let fixture: ComponentFixture<SearchServiceProvidersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchServiceProvidersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchServiceProvidersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
