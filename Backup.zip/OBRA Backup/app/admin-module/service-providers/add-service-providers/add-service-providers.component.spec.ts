import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddServiceProvidersComponent } from './add-service-providers.component';

describe('AddServiceProvidersComponent', () => {
  let component: AddServiceProvidersComponent;
  let fixture: ComponentFixture<AddServiceProvidersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddServiceProvidersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddServiceProvidersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
