import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-search-representative',
  templateUrl: './search-representative.component.html',
  styleUrls: ['./search-representative.component.css']
})
export class SearchRepresentativeComponent implements OnInit {
  private searchRepresentativeTypesForm: any;
  private searchMsgFlag: boolean = true;
  private searchError: String = '';
  spinnerFlag: boolean = false;
  data: Object;
  private filter: any;
  private searchInput: Object;
  private searchsuccess: String = '';
  private searchErrorMsgFlag: boolean = false;
  @Input() representativeGridData: any;
  @Input() modalRef: any;
  RepresentativeList: Array<any> = [];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) { }
  ngOnInit() {
    this.searchRepresentativeTypesForm = this.formBuilder.group({
      'id': [''],
      'value': ['']
    });
  }
  SearchReset() {
    this.searchRepresentativeTypesForm.reset();
  }
  searchRepresentativeTypesSubmit() {

    this.searchError = '';
    this.searchsuccess = '';
    this.filter = { filters: [this.searchRepresentativeTypesForm.value] };
    this.searchInput = {
      'max': 100,
      'skip': 0,
      'orderBy': '',
      'orderType': 'asc',
      'search': JSON.stringify(this.filter)
    };

    this.spinnerFlag = true;
    this.httpService.searchRecord('searchRepresentativeTypes', this.searchInput).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.RepresentativeList = res.data;
        this.representativeGridData.tableData = this.RepresentativeList;
        if (res.data.length === 0) {
          this.searchErrorMsgFlag = true;
          this.searchMsgFlag = false;
          this.searchError = 'Records Not found';

        } else {
          this.searchMsgFlag = true;
          this.searchErrorMsgFlag = false;
          this.searchsuccess = 'Records found';
        }
        
      } else {
        this.searchErrorMsgFlag = true;
        this.searchMsgFlag = false;
        this.searchError = 'No records found';
        
      }
    }, error => {
      console.log(error);
    });
  }
}
