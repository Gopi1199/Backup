import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchRepresentativeComponent } from './search-representative.component';

describe('SearchRepresentativeComponent', () => {
  let component: SearchRepresentativeComponent;
  let fixture: ComponentFixture<SearchRepresentativeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchRepresentativeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchRepresentativeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
