import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewRepresentativeComponent } from './view-representative.component';

describe('ViewRepresentativeComponent', () => {
  let component: ViewRepresentativeComponent;
  let fixture: ComponentFixture<ViewRepresentativeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewRepresentativeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewRepresentativeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
