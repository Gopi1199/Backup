import { Component, OnInit, TemplateRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ValidationService } from '../../validation/validation.service';
import { ControllerMessageComponent } from '../../validation/controller-message/controller-message.component';
import { recordslimitOptions } from '../../JSON';

@Component({
  selector: 'app-representative-type',
  templateUrl: './representative-type.component.html',
  styleUrls: ['./representative-type.component.css']
})
export class RepresentativeTypeComponent implements OnInit {
  private modalRef: BsModalRef;
  private selectedRowId: Number;
  private selectedRowData: any;
  private deactiveMsgFlag: boolean = false;
  private deactiveMsg: String = '';
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private spinnerFlag: boolean = false;
  RepresentativeList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  representativeGridData: any = {
    'gridName': 'Representative Types ',
    'primaryKey': 'representativeTypesId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Description', dataField: 'description', width: '80%', sort: true, sortColumn: 'description' },
      { caption: 'Default Flag', dataField: 'defaultFlag', width: '10%',  sort: true, sortColumn: 'defaultFlag' },
      { caption: 'Active', dataField: 'active', width: '10%',  sort: true, sortColumn: 'active' }
    ]
  };
  mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {

    this.data = {
      'InputFields': [{ 'cmhBoardId': 100 }],
      'SortFields': [{ 'cmhBoardId': 100 }],
      'startIndex': 0,
      'maxResults': 100,
      'orderBy': 'cmhBoardId'
    };

    this.limitOptions = recordslimitOptions;
    this.RefreshRepresentativeModal();
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.representativeTypesId;
  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
  }
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.RepresentativeList.length / event);
    this.pageSize = event;
  }
  AddRepresentativeModal(AddRepresentative: TemplateRef<any>) {
    this.messageFlag = false;
    this.notifyMsg = '';
    this.modalRef = this.modalService.show(AddRepresentative);
  }
  RefreshRepresentativeModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('searchRepresentativeTypes', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.RepresentativeList = res.data;
        this.representativeGridData.tableData = this.RepresentativeList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
  EditRepresentativeModal(EditRepresentative: TemplateRef<any>, SelectRepresentative: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.spinnerFlag = true;
      this.messageFlag = false;
      this.notifyMsg = '';
      this.httpService.getRecord('viewRepresentativeTypes?representativeTypesId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
          this.modalRef = this.modalService.show(EditRepresentative);
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });


    } else {
      this.modalRef = this.modalService.show(SelectRepresentative);
    }
  }
  ViewRepresentativeModal(ViewRepresentative: TemplateRef<any>, SelectRepresentative: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(ViewRepresentative);
      this.spinnerFlag = true;
      this.httpService.deleteRecord('viewRepresentativeTypes?representativeTypesId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectRepresentative);
    }
  }
  DeleteRepresentativeModal(DeleteRepresentative: TemplateRef<any>, SelectRepresentative: TemplateRef<any>) {
    this.deactiveMsgFlag = false;
    this.deactiveMsg = '';
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(DeleteRepresentative);
    } else {
      this.modalRef = this.modalService.show(SelectRepresentative);
    }
  }
  SearchRepresentativeModal(SearchRepresentative: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchRepresentative);
  }
}
