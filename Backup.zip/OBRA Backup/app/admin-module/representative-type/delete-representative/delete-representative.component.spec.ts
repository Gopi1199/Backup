import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteRepresentativeComponent } from './delete-representative.component';

describe('DeleteRepresentativeComponent', () => {
  let component: DeleteRepresentativeComponent;
  let fixture: ComponentFixture<DeleteRepresentativeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteRepresentativeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteRepresentativeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
