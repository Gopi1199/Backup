import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ValidationService } from '../../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { WebService } from '../../../Service/webservice';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';


@Component({
  selector: 'app-add-representative',
  templateUrl: './add-representative.component.html',
  styleUrls: ['./add-representative.component.css']
})
export class AddRepresentativeComponent implements OnInit {

  @Input() modalRef: any;
  @Input() representativeGridData: any;
  private addRepresentativeForm: any;
  private data: Object;
  private addAgenciesValidateFlag: boolean = false;
  private addAgenciesValidationMsg: String = '';
  spinnerFlag: boolean = false;
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  RepresentativeList: Array<any> = [];
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  // mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {

    this.addRepresentativeForm = new FormGroup({
      'description': new FormControl('', [Validators.required]),
      'defaultFlag': new FormControl('', [Validators.required]),
      'active': new FormControl('', [Validators.required]),
      'createdBy': new FormControl(''),
      'createdOn': new FormControl(''),
      'modifiedBy': new FormControl(''),
      'modifiedOn': new FormControl('')
    });

  }
  RefreshRepresentativeModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('searchRepresentativeTypes', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.RepresentativeList = res.data;
        this.representativeGridData.tableData = this.RepresentativeList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
  addRepresentativeSubmit(event: any) {
    Object.keys(this.addRepresentativeForm.controls).forEach(field => {
      const control = this.addRepresentativeForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.addRepresentativeForm.valid) {
      this.data = this.addRepresentativeForm.value;
      this.spinnerFlag = true;
      this.messageFlag = false;
      this.notifyMsg = '';
      this.httpService.addRecord('editRepresentativeTypes', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.messageFlag = true;
          this.notifyMsg = 'Record added successfully';
          this.RefreshRepresentativeModal();
          setTimeout(() => {
            this.modalRef.hide();
          }, 2000);
          this.RefreshRepresentativeModal();
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });

    }
    // console.log('addRepresentativeForm:' + JSON.stringify(this.addRepresentativeForm.value));
  }
}
