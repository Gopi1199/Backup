import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNotifiedPersonComponent } from './add-notified-person.component';

describe('AddNotifiedPersonComponent', () => {
  let component: AddNotifiedPersonComponent;
  let fixture: ComponentFixture<AddNotifiedPersonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddNotifiedPersonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddNotifiedPersonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
