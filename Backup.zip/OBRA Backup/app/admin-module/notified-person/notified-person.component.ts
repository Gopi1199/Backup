import { Component, OnInit, TemplateRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ValidationService } from '../../validation/validation.service';
import { ControllerMessageComponent } from '../../validation/controller-message/controller-message.component';
import { recordslimitOptions } from '../../JSON';

@Component({
  selector: 'app-notified-person',
  templateUrl: './notified-person.component.html',
  styleUrls: ['./notified-person.component.css']
})
export class NotifiedPersonComponent implements OnInit {
  private modalRef: BsModalRef;
  private selectedRowId: Number;
  private selectedRowData: any;
  private deactiveMsgFlag: boolean = false;
  private deactiveMsg: String = '';
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private spinnerFlag: boolean = false;
  NotifiedPersonList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  notifiedPersonGridData: any = {
    'gridName': 'Notified Person',
    'primaryKey': 'notifiedPersonsId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Description', dataField: 'description', width: '80%', sort: true, sortColumn: 'description' },
      { caption: 'Default Flag', dataField: 'defaultFlag', width: '10%', sort: true, sortColumn: 'defaultFlag' },
      { caption: 'Active', dataField: 'active', width: '10%', sort: true, sortColumn: 'active' }
    ]
  };
  mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.data = {
      'InputFields': [{ 'cmhBoardId': 100 }],
      'SortFields': [{ 'cmhBoardId': 100 }],
      'startIndex': 0,
      'maxResults': 100,
      'orderBy': 'cmhBoardId'
    };
    this.limitOptions = recordslimitOptions;
    this.RefreshNotifiedPersonModal();
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.notifiedPersonsId;

  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
  }
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.NotifiedPersonList.length / event);
    this.pageSize = event;
  }
  AddNotifiedPersonModal(AddNotifiedPerson: TemplateRef<any>) {
    this.messageFlag = false;
    this.notifyMsg = '';
    this.modalRef = this.modalService.show(AddNotifiedPerson);
  }
  RefreshNotifiedPersonModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('notifiedPersonList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.NotifiedPersonList = res.data;
        this.notifiedPersonGridData.tableData = this.NotifiedPersonList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
  EditNotifiedPersonModal(EditNotifiedPerson: TemplateRef<any>, SelectNotifiedPerson: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.spinnerFlag = true;
      this.messageFlag = false;
      this.notifyMsg = '';
      this.httpService.getRecord('viewNotifiedPersons?notifiedPersonId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
          this.modalRef = this.modalService.show(EditNotifiedPerson);
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });


    } else {
      this.modalRef = this.modalService.show(SelectNotifiedPerson);
    }
  }
  ViewNotifiedPersonModal(ViewNotifiedPerson: TemplateRef<any>, SelectNotifiedPerson: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(ViewNotifiedPerson);
      this.spinnerFlag = true;
      this.httpService.deleteRecord('viewNotifiedPersons?notifiedPersonId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectNotifiedPerson);
    }
  }
  DeleteNotifiedPersonModal(DeleteNotifiedPerson: TemplateRef<any>, SelectNotifiedPerson: TemplateRef<any>) {
    this.deactiveMsgFlag = false;
    this.deactiveMsg = '';
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(DeleteNotifiedPerson);
    } else {
      this.modalRef = this.modalService.show(SelectNotifiedPerson);
    }
  }
  SearchNotifiedPersonModal(SearchNotifiedPerson: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchNotifiedPerson);
    // selectRow(event: any, item: any) {
    //   this.selectedRowData = item;
    //   this.selectedRow = item.notifiedPersonsId;
    //   // console.log(JSON.stringify(this.selectedRowData));
    // }
  }


}
