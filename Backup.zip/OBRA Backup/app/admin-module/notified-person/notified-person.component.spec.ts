import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotifiedPersonComponent } from './notified-person.component';

describe('NotifiedPersonComponent', () => {
  let component: NotifiedPersonComponent;
  let fixture: ComponentFixture<NotifiedPersonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotifiedPersonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotifiedPersonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
