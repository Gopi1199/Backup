import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewNotifiedPersonComponent } from './view-notified-person.component';

describe('ViewNotifiedPersonComponent', () => {
  let component: ViewNotifiedPersonComponent;
  let fixture: ComponentFixture<ViewNotifiedPersonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewNotifiedPersonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewNotifiedPersonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
