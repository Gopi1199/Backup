import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchNotifiedPersonComponent } from './search-notified-person.component';

describe('SearchNotifiedPersonComponent', () => {
  let component: SearchNotifiedPersonComponent;
  let fixture: ComponentFixture<SearchNotifiedPersonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchNotifiedPersonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchNotifiedPersonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
