import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteNotifiedPersonComponent } from './delete-notified-person.component';

describe('DeleteNotifiedPersonComponent', () => {
  let component: DeleteNotifiedPersonComponent;
  let fixture: ComponentFixture<DeleteNotifiedPersonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteNotifiedPersonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteNotifiedPersonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
