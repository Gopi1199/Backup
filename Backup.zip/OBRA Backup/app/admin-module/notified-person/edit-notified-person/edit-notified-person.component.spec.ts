import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditNotifiedPersonComponent } from './edit-notified-person.component';

describe('EditNotifiedPersonComponent', () => {
  let component: EditNotifiedPersonComponent;
  let fixture: ComponentFixture<EditNotifiedPersonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditNotifiedPersonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditNotifiedPersonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
