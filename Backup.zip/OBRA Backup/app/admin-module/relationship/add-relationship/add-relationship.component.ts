import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ValidationService } from '../../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { WebService } from '../../../Service/webservice';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

@Component({
  selector: 'app-add-relationship',
  templateUrl: './add-relationship.component.html',
  styleUrls: ['./add-relationship.component.css']
})
export class AddRelationshipComponent implements OnInit {
  @Input() modalRef: any;
  @Input() relationshipGridData: any;
  private addRelationshipForm: any;
  private data: Object;
  private addAgenciesValidateFlag: boolean = false;
  private addAgenciesValidationMsg: String = '';
  spinnerFlag: boolean = false;
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  RelationshipList: Array<any> = [];
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  // mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {

    this.addRelationshipForm = new FormGroup({
      'description': new FormControl('', [Validators.required]),
      'active': new FormControl('', [Validators.required]),
      'createdBy': new FormControl(''),
      'createdOn': new FormControl(''),
      'modifiedBy': new FormControl(''),
      'modifiedOn': new FormControl('')
    });

  }
  RefreshRelationshipModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('relationshipList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.RelationshipList = res.data;
        this.relationshipGridData.tableData = this.RelationshipList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
  addRelationshipSubmit(event: any) {
    Object.keys(this.addRelationshipForm.controls).forEach(field => {
      const control = this.addRelationshipForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.addRelationshipForm.valid) {
      this.data = this.addRelationshipForm.value;
      this.spinnerFlag = true;
      this.messageFlag = false;
      this.notifyMsg = '';
      this.httpService.addRecord('editRelationships', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.messageFlag = true;
          this.notifyMsg = 'Record added successfully';
          this.RefreshRelationshipModal();
          setTimeout(() => {
            this.modalRef.hide();
          }, 2000);
          this.RefreshRelationshipModal();
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });

    }
    // console.log('addRelationshipForm:' + JSON.stringify(this.addRelationshipForm.value));
  }

}
