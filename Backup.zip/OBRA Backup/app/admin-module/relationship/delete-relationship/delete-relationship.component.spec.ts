import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteRelationshipComponent } from './delete-relationship.component';

describe('DeleteRelationshipComponent', () => {
  let component: DeleteRelationshipComponent;
  let fixture: ComponentFixture<DeleteRelationshipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteRelationshipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteRelationshipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
