import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import {dateFormat} from '../../../JSON';

@Component({
  selector: 'app-edit-relationship',
  templateUrl: './edit-relationship.component.html',
  styleUrls: ['./edit-relationship.component.css']
})
export class EditRelationshipComponent implements OnInit {
  private editRelationshipForm: any;
  private data: Object;
  spinnerFlag: boolean = false;
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private disablePre: Boolean = false;
  private disableNxt: Boolean = false;
  private currentIdx: any;
  private currentRecId: any;
  private nextIdx: any;
  private dateFormat: any;
  private selectedRowId: Number;
  private setClickedRow: Function;
 RelationshipList: Array<any> = [];
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  private recordsAll: any;
  private recCount: any;
  @Input() relationshipGridData: any;
  @Input() modalRef: any;
  @Input() selectedRowData: any;
  @Output() currentId: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) {
    this.dateFormat = dateFormat;
   }

  ngOnInit() {
    this.recordsAll = JSON.parse(localStorage.getItem('recAll'));
    this.recCount = this.recordsAll.length - 1;
    if (Number(localStorage.getItem('currentIndex')) === 1) {
      this.disablePre = true;
    } else if (Number(localStorage.getItem('currentIndex')) === this.recCount) {
      this.disableNxt = true;
    }
    this.editRelationshipForm = new FormGroup({
      'description': new FormControl('', [Validators.required]),
      'active': new FormControl('', [Validators.required]),
      'createdBy': new FormControl(''),
      'createdOn': new FormControl(''),
      'modifiedBy': new FormControl(''),
      'modifiedOn': new FormControl('')
    });
  }
  RefreshRelationshipModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('relationshipList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.RelationshipList = res.data;
        this.relationshipGridData.tableData = this.RelationshipList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
  editRelationshipSubmit(event: any) {
    console.log(this.editRelationshipForm.valid);
    Object.keys(this.editRelationshipForm.controls).forEach(field => {
      const control = this.editRelationshipForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.editRelationshipForm.valid) {
      this.data = this.editRelationshipForm.value;
      this.data['relationshipId'] = this.selectedRowData.relationshipId;
      this.spinnerFlag = true;
      this.notifyMsg = '';
      this.messageFlag = false;
      this.httpService.updateRecord('editRelationships', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.messageFlag = true;
          this.notifyMsg = 'Record updated successfully';
          setTimeout(() => {
            this.modalRef.hide();
          }, 2000);
          this.RefreshRelationshipModal();
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });

    }
  }
  EditRelationshipModal(id) {
    this.spinnerFlag = true;
    this.httpService.getRecord('viewRelationship?relationshipId=' + id).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.selectedRowData = res.data;

      } else {
        console.log('error');
      }
    }, error => {
      console.log(error);
    });
  }
  recordNavigation(action) {

    this.disablePre = false;
    this.disableNxt = false;
    const recordsAll: any = JSON.parse(localStorage.getItem('recAll'));
    this.currentIdx = localStorage.getItem('currentIndex');

    if (action === 'previous') {
      this.currentRecId = recordsAll[Number(this.currentIdx) - 1];
      this.currentIdx = Number(this.currentIdx) - 1;
    } else {
      this.currentRecId = recordsAll[Number(this.currentIdx) + 1];
      this.currentIdx = Number(this.currentIdx) + 1;
    }
    if (this.currentIdx === 1) {
      this.disablePre = true;
    }
    if (this.currentIdx === this.recCount) {
      this.disableNxt = true;
    }
    localStorage.setItem('currentIndex', this.currentIdx);
    const list = Array.from(document.getElementById('gridTable').querySelectorAll('tbody tr'));
    list.forEach(function(node) { node.className = ''; }) ;
    document.getElementById(this.currentRecId).classList.add('highlighted');
    this.EditRelationshipModal(this.currentRecId);
    this.currentId.emit(this.currentRecId);
  }


}
