import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchICDDiagnosesComponent } from './search-icddiagnoses.component';

describe('SearchICDDiagnosesComponent', () => {
  let component: SearchICDDiagnosesComponent;
  let fixture: ComponentFixture<SearchICDDiagnosesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchICDDiagnosesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchICDDiagnosesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
