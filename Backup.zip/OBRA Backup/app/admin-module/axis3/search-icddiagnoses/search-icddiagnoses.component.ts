import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-search-icddiagnoses',
  templateUrl: './search-icddiagnoses.component.html',
  styleUrls: ['./search-icddiagnoses.component.css']
})
export class SearchICDDiagnosesComponent implements OnInit {
  private searchIcdDiagnosesForm: any;
  private searchMsgFlag: boolean;
  private searchError: String = '';
  private filter: any;
  private searchInput: Object;
  private searchsuccess: String = '';
  private searchErrorMsgFlag: boolean;
  @Input() icdDiagnosesGridData: any;
  @Input() modalRef: any;
  spinnerFlag: boolean;
  data: Object;
  icdDiagnosesList: Array<any> = [];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) {
    this.searchMsgFlag = false;
    this.searchErrorMsgFlag = false;
   }
  ngOnInit() {
    this.searchIcdDiagnosesForm = this.formBuilder.group({
      'id': [''],
      'value': ['']
    });
  }
  SearchReset() {
    this.searchIcdDiagnosesForm.reset();
  }
  searchIcdDiagnosesSubmit() {

    this.searchError = '';
    this.searchsuccess = '';
    this.filter = { filters: [this.searchIcdDiagnosesForm.value] };
    this.searchInput = {
      'max': 100,
      'skip': 0,
      'orderBy': '',
      'orderType': 'asc',
      'search': JSON.stringify(this.filter)
    };

    this.spinnerFlag = true;
    this.httpService.searchRecord('searchIcdDiagnoses', this.searchInput).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.icdDiagnosesList = res.data;
        this.icdDiagnosesGridData.tableData = this.icdDiagnosesList;
        if (res.data.length === 0) {
          this.searchErrorMsgFlag = true;
          this.searchMsgFlag = false;
          this.searchError = 'Records Not found';

        } else {
          this.searchMsgFlag = true;
          this.searchErrorMsgFlag = false;
          this.searchsuccess = 'Records found';
        }
        
      } else {
        this.searchErrorMsgFlag = true;
        this.searchMsgFlag = false;
        this.searchError = 'No records found';
        
      }
    }, error => {
    });
  }
}
