import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EditICDDiagnosesComponent } from './edit-icddiagnoses.component';

describe('EditICDDiagnosesComponent', () => {
  let component: EditICDDiagnosesComponent;
  let fixture: ComponentFixture<EditICDDiagnosesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditICDDiagnosesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditICDDiagnosesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
