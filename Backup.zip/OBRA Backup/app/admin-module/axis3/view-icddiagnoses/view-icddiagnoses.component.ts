import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { dateFormat } from '../../../JSON';

@Component({
  selector: 'app-view-icddiagnoses',
  templateUrl: './view-icddiagnoses.component.html',
  styleUrls: ['./view-icddiagnoses.component.css']
})
export class ViewICDDiagnosesComponent implements OnInit {
  private disablePre: Boolean = false;
  private disableNxt: Boolean = false;
  private currentIdx: any;
  private currentRecId: any;
  spinnerFlag: Boolean = false;
  pageSize: Number = 20;
  private recordsAll: any;
  private recCount: any;
  @Input() modalRef: any;
  @Input() selectedRowData: any;
  private dateFormat: any;
  @Output() currentId: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();
  constructor(private httpService: WebService, private http: HttpClient) {
    this.dateFormat = dateFormat;
  }


  ngOnInit() {
    this.recordsAll = JSON.parse(localStorage.getItem('recAll'));
    this.recCount = this.recordsAll.length - 1;
    if (Number(localStorage.getItem('currentIndex')) === 1) {
      this.disablePre = true;
    } else if (Number(localStorage.getItem('currentIndex')) === this.recCount) {
      this.disableNxt = true;
    }

  }
  EditICDDiagnosesModal(id) {
    this.spinnerFlag = true;
    this.httpService.getRecord('viewIcdDiagnoses?icdDiagnosesId=' + id).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.selectedRowData = res.data;

      } else {
        console.log('error');
      }
    }, error => {
      console.log(error);
    });
  }

  recordNavigation(action) {
    this.disablePre = false;
    this.disableNxt = false;
    const recordsAll: any = JSON.parse(localStorage.getItem('recAll'));
    this.currentIdx = localStorage.getItem('currentIndex');

    if (action === 'previous') {
      this.currentRecId = recordsAll[Number(this.currentIdx) - 1];
      this.currentIdx = Number(this.currentIdx) - 1;
    } else {
      this.currentRecId = recordsAll[Number(this.currentIdx) + 1];
      this.currentIdx = Number(this.currentIdx) + 1;
    }
    if (this.currentIdx === 1) {
      this.disablePre = true;
    }
    if (this.currentIdx === this.recCount) {
      this.disableNxt = true;
    }
    localStorage.setItem('currentIndex', this.currentIdx);
    const list = Array.from(document.getElementById('gridTable').querySelectorAll('tbody tr'));
    list.forEach(function (node) { node.className = ''; });
    document.getElementById(this.currentRecId).classList.add('highlighted');
    this.EditICDDiagnosesModal(this.currentRecId);
    this.currentId.emit(this.currentRecId);
  }

}
