import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewICDDiagnosesComponent } from './view-icddiagnoses.component';

describe('ViewICDDiagnosesComponent', () => {
  let component: ViewICDDiagnosesComponent;
  let fixture: ComponentFixture<ViewICDDiagnosesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewICDDiagnosesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewICDDiagnosesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
