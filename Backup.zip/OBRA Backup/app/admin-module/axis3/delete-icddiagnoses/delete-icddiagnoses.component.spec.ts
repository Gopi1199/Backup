import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DeleteICDDiagnosesComponent } from './delete-icddiagnoses.component';

describe('DeleteICDDiagnosesComponent', () => {
  let component: DeleteICDDiagnosesComponent;
  let fixture: ComponentFixture<DeleteICDDiagnosesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteICDDiagnosesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteICDDiagnosesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
