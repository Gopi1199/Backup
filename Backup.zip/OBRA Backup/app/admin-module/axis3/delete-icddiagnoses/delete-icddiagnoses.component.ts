import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';


@Component({
  selector: 'app-delete-icddiagnoses',
  templateUrl: './delete-icddiagnoses.component.html',
  styleUrls: ['./delete-icddiagnoses.component.css']
})
export class DeleteICDDiagnosesComponent implements OnInit {
  spinnerFlag: boolean = false;
  data: Object;
  icdDiagnosesList: Array<any> = [];
  @Input() selectedRowId: any;
  @Input() modalRef: any;
  @Input() icdDiagnosesGridData: any;
  private deactiveMsgFlag: boolean = false;
  private deactiveMsg: String = '';
  private deactiveErrorMsgFlag: boolean = false;
  private deactiveErrorMsg: String = '';
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  constructor(private httpService: WebService) { }
  ngOnInit() {
  }
  deleteDiagnoses() {
    this.spinnerFlag = true;
    this.httpService.deleteRecord('deleteIcdDiagnoses?icdDiagnosesId=' + this.selectedRowId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.deactiveMsgFlag = true;
        this.deactiveMsg = 'Record deactivated successfully';
        setTimeout(() => {
          this.modalRef.hide();
        }, 2000);
        this.RefreshICDDiagnosesModal();
      } else if (res.global === 'errorMsg@') {
        this.deactiveErrorMsgFlag = true;
        if (res.data) {
          this.deactiveErrorMsg = res.data;
        } else if (res.data === '' || res.data === null) {
          this.deactiveErrorMsg = 'Record deactivated Unsuccessful';
        }

      }
    }, error => {      
    });
  }
  RefreshICDDiagnosesModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('searchIcdDiagnoses', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.icdDiagnosesList = res.data;
        this.icdDiagnosesGridData.tableData = this.icdDiagnosesList;
      } else if (res.global === 'errorMsg@') {
        this.deactiveErrorMsgFlag = true;
        this.deactiveErrorMsg = res.data;
      }

    }, error => {
    });
  }
}
