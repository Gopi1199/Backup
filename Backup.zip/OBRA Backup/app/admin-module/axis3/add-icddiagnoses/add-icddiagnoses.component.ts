import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-icddiagnoses',
  templateUrl: './add-icddiagnoses.component.html',
  styleUrls: ['./add-icddiagnoses.component.css']
})
export class AddICDDiagnosesComponent implements OnInit {
  private addICDDiagnosesForm: any;
  private messageFlag: boolean;
  private notifyMsg: String = '';
  private spinnerFlag: boolean;
  @Input() modalRef: any;
  @Input() icdDiagnosesGridData: any;
  data: Object;
  icdDiagnosesList: Array<any> = [];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) {
    this.messageFlag = false;
    this.spinnerFlag = false;
   }

  ngOnInit() {
      this.addICDDiagnosesForm = this.formBuilder.group({
        'code': ['', Validators.required],
        'description': ['', Validators.required],
        'active': ['', Validators.required],
        'createdBy': [{ value: '', disabled: true }],
        'createdOn': [{ value: '', disabled: true }],
        'modifiedBy': [{ value: '', disabled: true }],
        'modifiedOn': [{ value: '', disabled: true }]
      });
  }
  addICDDiagnosesSubmit(event: any) {
    Object.keys(this.addICDDiagnosesForm.controls).forEach(field => {
      const control = this.addICDDiagnosesForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.addICDDiagnosesForm.valid) {
      this.data = this.addICDDiagnosesForm.value;
      this.spinnerFlag = true;
      this.messageFlag = false;
      this.notifyMsg = '';
      this.httpService.addRecord('editIcdDiagnoses', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.messageFlag = true;
          this.notifyMsg = 'Record added successfully';
          this.RefreshICDDiagnosesModal();
          setTimeout(() => {
            this.modalRef.hide();
          }, 2000);
          this.RefreshICDDiagnosesModal();
        } else {
        }
      }, error => {
      });
    }
  }
  RefreshICDDiagnosesModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('searchIcdDiagnoses', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.icdDiagnosesList = res.data;
        this.icdDiagnosesGridData.tableData = this.icdDiagnosesList;
      } else {
    }

    }, error => {

    });
  }


}
