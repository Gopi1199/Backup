import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AddICDDiagnosesComponent } from './add-icddiagnoses.component';

describe('AddICDDiagnosesComponent', () => {
  let component: AddICDDiagnosesComponent;
  let fixture: ComponentFixture<AddICDDiagnosesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddICDDiagnosesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddICDDiagnosesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
