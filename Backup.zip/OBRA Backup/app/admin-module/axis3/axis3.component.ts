import { Component, OnInit, TemplateRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ValidationService } from '../../validation/validation.service';
import { ControllerMessageComponent } from '../../validation/controller-message/controller-message.component';
import { recordslimitOptions } from '../../JSON';

@Component({
  selector: 'app-axis3',
  templateUrl: './axis3.component.html',
  styleUrls: ['./axis3.component.css']
})
export class Axis3Component implements OnInit {
  private modalRef: BsModalRef;
  private selectedRowId: Number;
  private selectedRowData: any;
  private deactiveMsgFlag: boolean = false;
  private deactiveMsg: String = '';
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private spinnerFlag: boolean = false;
  icdDiagnosesList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  icdDiagnosesGridData: any = {
    'gridName': 'Axis III',
    'primaryKey': 'icdDiagnosesId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Code', dataField: 'code', width: '10%', sort: true, sortColumn: 'code' },
      { caption: 'Description', dataField: 'description', width: '80%', sort: true, sortColumn: 'description' },
      { caption: 'Active', dataField: 'active', width: '10%', sort: true, sortColumn: 'active' }
    ]
  };
  mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.data = {
      'InputFields': [{ 'cmhBoardId': 100 }],
      'SortFields': [{ 'cmhBoardId': 100 }],
      'startIndex': 0,
      'maxResults': 100,
      'orderBy': 'cmhBoardId'
    };

    this.limitOptions = recordslimitOptions;
    this.RefreshICDDiagnosesModal();
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.icdDiagnosesId;

  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
}
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.icdDiagnosesList.length / event);
    this.pageSize = event;
  }
  AddICDDiagnosesModal(AddICDDiagnoses: TemplateRef<any>) {
    this.messageFlag = false;
    this.notifyMsg = '';
    // this.addICDDiagnosesForm.reset();
    this.modalRef = this.modalService.show(AddICDDiagnoses);
  }
  RefreshICDDiagnosesModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('searchIcdDiagnoses', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.icdDiagnosesList = res.data;
        this.icdDiagnosesGridData.tableData = this.icdDiagnosesList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
  EditICDDiagnosesModal(EditICDDiagnoses: TemplateRef<any>, SelectICDDiagnoses: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.spinnerFlag = true;
      this.messageFlag = false;
      this.notifyMsg = '';
      this.httpService.getRecord('viewIcdDiagnoses?icdDiagnosesId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
          this.modalRef = this.modalService.show(EditICDDiagnoses);
        } else {
          console.log('error');
        }
      }, error => {
        console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectICDDiagnoses);
    }
  }
  ViewICDDiagnosesModal(ViewICDDiagnoses: TemplateRef<any>, SelectICDDiagnoses: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.spinnerFlag = true;
      this.httpService.deleteRecord('viewIcdDiagnoses?icdDiagnosesId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.selectedRowData = res.data;
          this.spinnerFlag = false;
          this.modalRef = this.modalService.show(ViewICDDiagnoses);
        } else {
          console.log('error');
        }
      }, error => {
        console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectICDDiagnoses);
    }
  }
  DeleteICDDiagnosesModal(DeleteICDDiagnoses: TemplateRef<any>, SelectICDDiagnoses: TemplateRef<any>) {
    this.deactiveMsgFlag = false;
    this.deactiveMsg = '';
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(DeleteICDDiagnoses);
    } else {
      this.modalRef = this.modalService.show(SelectICDDiagnoses);
    }
  }
  SearchICDDiagnosesModal(SearchICDDiagnoses: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchICDDiagnoses);
  }
}
