import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Axis3Component } from './axis3.component';

describe('Axis3Component', () => {
  let component: Axis3Component;
  let fixture: ComponentFixture<Axis3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Axis3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Axis3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
