import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchFacilityTypeComponent } from './search-facility-type.component';

describe('SearchFacilityTypeComponent', () => {
  let component: SearchFacilityTypeComponent;
  let fixture: ComponentFixture<SearchFacilityTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchFacilityTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFacilityTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
