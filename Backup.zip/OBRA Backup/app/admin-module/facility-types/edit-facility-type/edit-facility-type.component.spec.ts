import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditFacilityTypeComponent } from './edit-facility-type.component';

describe('EditFacilityTypeComponent', () => {
  let component: EditFacilityTypeComponent;
  let fixture: ComponentFixture<EditFacilityTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditFacilityTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditFacilityTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
