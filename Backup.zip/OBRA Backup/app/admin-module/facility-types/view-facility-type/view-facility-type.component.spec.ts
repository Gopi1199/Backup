import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewFacilityTypeComponent } from './view-facility-type.component';

describe('ViewFacilityTypeComponent', () => {
  let component: ViewFacilityTypeComponent;
  let fixture: ComponentFixture<ViewFacilityTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewFacilityTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewFacilityTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
