import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FacilityTypesComponent } from './facility-types.component';

describe('FacilityTypesComponent', () => {
  let component: FacilityTypesComponent;
  let fixture: ComponentFixture<FacilityTypesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FacilityTypesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FacilityTypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
