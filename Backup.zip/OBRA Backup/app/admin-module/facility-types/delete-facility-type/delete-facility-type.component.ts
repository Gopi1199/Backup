import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';

@Component({
  selector: 'app-delete-facility-type',
  templateUrl: './delete-facility-type.component.html',
  styleUrls: ['./delete-facility-type.component.css']
})
export class DeleteFacilityTypeComponent implements OnInit {
  spinnerFlag: boolean = false;
  @Input() selectedRowId: any;
  @Input() modalRef: any;
  @Input() FacilityTypeGridData: any;
  data: Object;
  FacilityTypeList: Array<any> = [];
  private deactiveMsgFlag: boolean = false;
  private deactiveMsg: String = '';
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  constructor(private httpService: WebService) {
  }

  ngOnInit() {
  }
  deleteFacilityType() {
    this.spinnerFlag = true;
    this.httpService.deleteRecord('deleteFacilityType?facilityTypeId=' + this.selectedRowId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.deactiveMsgFlag = true;
        this.deactiveMsg = 'Record deactivated successfully';
        setTimeout(() => {
          this.modalRef.hide();
        }, 2000);
        this.RefreshFacilityTypeModal();
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
  RefreshFacilityTypeModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('searchFacilityTypes', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.FacilityTypeList = res.data;
        this.FacilityTypeGridData.tableData = this.FacilityTypeList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
}
