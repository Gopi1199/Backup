import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteFacilityTypeComponent } from './delete-facility-type.component';

describe('DeleteFacilityTypeComponent', () => {
  let component: DeleteFacilityTypeComponent;
  let fixture: ComponentFixture<DeleteFacilityTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteFacilityTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteFacilityTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
