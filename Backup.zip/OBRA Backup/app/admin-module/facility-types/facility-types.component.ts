import { Component, OnInit, TemplateRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ValidationService } from '../../validation/validation.service';
import { ControllerMessageComponent } from '../../validation/controller-message/controller-message.component';
import { recordslimitOptions } from '../../JSON';
@Component({
  selector: 'app-facility-types',
  templateUrl: './facility-types.component.html',
  styleUrls: ['./facility-types.component.css']
})
export class FacilityTypesComponent implements OnInit {
  private modalRef: BsModalRef;
  private selectedRowId: Number;
  private selectedRowData: any;
  private deactiveMsgFlag: boolean = false;
  private deactiveMsg: String = '';
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private spinnerFlag: boolean = false;
  FacilityTypeList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  FacilityTypeGridData: any = {
    'gridName': 'Facility  Types',
    'primaryKey': 'facilityTypesId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Name', dataField: 'name', width: '10%', sort: true, sortColumn: 'name' },
      { caption: 'Short Name', dataField: 'shortName', width: '80%', sort: true, sortColumn: 'shortName' },
      { caption: 'Active', dataField: 'active', width: '10%', sort: true, sortColumn: 'active' }
    ]
  };
  mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {

    this.data = {
      'InputFields': [{ 'cmhBoardId': 100 }],
      'SortFields': [{ 'cmhBoardId': 100 }],
      'startIndex': 0,
      'maxResults': 100,
      'orderBy': 'cmhBoardId'
    };

    this.limitOptions = recordslimitOptions;
    this.RefreshFacilityTypeModal();
  }
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.FacilityTypeList.length / event);
    this.pageSize = event;
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.facilityTypesId;

  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
  }
  AddFacilityTypeModal(AddFacilityType: TemplateRef<any>) {
    this.messageFlag = false;
    this.notifyMsg = '';
    // this.addFacilityTypeForm.reset();
    this.modalRef = this.modalService.show(AddFacilityType);
  }
  RefreshFacilityTypeModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('searchFacilityTypes', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.FacilityTypeList = res.data;
        this.FacilityTypeGridData.tableData = this.FacilityTypeList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }
  EditFacilityTypeModal(EditFacilityType: TemplateRef<any>, SelectFacilityType: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.spinnerFlag = true;
      this.messageFlag = false;
      this.notifyMsg = '';
      this.httpService.getRecord('viewFacilityType?facilityTypeId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
          this.modalRef = this.modalService.show(EditFacilityType);
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });


    } else {
      this.modalRef = this.modalService.show(SelectFacilityType);
    }
  }
  ViewFacilityTypeModal(ViewFacilityType: TemplateRef<any>, SelectFacilityType: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(ViewFacilityType);
      this.spinnerFlag = true;
      this.httpService.deleteRecord('viewFacilityType?facilityTypeId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectFacilityType);
    }
  }
  DeleteFacilityTypeModal(DeleteFacilityType: TemplateRef<any>, SelectFacilityType: TemplateRef<any>) {
    this.deactiveMsgFlag = false;
    this.deactiveMsg = '';
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(DeleteFacilityType);
    } else {
      this.modalRef = this.modalService.show(SelectFacilityType);
    }
  }
  SearchFacilityTypeModal(SearchFacilityType: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchFacilityType);
  }

}
