import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';

@Component({
  selector: 'app-delete-item',
  templateUrl: './delete-item.component.html',
  styleUrls: ['./delete-item.component.css']
})
export class DeleteItemComponent implements OnInit {
  spinnerFlag: boolean = false;
  @Input() selectedRowId: any;
  @Input() modalRef: any;
  @Input() agenciesGridData: any;
  data: Object;
  userList: Array<any> = [];
  private deactiveMsgFlag: boolean = false;
  private deactiveMsg: String = '';
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  constructor(private httpService: WebService) {
  }

  ngOnInit() {
  }
  deleteAgencies() {
    // console.log(this.selectedRowId);
    this.spinnerFlag = true;
    this.httpService.deleteRecord('deleteAgenciesById?agenciesById=' + this.selectedRowId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.deactiveMsgFlag = true;
        this.deactiveMsg = 'Record deactivated successfully';
        setTimeout(() => {
          this.modalRef.hide();
        }, 2000);
        this.RefreshAgenciesModal();
      } else {

      }

    }, error => {

    });
  }
  RefreshAgenciesModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 1,
      'maxResults': 100
    };
    this.httpService.getRecordList('agenciesList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.userList = res.data;
        this.totalPages = Math.ceil(this.userList.length / this.pageSize);
        this.agenciesGridData.tableData = this.userList;
      } else {
      }
      }, error => {

    });
  }
}

