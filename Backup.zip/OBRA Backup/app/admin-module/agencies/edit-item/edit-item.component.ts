import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { ValidationService } from '../../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { dateFormat } from '../../../JSON';
@Component({
  selector: 'app-edit-item',
  templateUrl: './edit-item.component.html',
  styleUrls: ['./edit-item.component.css']
})
export class EditItemComponent implements OnInit {
  private editAgenciesForm: any;
  private data: Object;
  spinnerFlag: boolean = false;
  private messageFlag: boolean = false;
  private disablePre: Boolean = false;
  private disableNxt: Boolean = false;
  private notifyMsg: String = '';
  private selectedRowId: Number;
  private setClickedRow: Function;
  private currentIdx: any;
  private currentRecId: any;
  private nextIdx: any;
  @Input() modalRef: any;
  @Input() selectedRowData: any;
  @Input() cmhBoardAll: any;
  @Output() currentId: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();
  userList: Array<any> = [];
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  private recordsAll: any;
  private recCount: any;
  @Input() agenciesGridData: any;
  private dateFormat: any;
  mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) {
    this.dateFormat = dateFormat;
  }

  ngOnInit() {
    this.recordsAll = JSON.parse(localStorage.getItem('recAll'));
    this.recCount = this.recordsAll.length - 1;
    if (Number(localStorage.getItem('currentIndex')) === 1) {
      this.disablePre = true;
    } else if (Number(localStorage.getItem('currentIndex')) === this.recCount) {
      this.disableNxt = true;
    }

    this.editAgenciesForm = this.formBuilder.group({
      'name': ['', Validators.required],
      'coordinatorLastName': ['', Validators.required],
      'coordinatorFirstName': ['', Validators.required],
      'coordinatorMiddleName': [''],
      'coordinatorTitle': ['', Validators.required],
      'coordinatorGender': ['', Validators.required],
      'addressLine1': ['', Validators.required],
      'addressLine2': [''],
      'city': ['', Validators.required],
      'state': ['', Validators.required],
      'zipcode1': ['', [Validators.required, ValidationService.zipCodeValidator]],
      'zipcode2': ['', ValidationService.zipCodeValidator],
      'phoneNumber': ['', Validators.required],
      'faxNumber': ['', ValidationService.faxNumberValidator],
      'cmhBoardId': ['', Validators.required],
      'active': ['', Validators.required],
      'createdBy': [{ value: '', disabled: true }],
      'createdOn': [{ value: '', disabled: true }],
      'modifiedBy': [{ value: '', disabled: true }],
      'modifiedOn': [{ value: '', disabled: true }]
    });
  }

  editAgenciesSubmit(event: any) {

    Object.keys(this.editAgenciesForm.controls).forEach(field => {
      const control = this.editAgenciesForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.editAgenciesForm.valid) {
      let phone = String(this.editAgenciesForm.value.phoneNumber);
      phone = phone.replace(/\D+/g, '');
      this.editAgenciesForm.value.phoneNumber = phone;
      this.data = this.editAgenciesForm.value;
      this.data['agencyId'] = this.selectedRowData.agencyId;
      this.spinnerFlag = true;
      this.notifyMsg = '';
      this.messageFlag = false;
      this.httpService.updateRecord('editAgency', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.messageFlag = true;
          this.notifyMsg = 'Record updated successfully';
          setTimeout(() => {
            this.modalRef.hide();
          }, 2000);
          this.RefreshAgenciesModal();
        } else {
        }

      }, error => {
      });

    }
  }
  RefreshAgenciesModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 1,
      'maxResults': 100
    };
    this.httpService.getRecordList('agenciesList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.userList = res.data;
        this.totalPages = Math.ceil(this.userList.length / this.pageSize);
        this.agenciesGridData.tableData = this.userList;
      } else {
        this.spinnerFlag = false;
      }

    }, error => {
      this.spinnerFlag = false;
    });
  }
  EditAgenciesModal(id) {
    this.spinnerFlag = true;
    this.httpService.getRecord('viewAgency?agenciesId=' + id).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.selectedRowData = res.data;

      } else {
      }
    }, error => {
    });
  }
  recordNavigation(action) {

    this.disablePre = false;
    this.disableNxt = false;
    // const recordsAll: any = JSON.parse(localStorage.getItem('recAll'));
    this.currentIdx = localStorage.getItem('currentIndex');

    if (action === 'previous') {
      this.currentRecId = this.recordsAll[Number(this.currentIdx) - 1];
      this.currentIdx = Number(this.currentIdx) - 1;
    } else {
      this.currentRecId = this.recordsAll[Number(this.currentIdx) + 1];
      this.currentIdx = Number(this.currentIdx) + 1;
    }
    if (this.currentIdx === 1) {
      this.disablePre = true;
    }
    if (this.currentIdx === this.recCount) {
      this.disableNxt = true;
    }
    localStorage.setItem('currentIndex', this.currentIdx);
    const list = Array.from(document.getElementById('gridTable').querySelectorAll('tbody tr'));
    list.forEach(function (node) { node.className = ''; });
    document.getElementById(this.currentRecId).classList.add('highlighted');
    this.EditAgenciesModal(this.currentRecId);
    this.currentId.emit(this.currentRecId);
  }
}
