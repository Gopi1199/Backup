import { Component, OnInit, Input, Output, TemplateRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ValidationService } from '../../validation/validation.service';
import { ControllerMessageComponent } from '../../validation/controller-message/controller-message.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { recordslimitOptions } from '../../JSON';
import { forkJoin } from 'rxjs/observable/forkJoin';

@Component({
  selector: 'app-agencies',
  templateUrl: './agencies.component.html',
  styleUrls: ['./agencies.component.css']

})
export class AgenciesComponent implements OnInit {
  @Input() currentId: any;
  private modalRef: BsModalRef;
  private selectedRowId: Number;
  private selectedRowData: any;
  private cmhBoardAll: any;
  spinnerFlag: boolean = false;
  userList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  errorMessage: string;
  agenciesGridData: any = {
    'gridName': 'Agencies',
    'primaryKey': 'agenciesId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Agency Name', dataField: 'name', width: '20%', sort: true, sortColumn: 'name' },
      { caption: 'Coordinator Last Name', dataField: 'coordinatorLastName', width: '20%', sort: true, sortColumn: 'coordinatorLastName' },
      {
        caption: 'Coordinator First Name', dataField: 'coordinatorFirstName', width: '20%', sort: true,
        sortColumn: 'coordinatorFirstName'
      },
      { caption: 'Phone', dataField: 'phone', width: '10%', sort: true, sortColumn: 'phone' },
      { caption: 'CMH Board', dataField: 'cmhBoard', width: '20%', sort: true, sortColumn: 'cmhBoard' },
      { caption: 'Active', dataField: 'active', width: '10%', sort: true, sortColumn: 'active' }
    ]
  };
  mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {
    // this.data = {
    //   'InputFields': [{ 'cmhBoardId': 100 }],
    //   'SortFields': [{ 'cmhBoardId': 100 }],
    //   'max': 40,
    //   'skip': 40,
    //   'orderBy': 'cmhBoardId'
    // };
    this.limitOptions = recordslimitOptions;
    this.RefreshAgenciesModal();
  }
  pageChanged($event) {
    this.pageNumber = $event;
    console.log($event);
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.userList.length / event);
    this.pageSize = event;
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.agenciesId;
  }
  onCurrentId(data: any): void {
      this.selectedRowId = data;
  }
  AddAgenciesModal(AddAgencies: TemplateRef<any>) {
    this.spinnerFlag = true;
    this.httpService.getRecord('cmhBoardDropDown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.cmhBoardAll = res.data;
        this.modalRef = this.modalService.show(AddAgencies);
      } else {
        // console.log('error');
      }
    }, error => {
      this.errorMessage = error.data;
    });
  }
  RefreshAgenciesModal() {
    this.spinnerFlag = true;
    // this.data = {
    //   'startIndex': this.gridModel.maxRows,
    //   'maxResults': this.gridModel.startIndex
    // // };
    this.data = {
      'startIndex': 1,
      'maxResults': 100
    };
    this.httpService.getRecordList('agenciesList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.userList = res.data;
        this.totalPages = Math.ceil(this.userList.length / this.pageSize);
        this.agenciesGridData.tableData = this.userList;
      } else if (res.global === 'errorMsg@') {
        this.spinnerFlag = false;
        this.errorMessage = res.data;
      }
      // else {
      //   this.spinnerFlag = false;
      //   if (res.status === 404) {
      //     this.errorMessage = 'Request ' + res.statusText;
      //   } else if (res.status === 500) {
      //     this.errorMessage = 'Server down ' + res.statusText;
      //   } else {
      //     this.errorMessage = res.statusText;
      //   }
      // }
    }, error => {
      this.spinnerFlag = false;
      // console.log('error message');
      this.errorMessage = error;
    });
  }
  EditAgenciesModal(EditAgencies: TemplateRef<any>, SelectAgencies: TemplateRef<any>) {
    console.log(this.currentId);
    if (this.currentId !== undefined) {
      this.selectedRowId = this.currentId;
    }
    if (this.selectedRowId) {
      this.spinnerFlag = true;
      const agenciesInfo = this.httpService.getRecord('viewAgency?agenciesId=' + this.selectedRowId);
      const cmhBoardDropDown = this.httpService.getRecord('cmhBoardDropDown');
      forkJoin([agenciesInfo, cmhBoardDropDown]).subscribe(results => {

        if (results[0].global === 'successMsg@' && results[1].global === 'successMsg@') {
          this.selectedRowData = results[0].data;
          this.cmhBoardAll = results[1].data;
          this.spinnerFlag = false;
          this.modalRef = this.modalService.show(EditAgencies);
        }
      });
    } else {
      this.modalRef = this.modalService.show(SelectAgencies);
    }
  }

  ViewAgenciesModal(ViewAgencies: TemplateRef<any>, SelectAgencies: TemplateRef<any>) {
    if (this.selectedRowId) {

      this.spinnerFlag = true;
      this.httpService.deleteRecord('viewAgency?agenciesId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.selectedRowData = res.data;
          this.spinnerFlag = false;
          this.modalRef = this.modalService.show(ViewAgencies);
        } else {
          // console.log('error');
        }

      }, error => {
        // console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectAgencies);
    }
  }
  DeleteAgenciesModal(DeleteAgencies: TemplateRef<any>, SelectAgencies: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(DeleteAgencies);
    } else {
      this.modalRef = this.modalService.show(SelectAgencies);
    }
  }
  SearchAgenciesModal(SearchAgencies: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchAgencies);
  }
}


