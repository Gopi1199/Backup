import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ValidationService } from '../../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { WebService } from '../../../Service/webservice';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

@Component({
  selector: 'app-add-items',
  templateUrl: './add-items.component.html',
  styleUrls: ['./add-items.component.css']
})
export class AddItemsComponent implements OnInit {
  @Input() modalRef: any;
  @Input() agenciesGridData: any;
  @Input() cmhBoardAll: any;
  private addAgenciesForm: any;
  private data: Object;
  private addAgenciesValidateFlag: boolean = false;
  private addAgenciesValidationMsg: String = '';
  spinnerFlag: boolean = false;
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  userList: Array<any> = [];
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.addAgenciesForm = this.formBuilder.group({
      'name': ['', Validators.required],
      'coordinatorLastName': ['', Validators.required],
      'coordinatorFirstName': ['', Validators.required],
      'coordinatorMiddleName': [''],
      'coordinatorTitle': ['', Validators.required],
      'coordinatorGender': ['', Validators.required],
      'addressLine1': ['', Validators.required],
      'addressLine2': [''],
      'city': ['', Validators.required],
      'state': ['', Validators.required],
      'zipcode1': ['', [Validators.required, ValidationService.zipCodeValidator]],
      'zipcode2': ['', ValidationService.zipCodeValidator],
      'phoneNumber': ['', Validators.required],
      'faxNumber': ['', ValidationService.faxNumberValidator],
      'cmhBoardId': ['', Validators.required],
      'active': ['', Validators.required],
      'createdBy': [{ value: '', disabled: true }],
      'createdOn': [{ value: '', disabled: true }],
      'modifiedBy': [{ value: '', disabled: true }],
      'modifiedOn': [{ value: '', disabled: true }]
    });
  }
  addAgenciesSubmit(event: any) {
    Object.keys(this.addAgenciesForm.controls).forEach(field => {
      const control = this.addAgenciesForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.addAgenciesForm.valid) {
      let phone = String(this.addAgenciesForm.value.phoneNumber);
      phone = phone.replace(/\D+/g, '');
      this.addAgenciesForm.value.phoneNumber = phone;
      this.data = this.addAgenciesForm.value;
      this.spinnerFlag = true;
      this.messageFlag = false;
      this.notifyMsg = '';
      this.httpService.addRecord('editAgency', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.messageFlag = true;
          this.notifyMsg = 'Record added successfully';
          this.RefreshAgenciesModal();
          setTimeout(() => {
            this.modalRef.hide();
          }, 2000);
          this.RefreshAgenciesModal();
        } else {

        }

      }, error => {

      });

    }
    }
  RefreshAgenciesModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 1,
      'maxResults': 100
    };
    this.httpService.getRecordList('agenciesList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.userList = res.data;
        this.totalPages = Math.ceil(this.userList.length / this.pageSize);
        this.agenciesGridData.tableData = this.userList;
      } else {
      }

    }, error => {
    });
  }
  addAgenciesClose() {
    this.modalRef.hide();
    this.spinnerFlag = false;
  }

}
