import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-search-item',
  templateUrl: './search-item.component.html',
  styleUrls: ['./search-item.component.css']
})
export class SearchItemComponent implements OnInit {
  private searchAgenciesForm: any;
  private searchMsgFlag: boolean = true;
  private searchError: String;
  spinnerFlag: boolean = false;
  data: Object;
  private filter: any;
  private searchInput: Object;
  private searchsuccess: String;
  private searchErrorMsgFlag: boolean = false;
  @Input() agenciesGridData: any;
  @Input() modalRef: any;
  userList: Array<any> = [];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) { }
  ngOnInit() {
    this.searchAgenciesForm = this.formBuilder.group({
      'id': [''],
      'value': ['']
    });
  }
  SearchReset() {
    this.searchAgenciesForm.reset();
  }
  SearchAgenciesSubmit() {
    this.filter = { filters: [this.searchAgenciesForm.value] };
    this.searchInput = {
      'max': 100,
      'skip': 0,
      'orderBy': '',
      'orderType': 'asc',
      'search': JSON.stringify(this.filter)
    };

    this.spinnerFlag = true;
    this.httpService.searchRecord('agenciesList', this.searchInput).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.userList = res.data;
        this.agenciesGridData.tableData = this.userList;
        if (res.data.length === 0) {
          this.searchErrorMsgFlag = true;
          this.searchMsgFlag = false;
          this.searchError = 'Records Not found';

        } else {
          this.searchMsgFlag = true;
          this.searchErrorMsgFlag = false;
          this.searchsuccess = 'Records found';
        }
       
      } else {
        this.searchErrorMsgFlag = true;
        this.searchMsgFlag = false;
        this.searchError = 'No records found';
        
      }
    }, error => {
    });
  }
}
