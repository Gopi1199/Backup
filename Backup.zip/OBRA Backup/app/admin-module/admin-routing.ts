import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminMainComponent } from './admin-main/admin-main.component';
import { AdminDashboardComponent } from '../admin-dashboard/admin-dashboard.component';
import { AgenciesComponent } from './agencies/agencies.component';
import { AxisOneTwoComponent } from './axis-one-two/axis-one-two.component';
import { DeterminationComponent } from './determination/determination.component';
import { DiagnosisCategoriesComponent } from './diagnosis-categories/diagnosis-categories.component';
import { MissingInformationComponent } from './missing-information/missing-information.component';
import { TerminationComponent } from './termination/termination.component';
import { Axis3Component } from './axis3/axis3.component';
import { CareFacilitiesComponent } from './care-facilities/care-facilities.component';
import { CMHBoardComponent } from './cmhboard/cmhboard.component';
import { CMHRecommendationComponent } from './cmhrecommendation/cmhrecommendation.component';
import { DischargeComponent } from './discharge/discharge.component';
import { EvaluationTypeComponent } from './evaluation-type/evaluation-type.component';
import { FacilityTypesComponent } from './facility-types/facility-types.component';
import { NotificationMethodComponent } from './notification-method/notification-method.component';
import { NotifiedPersonComponent } from './notified-person/notified-person.component';
import { RelationshipComponent } from './relationship/relationship.component';
import { RepresentativeTypeComponent } from './representative-type/representative-type.component';
import { ServiceProvidersComponent } from './service-providers/service-providers.component';
import { RolesComponent } from './roles/roles.component';
import { SearchRoleComponent } from './roles/search-role/search-role.component';
import { AddRolesComponent } from './roles/add-roles/add-roles.component';
import { RoleDetailComponent } from './roles/role-detail/role-detail.component';
import { EditRoleComponent } from './roles/edit-role/edit-role.component';
const routes: Routes = [
    { path: '', component: AdminMainComponent, pathMatch: 'full' },
    { path: 'adminDashboard', pathMatch: 'full', component: AdminMainComponent },
    { path: 'agencies', pathMatch: 'full', component: AgenciesComponent },
    { path: 'axisOneTwo', pathMatch: 'full', component: AxisOneTwoComponent },
    { path: 'determination', pathMatch: 'full', component: DeterminationComponent },
    { path: 'diagnosisCategories', pathMatch: 'full', component: DiagnosisCategoriesComponent },
    { path: 'missingInformation', pathMatch: 'full', component: MissingInformationComponent },
    { path: 'termination', pathMatch: 'full', component: TerminationComponent },
    { path: 'axis3', pathMatch: 'full', component: Axis3Component },
    { path: 'careFacilities', pathMatch: 'full', component: CareFacilitiesComponent },
    { path: 'CMHBoard', pathMatch: 'full', component: CMHBoardComponent },
    { path: 'CMHRecommendation', pathMatch: 'full', component: CMHRecommendationComponent },
    { path: 'discharge', pathMatch: 'full', component: DischargeComponent },
    { path: 'evaluationType', pathMatch: 'full', component: EvaluationTypeComponent },
    { path: 'facilityTypes', pathMatch: 'full', component: FacilityTypesComponent },
    { path: 'notificationMethod', pathMatch: 'full', component: NotificationMethodComponent },
    { path: 'notifiedPerson', pathMatch: 'full', component: NotifiedPersonComponent },
    { path: 'relationship', pathMatch: 'full', component: RelationshipComponent },
    { path: 'representativeType', pathMatch: 'full', component: RepresentativeTypeComponent },
    { path: 'serviceProviders', pathMatch: 'full', component: ServiceProvidersComponent },
    { path: 'roles', pathMatch: 'full', component: RolesComponent },
    { path: 'SearchRoles', pathMatch: 'full', component: SearchRoleComponent },
    { path: 'addRoles', pathMatch: 'full', component: AddRolesComponent },
    { path: 'editRoles', pathMatch: 'full', component: EditRoleComponent },
    { path: 'role-detail/:id', pathMatch: 'full', component: RoleDetailComponent },
    { path: '**', redirectTo: 'dashboard', pathMatch: 'full' }
];

export const AdminRoutes: ModuleWithProviders = RouterModule.forChild(routes);
