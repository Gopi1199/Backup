import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewDeterminationComponent } from './view-determination.component';

describe('ViewDeterminationComponent', () => {
  let component: ViewDeterminationComponent;
  let fixture: ComponentFixture<ViewDeterminationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewDeterminationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewDeterminationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
