import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { recordslimitOptions } from '../../JSON';

@Component({
  selector: 'app-determination',
  templateUrl: './determination.component.html',
  styleUrls: ['./determination.component.css']
})
export class DeterminationComponent implements OnInit {
  private modalRef: BsModalRef;
  private selectedRow: Number;
  private setClickedRow: Function;
  private selectedRowData: any;
  private selectedRowId: Number;
  private spinnerFlag: boolean = false;
  determinationList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  determinationGridData: any = {
    'gridName': 'CMH Determinations',
    'primaryKey': 'determinationId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Code', dataField: 'code', width: '10%', sort: true, sortColumn: 'code' },
      { caption: 'Name', dataField: 'name', width: '35%', sort: true, sortColumn: 'name'},
      { caption: 'Description', dataField: 'description', width: '35%', sort: true, sortColumn: 'description' },
      { caption: 'Default Flag', dataField: 'defaultFlag', width: '10%', sort: true, sortColumn: 'defaultFlag' },
      { caption: 'Active', dataField: 'active', width: '10%', sort: true, sortColumn: 'active' }
    ]
  };

  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.limitOptions = recordslimitOptions;
    this.refreshDeterminationModal();
  }
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.determinationList.length / event);
    this.pageSize = event;
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.determinationId;

  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
  }
  refreshDeterminationModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('determinationList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.determinationList = res.data;
        this.determinationGridData.tableData = this.determinationList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }

  ViewDeterminationModal(ViewDetermination: TemplateRef<any>, SelectDetermination: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(ViewDetermination);
      this.spinnerFlag = true;
      this.httpService.deleteRecord('viewDetermination?determinationId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectDetermination);
    }
  }

  SearchDeterminationModal(SearchDetermination: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchDetermination);
  }

}
