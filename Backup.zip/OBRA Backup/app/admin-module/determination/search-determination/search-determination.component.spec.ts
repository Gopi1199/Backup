import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchDeterminationComponent } from './search-determination.component';

describe('SearchDeterminationComponent', () => {
  let component: SearchDeterminationComponent;
  let fixture: ComponentFixture<SearchDeterminationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchDeterminationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchDeterminationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
