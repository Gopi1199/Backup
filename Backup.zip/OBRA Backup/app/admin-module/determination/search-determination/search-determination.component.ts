import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-search-determination',
  templateUrl: './search-determination.component.html',
  styleUrls: ['./search-determination.component.css']
})
export class SearchDeterminationComponent implements OnInit {
  private searchCMHBoardsForm: any;
  private searchMsgFlag: boolean = true;
  private searchError: String = '';
  spinnerFlag: boolean = false;
  data: Object;
  private filter: any;
  private searchInput: Object;
  private searchsuccess: String = '';
  private searchErrorMsgFlag: boolean = false;
  @Input() determinationGridData: any;
  @Input() modalRef: any;
  determinationList: Array<any> = [];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) { }
  ngOnInit() {
    this.searchCMHBoardsForm = this.formBuilder.group({
      'id': [''],
      'value': ['']
    });
  }
  SearchReset() {
    this.searchCMHBoardsForm.reset();
  }
  searchCMHBoardsSubmit() {

    this.searchError = '';
    this.searchsuccess = '';
    this.filter = { filters: [this.searchCMHBoardsForm.value] };
    this.searchInput = {
      'max': 100,
      'skip': 0,
      'orderBy': '',
      'orderType': 'asc',
      'search': JSON.stringify(this.filter)
    };

    this.spinnerFlag = true;
    this.httpService.searchRecord('determinationList', this.searchInput).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.determinationList = res.data;
        this.determinationGridData.tableData = this.determinationList;
        if (res.data.length === 0) {
          this.searchErrorMsgFlag = true;
          this.searchMsgFlag = false;
          this.searchError = 'Records Not found';

        } else {
          this.searchMsgFlag = true;
          this.searchErrorMsgFlag = false;
          this.searchsuccess = 'Records found';
        }
        
      } else {
        this.searchErrorMsgFlag = true;
        this.searchMsgFlag = false;
        this.searchError = 'No records found';
        
      }
    }, error => {
      console.log(error);
    });
  }
}
