import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { CommonServiceService } from '../../../Service/common-service.service';

@Component({
  selector: 'app-add-roles',
  templateUrl: './add-roles.component.html',
  styleUrls: ['./add-roles.component.css']
})
export class AddRolesComponent implements OnInit {
  private addroleForm: any;
  private forkResponse: any;
  private settingsPermissions: any;
  private permissionData;
  private selectedPermissionsItems;
  private permissionList: any;
  private data: Object;
  private selectedItems: any;
  private permissions:any[];
  private addRow;
  private str: any;
  private status: any = [{ 'key': 'A', name: 'Active' }, { 'key': 'I', name: 'Inactive' }];
  @Input() dataUrl: string;
  constructor(private router: Router, private Activatedroute: ActivatedRoute, private builder: FormBuilder,
    private httpService: WebService, private CommonServiceData: CommonServiceService) { }

  ngOnInit() {
    this.addroleForm = this.builder.group({
      'roleName': ['', Validators.required],
      'status': ['', Validators.required],
      'permissions': ['', Validators.required]
    });

      this.getPermission();

    
      }
     
    

  loadPermissionMultiselect() {
    this.str = JSON.stringify(this.permissionData);
    this.str = this.str.replace(/name/g, 'itemName');
    this.permissionData = JSON.parse(this.str);
    this.settingsPermissions = {
      singleSelection: false,
      text: 'Select',
      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: false,
      badgeShowLimit: 1,
      selectedLabel: 'Permissions selected',
      classes: '',
      disabled: false,
      searchPlaceholderText: 'Search',
      showCheckbox: true,
      noDataLabel: 'No Data Available',
      searchAutofocus: true
    };
  }

  addRoles() {
    this.permissionList = [];

    Object.keys(this.addroleForm.controls).forEach(field => {
      const control = this.addroleForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });

    if (this.selectedPermissionsItems !== undefined) {
      console.log(this.selectedPermissionsItems);
      // this.selectedPermissionsItems.forEach(element => {
      //   this.permissionList.push(Number(element.id));
      // });
    }

    this.data = {
      "roleName":this.addroleForm.controls['roleName'].value,
      "status":this.addroleForm.controls['status'].value,
      "permissions":this.permissionList
    };


     this.httpService.getRecordList('editRole',this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.addRow = res.data;
      } else {
        
      }

    }, error => {
      console.log(error);
    });
  }

  getPermission(){
    this.httpService.getRecord('permissionsDropdown').subscribe(res => {
      if (res.global === 'successMsg@') {
        this.permissionData = res.data;
        this.loadPermissionMultiselect();
        console.log(this.permissionData);
      } else {
        
      }

    }, error => {
      console.log(error);
    });
  }
     }

