import { Component, OnInit ,OnDestroy, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { CommonServiceService } from '../../../Service/common-service.service';

@Component({
  selector: 'app-edit-role',
  templateUrl: './edit-role.component.html',
  styleUrls: ['./edit-role.component.css']
})
export class EditRoleComponent implements OnInit {
  private editroleForm: any;
  private forkResponse: any;
  private settingsrolePermissions: any;
  constructor(private router: Router, private Activatedroute: ActivatedRoute, private builder: FormBuilder,
    private httpService: WebService, private CommonServiceData: CommonServiceService) { }

   
  ngOnInit() {
    this.editroleForm = this.builder.group({
      'roleName': ['', Validators.required],
      'status': ['', Validators.required],
      'permissions': ['', Validators.required]
    });
  }
  editRoleSubmit() {
    Object.keys(this.editroleForm.controls).forEach(field => {
      const control = this.editroleForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
  }

  loadRoleMultiselect() {

    this.settingsrolePermissions = {
      singleSelection: false,
      text: 'Select',
      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: false,
      badgeShowLimit: 1,
      selectedLabel: 'Roles selected',
      classes: '',
      disabled: false,
      searchPlaceholderText: 'Search',
      showCheckbox: true,
      noDataLabel: 'No Data Available',
      searchAutofocus: true
    };
  }
}
