import { Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { WebService } from '../../../Service/webservice';
import { DateService } from '../../../Service/date.service';
@Component({
  selector: 'app-search-role',
  templateUrl: './search-role.component.html',
  styleUrls: ['./search-role.component.css']
})
export class SearchRoleComponent implements OnInit {

 
  private dataUrl: string;
  private configUrl: string;
  searchInput: Object = {};
  private sucessFlag: boolean;
  private sucessMsg: string;
  private errorFlag: boolean;
  private errorMsg: string;
  private data: Object;
  private selectedRowId: Number;
  private selectedRowData: any;
  constructor(private activeRoute: ActivatedRoute, private router: Router, private dateService: DateService) {
  
}
  ngOnInit() {
    this.dataUrl = 'rolesLists';
    this.configUrl = 'Roles.json';
    this.searchInput = {
      "search": "{\"filters\":[{\"id\":\"\",\"value\":\"\"}]}"
    };
    }
    onNotify(data: any): void {
      this.selectedRowData = data;
      this.selectedRowId = data.roleId;
      console.log(data.roleId);
      this.router.navigate(['/dashboard/adminDashboard/role-detail', this.selectedRowId]);     
    }
    
    
  gotoaddroles() {       
    this.router.navigate(['/dashboard/adminDashboard/addRoles']);
  }

}
