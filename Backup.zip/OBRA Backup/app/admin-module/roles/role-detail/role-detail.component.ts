import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../../validation/validation.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { CommonServiceService } from '../../../Service/common-service.service';

@Component({
  selector: 'app-role-detail',
  templateUrl: './role-detail.component.html',
  styleUrls: ['./role-detail.component.css']
})
export class RoleDetailComponent implements OnInit {
  private sub: any;
  private roleId: any;
  private selectedRowData: any;
  private activeStatus: Boolean = true;
  constructor(private router: Router,private activeRoute: ActivatedRoute, private builder: FormBuilder,
    private httpService: WebService, private CommonServiceData: CommonServiceService) { }

  ngOnInit() {
    this.sub = this.activeRoute.params.subscribe(params => {
      this.roleId = Number(params['id']);
      console.log(this.roleId);
      this. getRoleInfo();
    });
  }
  getRoleInfo() {
    //this.spinnerFlag = true;
    this.selectedRowData = [];
    this.selectedRowData['clientLegalRepViews'] = [];
    this.selectedRowData['address'] = [];
    this.httpService.getRecord('viewRole?roleId=' + this.roleId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.selectedRowData = res.data;      
       
      // this.spinnerFlag = false;
        
      } else {
       // this.spinnerFlag = false;
       // this.errorFlag = true;
      //  this.erroMsg = res.inline;
      }

    }, error => {
      console.log(error);
    });
  }
  geteditrole() {
    this.router.navigate(['/dashboard/adminDashboard/editRoles']);
  }
  roledetailCancel() {
    this.router.navigate(['/dashboard/adminDashboard/roles']);
  }
}
