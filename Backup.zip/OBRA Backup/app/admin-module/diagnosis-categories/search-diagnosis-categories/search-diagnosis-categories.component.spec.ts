import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchDiagnosisCategoriesComponent } from './search-diagnosis-categories.component';

describe('SearchDiagnosisCategoriesComponent', () => {
  let component: SearchDiagnosisCategoriesComponent;
  let fixture: ComponentFixture<SearchDiagnosisCategoriesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchDiagnosisCategoriesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchDiagnosisCategoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
