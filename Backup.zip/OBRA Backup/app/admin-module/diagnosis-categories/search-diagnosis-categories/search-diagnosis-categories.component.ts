import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-search-diagnosis-categories',
  templateUrl: './search-diagnosis-categories.component.html',
  styleUrls: ['./search-diagnosis-categories.component.css']
})
export class SearchDiagnosisCategoriesComponent implements OnInit {
  private searchDiagnosisForm: any;
  private searchMsgFlag: boolean = true;
  private searchError: String = '';
  spinnerFlag: boolean = false;
  data: Object;
  private filter: any;
  private searchInput: Object;
  private searchsuccess: String = '';
  private searchErrorMsgFlag: boolean = false;
  @Input() diagnosisCategoriesGridData: any;
  @Input() modalRef: any;
  diagnosisCategoriesList: Array<any> = [];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) { }
  ngOnInit() {
    this.searchDiagnosisForm = this.formBuilder.group({
      'id': [''],
      'value': ['']
    });
  }
  SearchReset() {
    this.searchDiagnosisForm.reset();
  }
  searchDiagnosisSubmit() {

    this.searchError = '';
    this.searchsuccess = '';
    this.filter = { filters: [this.searchDiagnosisForm.value] };
    this.searchInput = {
      'max': 100,
      'skip': 0,
      'orderBy': '',
      'orderType': 'asc',
      'search': JSON.stringify(this.filter)
    };

    this.spinnerFlag = true;
    this.httpService.searchRecord('searchDiagnosisCategories', this.searchInput).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.diagnosisCategoriesList = res.data;
        this.diagnosisCategoriesGridData.tableData = this.diagnosisCategoriesList;
        if (res.data.length === 0) {
          this.searchErrorMsgFlag = true;
          this.searchMsgFlag = false;
          this.searchError = 'Records Not found';

        } else {
          this.searchMsgFlag = true;
          this.searchErrorMsgFlag = false;
          this.searchsuccess = 'Records found';
        }
        
      } else {
        this.searchErrorMsgFlag = true;
        this.searchMsgFlag = false;
        this.searchError = 'No records found';
        
      }
    }, error => {
      console.log(error);
    });
  }
}
