import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewDiagnosisCategoriesComponent } from './view-diagnosis-categories.component';

describe('ViewDiagnosisCategoriesComponent', () => {
  let component: ViewDiagnosisCategoriesComponent;
  let fixture: ComponentFixture<ViewDiagnosisCategoriesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewDiagnosisCategoriesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewDiagnosisCategoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
