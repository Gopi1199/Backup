import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiagnosisCategoriesComponent } from './diagnosis-categories.component';

describe('DiagnosisCategoriesComponent', () => {
  let component: DiagnosisCategoriesComponent;
  let fixture: ComponentFixture<DiagnosisCategoriesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiagnosisCategoriesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiagnosisCategoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
