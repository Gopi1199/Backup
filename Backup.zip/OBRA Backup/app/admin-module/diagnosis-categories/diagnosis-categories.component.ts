import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { recordslimitOptions } from '../../JSON';

@Component({
  selector: 'app-diagnosis-categories',
  templateUrl: './diagnosis-categories.component.html',
  styleUrls: ['./diagnosis-categories.component.css']
})
export class DiagnosisCategoriesComponent implements OnInit {
  private modalRef: BsModalRef;
  private selectedRow: Number;
  private selectedRowData: any;
  private selectedRowId: Number;
  private spinnerFlag: boolean = false;
  diagnosisCategoriesList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  diagnosisCategoriesGridData: any = {
    'gridName': 'Diagnosis Categories',
    'primaryKey': 'diagnosisCategoriesId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Description', dataField: 'description', width: '10%', sort: true, sortColumn: 'description' },
      { caption: 'Name', dataField: 'name', width: '40%', sort: true, sortColumn: 'name' },
      { caption: 'Active', dataField: 'active', width: '10%', sort: true, sortColumn: 'active' }
    ]
  };

  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.limitOptions = recordslimitOptions;
    this.refreshDiagnosisCategoriesModal();
  }
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.diagnosisCategoriesList.length / event);
    this.pageSize = event;
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.diagnosisCategoriesId;

  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
  }
  refreshDiagnosisCategoriesModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('searchDiagnosisCategories', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.diagnosisCategoriesList = res.data;
        this.diagnosisCategoriesGridData.tableData = this.diagnosisCategoriesList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }

  ViewDiagnosisCategoriesModal(ViewDiagnosisCategories: TemplateRef<any>, SelectDiagnosisCategories: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(ViewDiagnosisCategories);
      this.spinnerFlag = true;
      this.httpService.deleteRecord('viewDiagnosisCategories?diagnosisCategoriesId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectDiagnosisCategories);
    }
  }

  SearchDiagnosisCategoriesModal(SearchDiagnosisCategories: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchDiagnosisCategories);
  }

}
