import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchRecommendationComponent } from './search-recommendation.component';

describe('SearchRecommendationComponent', () => {
  let component: SearchRecommendationComponent;
  let fixture: ComponentFixture<SearchRecommendationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchRecommendationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchRecommendationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
