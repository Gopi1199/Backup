import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CMHRecommendationComponent } from './cmhrecommendation.component';

describe('CMHRecommendationComponent', () => {
  let component: CMHRecommendationComponent;
  let fixture: ComponentFixture<CMHRecommendationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CMHRecommendationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CMHRecommendationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
