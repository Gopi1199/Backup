import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { recordslimitOptions } from '../../JSON';

@Component({
  selector: 'app-cmhrecommendation',
  templateUrl: './cmhrecommendation.component.html',
  styleUrls: ['./cmhrecommendation.component.css']
})
export class CMHRecommendationComponent implements OnInit {
  private modalRef: BsModalRef;
  private selectedRowData: any;
  private selectedRowId: Number;
  private spinnerFlag: boolean = false;
  recommendationList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  CMHRecommendationGridData: any = {
    'gridName': 'CMH Recommendations',
    'primaryKey': 'recommendationsId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Code', dataField: 'code', width: '10%', sort: true, sortColumn: 'code' },
      { caption: 'Name', dataField: 'name', width: '35%', sort: true, sortColumn: 'name' },
      { caption: 'Description', dataField: 'description', width: '35%', sort: true, sortColumn: 'description' },
      { caption: 'Default Flag', dataField: 'defaultFlag', width: '10%', sort: true, sortColumn: 'defaultFlag' },
      { caption: 'Active', dataField: 'active', width: '10%', sort: true, sortColumn: 'active' }
    ]
  };

  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {
    // this.searchForm = this.formBuilder.group({
    //   'AgencyName': [''],
    //   'equal': ['']
    // });
    this.limitOptions = recordslimitOptions;
    this.refreshCMHRecommendationModal();
  }
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.recommendationList.length / event);
    this.pageSize = event;
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.recommendationsId;
  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
  }
  refreshCMHRecommendationModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('recommendationList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.recommendationList = res.data;
        this.CMHRecommendationGridData.tableData = this.recommendationList;
      } else {
        console.log('error');
      }

    }, error => {
      console.log(error);
    });
  }

  ViewRecommendationModal(ViewRecommendation: TemplateRef<any>, SelectRecommendation: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.spinnerFlag = true;
      this.httpService.deleteRecord('viewRecommendations?recommendationsId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.selectedRowData = res.data;
          this.modalRef = this.modalService.show(ViewRecommendation);
        } else {
          console.log('error');
        }

      }, error => {
        console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectRecommendation);
    }
  }

  SearchRecommendationModal(SearchRecommendation: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchRecommendation);
  }
}
