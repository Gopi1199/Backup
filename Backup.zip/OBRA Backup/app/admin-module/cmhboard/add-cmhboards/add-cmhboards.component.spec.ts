import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCMHBoardsComponent } from './add-cmhboards.component';

describe('AddCMHBoardsComponent', () => {
  let component: AddCMHBoardsComponent;
  let fixture: ComponentFixture<AddCMHBoardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddCMHBoardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddCMHBoardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
