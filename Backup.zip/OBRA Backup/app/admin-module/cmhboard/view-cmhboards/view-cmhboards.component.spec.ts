import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewCMHBoardsComponent } from './view-cmhboards.component';

describe('ViewCMHBoardsComponent', () => {
  let component: ViewCMHBoardsComponent;
  let fixture: ComponentFixture<ViewCMHBoardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewCMHBoardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewCMHBoardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
