import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DeleteCMHBoardsComponent } from './delete-cmhboards.component';

describe('DeleteCMHBoardsComponent', () => {
  let component: DeleteCMHBoardsComponent;
  let fixture: ComponentFixture<DeleteCMHBoardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteCMHBoardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteCMHBoardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
