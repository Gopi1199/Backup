import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';

@Component({
  selector: 'app-delete-cmhboards',
  templateUrl: './delete-cmhboards.component.html',
  styleUrls: ['./delete-cmhboards.component.css']
})
export class DeleteCMHBoardsComponent implements OnInit {
  spinnerFlag: boolean = false;
  @Input() selectedRowId: any;
  @Input() modalRef: any;
  @Input() CMHBoardsGridData: any;
  data: Object;
  CMHBoardsList: Array<any> = [];
  private deactiveMsgFlag: boolean = false;
  private deactiveMsg: String = '';
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  constructor(private httpService: WebService) {
  }

  ngOnInit() {
  }
  RefreshCMHBoardsModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('cmhBoardList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.CMHBoardsList = res.data;
        this.CMHBoardsGridData.tableData = this.CMHBoardsList;
      } else {
        // console.log('error');
      }

    }, error => {
      // console.log(error);
    });
  }
  deleteCMHBoards() {
    this.spinnerFlag = true;
    this.httpService.deleteRecord('deleteCmhBoard?cmhBoardId=' + this.selectedRowId).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.deactiveMsgFlag = true;
        this.deactiveMsg = 'Record deactivated successfully';
        setTimeout(() => {
          this.modalRef.hide();
        }, 2000);
        this.RefreshCMHBoardsModal();
      } else {
        // console.log('error');
      }

    }, error => {
      // console.log(error);
    });
  }
}
