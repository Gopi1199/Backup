import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { dateFormat } from '../../../JSON';
@Component({
  selector: 'app-edit-cmhboards',
  templateUrl: './edit-cmhboards.component.html',
  styleUrls: ['./edit-cmhboards.component.css']
})
export class EditCMHBoardsComponent implements OnInit {
  private editCMHBoardsForm: any;
  private data: Object;
  spinnerFlag: boolean = false;
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private selectedRowId: Number;
  private setClickedRow: Function;
  @Input() modalRef: any;
  @Input() selectedRowData: any;
  CMHBoardsList: Array<any> = [];
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  private disablePre: Boolean = false;
  private disableNxt: Boolean = false;
  private currentIdx: any;
  private currentRecId: any;
  private nextIdx: any;
  private recordsAll: any;
  private recCount: any;
  @Input() CMHBoardsGridData: any;
  private dateFormat: any;
  @Output() currentId: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) {
    this.dateFormat = dateFormat;
  }

  ngOnInit() {
    this.recordsAll = JSON.parse(localStorage.getItem('recAll'));
    this.recCount = this.recordsAll.length - 1;
    if (Number(localStorage.getItem('currentIndex')) === 1) {
      this.disablePre = true;
    } else if (Number(localStorage.getItem('currentIndex')) === this.recCount) {
      this.disableNxt = true;
    }
    this.editCMHBoardsForm = new FormGroup({
      'name': new FormControl('', Validators.required),
      'active': new FormControl('', Validators.required),
      'createdBy': new FormControl(''),
      'createdOn': new FormControl(''),
      'modifiedBy': new FormControl(''),
      'modifiedOn': new FormControl('')
    });
  }
  RefreshCMHBoardsModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('cmhBoardList', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.CMHBoardsList = res.data;
        this.CMHBoardsGridData.tableData = this.CMHBoardsList;
      } else {
        // console.log('error');
      }

    }, error => {
      // console.log(error);
    });
  }
  editCMHBoardsSubmit(event: any) {
    console.log(this.editCMHBoardsForm.valid);
    Object.keys(this.editCMHBoardsForm.controls).forEach(field => {
      const control = this.editCMHBoardsForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.editCMHBoardsForm.valid) {
      this.data = this.editCMHBoardsForm.value;
      this.data['cmhboardsId'] = this.selectedRowData.cmhboardsId;
      this.spinnerFlag = true;
      this.notifyMsg = '';
      this.messageFlag = false;
      this.httpService.updateRecord('editCMHBoard', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.messageFlag = true;
          this.notifyMsg = 'Record updated successfully';
          setTimeout(() => {
            this.modalRef.hide();
          }, 2000);
          this.RefreshCMHBoardsModal();
        } else {
          // console.log('error');
        }

      }, error => {
        // console.log(error);
      });

    }
  }
  EditCMHBoardsModal(id) {
    this.spinnerFlag = true;
    this.httpService.getRecord('viewCmhBoard?cmhBoardId=' + id).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.selectedRowData = res.data;

      } else {
        // console.log('error');
      }
    }, error => {
      // console.log(error);
    });
  }

  recordNavigation(action) {

    this.disablePre = false;
    this.disableNxt = false;
    const recordsAll: any = JSON.parse(localStorage.getItem('recAll'));
    this.currentIdx = localStorage.getItem('currentIndex');

    if (action === 'previous') {
      this.currentRecId = recordsAll[Number(this.currentIdx) - 1];
      this.currentIdx = Number(this.currentIdx) - 1;
    } else {
      this.currentRecId = recordsAll[Number(this.currentIdx) + 1];
      this.currentIdx = Number(this.currentIdx) + 1;
    }
    if (this.currentIdx === 1) {
      this.disablePre = true;
    }
    if (this.currentIdx === this.recCount) {
      this.disableNxt = true;
    }
    localStorage.setItem('currentIndex', this.currentIdx);
    const list = Array.from(document.getElementById('gridTable').querySelectorAll('tbody tr'));
    list.forEach(function (node) { node.className = ''; });
    document.getElementById(this.currentRecId).classList.add('highlighted');
    this.EditCMHBoardsModal(this.currentRecId);
    this.currentId.emit(this.currentRecId);
  }

}
