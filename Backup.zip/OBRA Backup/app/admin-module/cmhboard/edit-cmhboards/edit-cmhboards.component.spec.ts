import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EditCMHBoardsComponent } from './edit-cmhboards.component';

describe('EditCMHBoardsComponent', () => {
  let component: EditCMHBoardsComponent;
  let fixture: ComponentFixture<EditCMHBoardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditCMHBoardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditCMHBoardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
