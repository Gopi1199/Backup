import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CMHBoardComponent } from './cmhboard.component';

describe('CMHBoardComponent', () => {
  let component: CMHBoardComponent;
  let fixture: ComponentFixture<CMHBoardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CMHBoardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CMHBoardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
