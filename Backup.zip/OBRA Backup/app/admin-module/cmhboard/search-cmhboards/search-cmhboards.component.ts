import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-search-cmhboards',
  templateUrl: './search-cmhboards.component.html',
  styleUrls: ['./search-cmhboards.component.css']
})
export class SearchCMHBoardsComponent implements OnInit {
  private searchCMHBoardsForm: any;
  private searchMsgFlag: boolean = true;
  private searchError: String;
  spinnerFlag: boolean = false;
  data: Object;
  private filter: any;
  private searchInput: Object;
  private searchsuccess: String;
  private searchErrorMsgFlag: boolean = false;
  @Input() CMHBoardsGridData: any;
  @Input() modalRef: any;
  userList: Array<any> = [];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) { }
  ngOnInit() {
    this.searchCMHBoardsForm = this.formBuilder.group({
      'id': [''],
      'value': ['']
    });
  }
  SearchReset() {
    this.searchCMHBoardsForm.reset();
  }
  searchCMHBoardsSubmit() {
    this.filter = { filters: [this.searchCMHBoardsForm.value] };
    this.searchInput = {
      'max': 100,
      'skip': 0,
      'orderBy': '',
      'orderType': 'asc',
      'search': JSON.stringify(this.filter)
    };

    this.spinnerFlag = true;
    this.searchError = '';
    this.searchsuccess = '';
    this.httpService.searchRecord('cmhBoardList', this.searchInput).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.userList = res.data;
        this.CMHBoardsGridData.tableData = this.userList;
        if (res.data.length === 0) {
          this.searchErrorMsgFlag = true;
          this.searchMsgFlag = false;
          this.searchError = 'Records Not found';

        } else {
          this.searchMsgFlag = true;
          this.searchErrorMsgFlag = false;
          this.searchsuccess = 'Records found';
        }
        
      } else {
        this.searchErrorMsgFlag = true;
        this.searchMsgFlag = false;
        this.searchError = 'No records found';
        
      }
    }, error => {
      console.log(error);
    });
  }
}
