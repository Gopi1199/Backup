import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchCMHBoardsComponent } from './search-cmhboards.component';

describe('SearchCMHBoardsComponent', () => {
  let component: SearchCMHBoardsComponent;
  let fixture: ComponentFixture<SearchCMHBoardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchCMHBoardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchCMHBoardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
