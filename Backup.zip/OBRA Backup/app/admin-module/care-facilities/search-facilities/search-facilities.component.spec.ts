import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchFacilitiesComponent } from './search-facilities.component';

describe('SearchFacilitiesComponent', () => {
  let component: SearchFacilitiesComponent;
  let fixture: ComponentFixture<SearchFacilitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchFacilitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFacilitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
