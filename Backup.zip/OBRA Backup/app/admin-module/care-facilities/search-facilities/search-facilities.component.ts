import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-search-facilities',
  templateUrl: './search-facilities.component.html',
  styleUrls: ['./search-facilities.component.css']
})
export class SearchFacilitiesComponent implements OnInit {
  private careFacilityForm: any;
  private searchMsgFlag: boolean = true;
  private searchError: String = '';
  spinnerFlag: boolean = false;
  data: Object;
  private filter: any;
  private searchInput: Object;
  private searchsuccess: String = '';
  private searchErrorMsgFlag: boolean = false;
  @Input() facilitiesGridData: any;
  @Input() modalRef: any;
  careFacilitiesList: Array<any> = [];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) { }
  ngOnInit() {
    this.careFacilityForm = this.formBuilder.group({
      'id': [''],
      'value': ['']
    });
  }
  SearchReset() {
    this.careFacilityForm.reset();
  }
  careFacilitySubmit() {

    this.searchError = '';
    this.searchsuccess = '';
    this.filter = { filters: [this.careFacilityForm.value] };
    this.searchInput = {
      'max': 100,
      'skip': 0,
      'orderBy': '',
      'orderType': 'asc',
      'search': JSON.stringify(this.filter)
    };

    this.spinnerFlag = true;
    this.httpService.searchRecord('searchFacility', this.searchInput).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.careFacilitiesList = res.data;
        this.facilitiesGridData.tableData = this.careFacilitiesList;
        if (res.data.length === 0) {
          this.searchErrorMsgFlag = true;
          this.searchMsgFlag = false;
          this.searchError = 'Records Not found';

        } else {
          this.searchMsgFlag = true;
          this.searchErrorMsgFlag = false;
          this.searchsuccess = 'Records found';

        }
        
      } else {
        this.searchErrorMsgFlag = true;
        this.searchMsgFlag = false;
        this.searchError = 'No records found';
        
      }
    }, error => {
      // console.log(error);
    });
  }
}
