import { Component, OnInit, TemplateRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ValidationService } from '../../validation/validation.service';
import { ControllerMessageComponent } from '../../validation/controller-message/controller-message.component';
import { recordslimitOptions } from '../../JSON';
import { forkJoin } from 'rxjs/observable/forkJoin';

@Component({
  selector: 'app-care-facilities',
  templateUrl: './care-facilities.component.html',
  styleUrls: ['./care-facilities.component.css']
})
export class CareFacilitiesComponent implements OnInit {
  private modalRef: BsModalRef;
  private selectedRowData: any;
  private addFacilitiesForm: FormGroup;
  private selectedRowId: Number;
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private spinnerFlag: boolean = false;
  private facilityTypeAll: any;
  private countyAll: any;
  userList: Array<any> = [];
  private data: Object;
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;

  facilitiesGridData: any = {
    'gridName': 'Facilities',
    'primaryKey': 'facilitiesId',
    'tableData': {},
    'gridDetails': [
      { caption: 'Facility Type', dataField: 'facilityType', width: '20%', sort: true, sortColumn: 'facilityType' },
      { caption: 'Facility Name', dataField: 'facilityName', width: '20%',sort: true, sortColumn: 'facilityName' },
      { caption: 'Address 1', dataField: 'addressLine1', width: '20%', sort: true, sortColumn: 'addressLine1'},
      { caption: 'City', dataField: 'city', width: '10%', sort: true, sortColumn: 'city' },
      { caption: 'Zip', dataField: 'zipcode1', width: '10%', sort: true, sortColumn: 'zipcode1' },
      { caption: 'County', dataField: 'county', width: '10%', sort: true, sortColumn: 'county' },
      { caption: 'Active', dataField: 'active', width: '10%', sort: true, sortColumn: 'active' }
    ]
  };

  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.limitOptions = recordslimitOptions;
    this.RefreshFacilitiesModal();

  }
  pageChanged($event) {
    this.pageNumber = $event;
  }
  onPageSizeChanged(event) {
    this.totalPages = Math.ceil(this.userList.length / event);
    this.pageSize = event;
  }
  onNotify(data: any): void {
    this.selectedRowData = data;
    this.selectedRowId = data.facilitiesId;

  }
  onCurrentId(data: any): void {
    this.selectedRowId = data;
}
  AddFacilitiesModal(AddFacilities: TemplateRef<any>) {
    this.messageFlag = false;
    this.notifyMsg = '';
    this.spinnerFlag = true;

    this.spinnerFlag = true;
    const countryDropDown = this.httpService.getRecord('countyDropDown');
    const cmhBoardDropDown = this.httpService.getRecord('facilityTypeDropDown');
    forkJoin([countryDropDown, cmhBoardDropDown]).subscribe(results => {

      if ( results[0].global === 'successMsg@' &&  results[1].global === 'successMsg@') {
        this.countyAll = results[0].data;
        this.facilityTypeAll = results[1].data;
        this.spinnerFlag = false;
        this.modalRef = this.modalService.show(AddFacilities);
      }
    });
  }
  RefreshFacilitiesModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('searchFacility', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.userList = res.data;
        this.facilitiesGridData.tableData = this.userList;
      } else {
        // console.log('error');
      }

    }, error => {
      // console.log(error);
    });
  }
  EditFacilitiesModal(EditFacilities: TemplateRef<any>, SelectFacilities: TemplateRef<any>) {

    if (this.selectedRowId) {
      this.spinnerFlag = true;
      const facilitiesInfo = this.httpService.getRecord('viewFacility?facilitiesId=' + this.selectedRowId);
      const cmhBoardDropDown = this.httpService.getRecord('facilityTypeDropDown');
      const countryDropDown = this.httpService.getRecord('countyDropDown');
      forkJoin([facilitiesInfo, cmhBoardDropDown, countryDropDown]).subscribe(results => {

        if ( results[0].global === 'successMsg@' &&  results[1].global === 'successMsg@') {
          this.selectedRowData = results[0].data;
          this.facilityTypeAll = results[1].data;
          this.countyAll = results[2].data;
          this.spinnerFlag = false;
          this.modalRef = this.modalService.show(EditFacilities);
        }
      });
    } else {
      this.modalRef = this.modalService.show(SelectFacilities);
    }
  }
  ViewFacilitiesModal(ViewFacilities: TemplateRef<any>, SelectFacilities: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.spinnerFlag = true;
      this.httpService.deleteRecord('viewFacility?facilitiesId=' + this.selectedRowId).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.selectedRowData = res.data;
          this.spinnerFlag = false;
          this.modalRef = this.modalService.show(ViewFacilities);
        } else {
          // console.log('error');
        }

      }, error => {
        // console.log(error);
      });
    } else {
      this.modalRef = this.modalService.show(SelectFacilities);
    }
  }
  DeleteFacilitiesModal(DeleteFacilities: TemplateRef<any>, SelectFacilities: TemplateRef<any>) {
    if (this.selectedRowId) {
      this.modalRef = this.modalService.show(DeleteFacilities);
    } else {
      this.modalRef = this.modalService.show(SelectFacilities);
    }
  }
  SearchFacilitiesModal(SearchFacilities: TemplateRef<any>) {
    this.modalRef = this.modalService.show(SearchFacilities);
  }
}
