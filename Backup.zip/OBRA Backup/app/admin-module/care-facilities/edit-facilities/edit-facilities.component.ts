import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../../../Service/webservice';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ValidationService } from '../../../validation/validation.service';
import { dateFormat } from '../../../JSON';
@Component({
  selector: 'app-edit-facilities',
  templateUrl: './edit-facilities.component.html',
  styleUrls: ['./edit-facilities.component.css']
})
export class EditFacilitiesComponent implements OnInit {
  private editFacilitiesForm: any;
  private data: Object;
  spinnerFlag: boolean = false;
  private messageFlag: boolean = false;
  private notifyMsg: String = '';
  private selectedRowId: Number;
  private setClickedRow: Function;
  private disablePre: Boolean = false;
  private disableNxt: Boolean = false;
  private currentIdx: any;
  private currentRecId: any;
  private nextIdx: any;
  userList: Array<any> = [];
  pageNumber: number = 1;
  pageSize: number = 20;
  limitOptions: any;
  totalPages: number;
  private recordsAll: any;
  private recCount: any;
  @Input() facilitiesGridData: any;
  @Output() currentId: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();
  @Input() modalRef: any;
  @Input() selectedRowData: any;
  @Input() facilityTypeAll: any;
  @Input() countyAll: any;
  private dateFormat: any;
  mask: any[] = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private httpService: WebService, private http: HttpClient, private formBuilder: FormBuilder) {
    this.dateFormat = dateFormat;
  }
  ngOnInit() {
    this.recordsAll = JSON.parse(localStorage.getItem('recAll'));
    this.recCount = this.recordsAll.length - 1;
    if (Number(localStorage.getItem('currentIndex')) === 1) {
      this.disablePre = true;
    } else if (Number(localStorage.getItem('currentIndex')) === this.recCount) {
      this.disableNxt = true;
    }
    this.editFacilitiesForm = this.formBuilder.group({
      'facilityTypesId': new FormControl('', [Validators.required]),
      'name': new FormControl('', [Validators.required]),
      'addressLine1': new FormControl('', [Validators.required]),
      'addressLine2': new FormControl(''),
      'city': new FormControl('', [Validators.required]),
      'state': new FormControl('MI', [Validators.required]),
      'zipcode1': new FormControl('', [Validators.required, ValidationService.zipCodeValidator]),
      'zipcode2': new FormControl('', ValidationService.zipCodeValidator),
      'phoneNumber': new FormControl(''),
      'countyId': new FormControl('ALCONA', [Validators.required]),
      'active': new FormControl('Y', [Validators.required]),
      'facilityFlag': new FormControl('Yes', [Validators.required]),
      'createdBy': new FormControl(''),
      'createdOn': new FormControl(''),
      'modifiedBy': new FormControl(''),
      'modifiedOn': new FormControl('')
    });
  }
  RefreshFacilitiesModal() {
    this.spinnerFlag = true;
    this.data = {
      'startIndex': 0,
      'maxResults': 100
    };
    this.httpService.getRecordList('searchFacility', this.data).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.userList = res.data;
        this.facilitiesGridData.tableData = this.userList;
      } else {
        // console.log('error');
      }

    }, error => {
      // console.log(error);
    });
  }
  editFacilitiesSubmit(event: any) {
    console.log(this.editFacilitiesForm.valid);
    Object.keys(this.editFacilitiesForm.controls).forEach(field => {
      const control = this.editFacilitiesForm.get(field);
      control.markAsTouched({ onlySelf: true });
    });
    if (this.editFacilitiesForm.valid) {
      let phone = String(this.editFacilitiesForm.value.phoneNumber);
      phone = phone.replace(/\D+/g, '');
      this.editFacilitiesForm.value.phoneNumber = phone;
      this.data = this.editFacilitiesForm.value;
      this.data['facilitiesId'] = this.selectedRowData.facilitiesId;
      this.spinnerFlag = true;
      this.notifyMsg = '';
      this.messageFlag = false;
      this.httpService.updateRecord('editFacility', this.data).subscribe(res => {
        if (res.global === 'successMsg@') {
          this.spinnerFlag = false;
          this.messageFlag = true;
          this.notifyMsg = 'Record updated successfully';
          setTimeout(() => {
            this.modalRef.hide();
          }, 2000);
          this.RefreshFacilitiesModal();
        } else {
          // console.log('error');
        }

      }, error => {
        // console.log(error);
      });

    }
  }

  EditFacilitiesModal(id) {
    this.spinnerFlag = true;
    this.httpService.getRecord('viewFacility?facilitiesId=' + id).subscribe(res => {
      if (res.global === 'successMsg@') {
        this.spinnerFlag = false;
        this.selectedRowData = res.data;

      } else {
        // console.log('error');
      }
    }, error => {
      // console.log(error);
    });
  }

  recordNavigation(action) {

    this.disablePre = false;
    this.disableNxt = false;
    const recordsAll: any = JSON.parse(localStorage.getItem('recAll'));
    this.currentIdx = localStorage.getItem('currentIndex');

    if (action === 'previous') {
      this.currentRecId = recordsAll[Number(this.currentIdx) - 1];
      this.currentIdx = Number(this.currentIdx) - 1;
    } else {
      this.currentRecId = recordsAll[Number(this.currentIdx) + 1];
      this.currentIdx = Number(this.currentIdx) + 1;
    }
    if (this.currentIdx === 1) {
      this.disablePre = true;
    }
    if (this.currentIdx === this.recCount) {
      this.disableNxt = true;
    }
    localStorage.setItem('currentIndex', this.currentIdx);
    const list = Array.from(document.getElementById('gridTable').querySelectorAll('tbody tr'));
    list.forEach(function (node) { node.className = ''; });
    document.getElementById(this.currentRecId).classList.add('highlighted');
    this.EditFacilitiesModal(this.currentRecId);
    this.currentId.emit(this.currentRecId);
  }

}
