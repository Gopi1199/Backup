import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CareFacilitiesComponent } from './care-facilities.component';

describe('CareFacilitiesComponent', () => {
  let component: CareFacilitiesComponent;
  let fixture: ComponentFixture<CareFacilitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CareFacilitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CareFacilitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
