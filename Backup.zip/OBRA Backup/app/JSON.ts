export const recordslimitOptions = [
    {
        key: '20',
        value: 20
    },
    {
        key: '40',
        value: 40
    },
    {
        key: '60',
        value: 60
    }
];
export const dateFormat = 'MM/dd/yyyy';
